# News for hyenaR

The content of the NEWS is stored as an optional vignette.

You can see its content after installing the package by simply running:

```{r}
build_vignette_news()
```
