context("Test fetch_database_column functions")


test_that("fetch_database_column is robust", {
  test1 <- fetch_database_column(column = "sex", tbl.name = "hyenas")
  ID <- find_pop_id()
  test2 <- fetch_id_sex(ID = ID)
  foo <- function(ID) fetch_id_sex(ID = ID)
  test3 <- foo(ID = ID)
  expect_identical(test1, test2)
  expect_identical(test2, test3)
})
