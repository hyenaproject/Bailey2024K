context("Test functions associated with SHIM simulation...")

test_that("simulation can be loaded", {
  # Run simulation object if recent SHIM is installed
  ## NEEDS 0.5.12 BECAUSE THIS ALLOWS US TO RUN WITHOUT ATTACHING!!
  testthat::skip_if_not_installed("SHIM", minimum_version = "0.5.12")

  ## SHIM should be able to run even if unattached
  sim_test <- SHIM::simulation$new(
    number_clans = 2,
    ## Ignore starting population for smaller sim
    start_pop = NULL,
    start_clan_size = 2, sex_ratio = 0.5, mean_age = 6,
    seed = 123
  )
  sim_test$run_sim(number_steps = 2)

  ## Can load database and
  # .database is created with sim attribute
  load_package_database.sim(sim_test, verbose = FALSE)
  expect_true(attr(.database, "datatype") == "sim")

  # Test that we can run a regular hyenaR function
  # Shouldn't throw any errors
  expect_no_error(create_id_life.history.table())

  # Test that simulation data is correctly available for hyenaR
  ## Should only have 2 clans
  expect_equal(length(find_clan_name.all()), 2)
  ## Population size should be 4 at start date
  expect_equal(fetch_pop_number(at = find_pop_date.observation.first()), 4)

  # Reload dummy data in case there are other tests that need to be run
  load_package_database.dummy()
})
