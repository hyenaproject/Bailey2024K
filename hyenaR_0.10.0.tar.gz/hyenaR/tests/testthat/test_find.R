context("Test find_xxx functions")

test_that("all find functions return the correct type", {
  expect_equal(class(find_clan_id(clan = c("A", "L"), at = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id(clan = c("A", "L"), at = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id(clan = "A", at = "1997/01/01"))[1], "character")

  expect_equal(class(find_clan_id(clan = "A"))[1], "character")
  expect_equal(class(find_clan_id(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12"))[1], "character")
  expect_equal(class(find_clan_id(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start"))[1], "character")
  expect_equal(class(find_clan_id(clan = "A", lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start"))[1], "character")
  expect_equal(class(find_clan_id(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-10-30", clan.overlap = "always", lifestage.overlap = "always"))[1], "character")
  expect_equal(class(find_clan_id(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any"))[1], "character")

  expect_equal(class(find_clan_id.anysex.dead(clan = "A", from = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.anysex.dead(clan = "A", to = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.anysex.dead(clan = "A", at = "1997/01/01"))[1], "character")
  expect_equal(class(find_clan_id.anysex.dead(clan = "A"))[1], "character")
  expect_equal(class(find_pop_id.anysex.dead())[1], "character")

  expect_equal(class(find_clan_name.all(main.clans = TRUE, full.clan.names = FALSE))[1], "character")
  expect_equal(class(find_clan_name.all(main.clans = TRUE, full.clan.names = TRUE))[1], "character")
  expect_equal(class(find_pop_date.birth.first())[1], "Date")

  expect_equal(class(find_dyad_winner.migrant("A-011", "A-055", "1997-01-01")), "character")
  expect_equal(class(find_dyad_winner.native.migrant("A-001", "A-011")), "character")
  expect_equal(class(find_dyad_winner.native.unrelated("A-001", "A-004", "1997-01-01")), "character")
  expect_equal(class(find_dyad_winner.native.related("A-001", "A-010")), "character")
  expect_equal(class(find_dyad_interaction.winner.from.interaction.type("A-001", "A-010", "1997-01-01", "native_related")), "character")
  expect_equal(class(find_dyad_MRCA.choice("A-001", "A-010")), "character")
  expect_equal(class(find_dyad_number.supporter(ID.1 = "A-001", ID.2 = "A-010", at = "1997/01/01")), "integer")
  expect_equal(class(find_id_id.descendant.of.youngest.offspring(ID = c("A-010", "A-084"), mrcaID = "A-001")), "character")
  expect_equal(class(find_id_id.sibling.older(ID = "A-018")), "character")
  expect_equal(class(find_id_id.sibling(ID = "A-084", filiation = "mother_genetic")), "character")
  expect_equal(class(find_id_id.offspring(ID = "A-001")), "character")
})


test_that("find_clan_id return the correct output", {
  # Return all individuals ever alive
  job1 <- find_clan_id(clan = find_clan_name.all(main.clans = FALSE))
  ref1 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-007", "A-008",
    "A-009", "A-010", "A-011", "A-013", "A-014", "A-015", "A-016",
    "A-017", "A-018", "A-019", "A-020", "A-040", "A-041", "A-042",
    "A-043", "A-044", "A-045", "A-046", "A-047", "A-048", "A-049",
    "A-050", "A-051", "A-052", "A-053", "A-054", "A-055", "A-056",
    "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
    "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
    "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
    "A-099", "A-100", "A-113", "A-114", "L-001", "L-002", "L-003",
    "L-004", "L-005", "L-006", "L-007", "L-008", "L-009", "L-010",
    "L-011", "L-012", "L-013", "L-014", "L-015", "L-040", "L-041",
    "L-042", "L-043", "L-044", "L-045", "L-046", "L-047", "L-048",
    "L-049", "L-080", "L-081", "L-082", "L-083", "L-084", "L-085",
    "L-086", "L-087", "L-088", "L-089", "L-090", "L-091", "L-092",
    "L-093", "L-094", "L-095", "L-096", "L-097", "L-098", "L-099",
    "L-100", "L-101", "L-102", "L-103", "L-104", "L-105", "L-106",
    "L-108", "L-109", "L-110", "M-004", "M-047", "M-051", "M-053",
    "N-043", "S-002", "S-043"
  )
  expect_identical(job1, ref1)

  # Return all individuals ever in clan A
  job2 <- find_clan_id(clan = "A")
  ref2 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-007", "A-008",
    "A-009", "A-010", "A-011", "A-013", "A-014", "A-015", "A-016",
    "A-017", "A-018", "A-019", "A-020", "A-040", "A-041", "A-042",
    "A-043", "A-044", "A-045", "A-046", "A-047", "A-048", "A-049",
    "A-050", "A-051", "A-052", "A-053", "A-054", "A-055", "A-056",
    "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
    "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
    "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
    "A-099", "A-100", "A-113", "A-114", "M-051", "M-053", "S-043"
  )
  expect_identical(job2, ref2)

  # Return all individuals that were philopatric at this date
  job3 <- find_clan_id(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
  ref3 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-007", "A-009",
    "A-013", "A-014", "A-015", "A-016", "A-017", "A-020", "L-001",
    "L-002", "L-003", "L-004", "L-005", "L-006", "L-007", "L-008",
    "L-009", "L-011", "L-012", "L-014"
  )
  expect_identical(job3, ref3)

  # Return all individuals that were born/emigrated to clan A between these dates
  job4 <- find_clan_id(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start")
  ref4 <- c(
    "A-011", "A-042", "A-044", "A-045", "A-047", "A-048",
    "A-050", "A-051", "A-055", "A-080", "A-081", "A-086", "A-087",
    "A-088", "A-089", "A-090", "A-091", "A-092", "A-093", "A-094",
    "A-095", "A-096", "A-097", "A-098", "A-099", "A-100", "A-114",
    "M-051", "M-053", "S-043"
  )
  expect_identical(job4, ref4)

  # Return individuals that immigrated to clan A during these dates
  job5 <- find_clan_id(clan = "A", lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start")
  ref5 <- c(
    "A-008", "A-010", "A-018", "A-019", "A-040", "M-051", "M-053",
    "S-043"
  )
  expect_identical(job5, ref5)

  # Return individuals that were philopatric in clan A during this whole period
  job6 <- find_clan_id(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-01-30", clan.overlap = "always", lifestage.overlap = "always")
  ref6 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-008", "A-009",
    "A-010", "A-013", "A-014", "A-015", "A-016", "A-017", "A-018", "A-019",
    "A-020", "A-040"
  )
  expect_identical(job6, ref6)

  # Return individuals that were philopatric for some time in clan A during this period
  # Use argument 'any' is the default, so we should get the same result with and without overlap arguments
  job7a <- find_clan_id(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any")
  job7b <- find_clan_id(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30")
  ref7 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-007", "A-008",
    "A-009", "A-010", "A-013", "A-014", "A-015", "A-016", "A-017",
    "A-018", "A-019", "A-020", "A-040"
  )
  expect_identical(job7a, job7b, ref7)

  # All females born in clan A
  job8 <- find_clan_id(sex = "female", clan = "A")
  ref8 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-007", "A-008",
    "A-009", "A-010", "A-013", "A-014", "A-015", "A-016", "A-017",
    "A-018", "A-019", "A-020", "A-080", "A-081", "A-088", "A-096",
    "A-098", "A-114"
  )
  expect_identical(job8, ref8)

  # Return all lifestages except dead
  job9a <- find_clan_id(clan = "A", lifestage = "!dead", at = "1997-01-01")
  job9b <- find_clan_id(clan = "A", at = "1997-01-01")
  ref9 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-008", "A-009",
    "A-010", "A-011", "A-013", "A-014", "A-015", "A-016", "A-017",
    "A-018", "A-019", "A-020", "A-040", "A-041", "A-042", "A-045",
    "A-046", "A-047", "A-048", "A-049", "A-050", "A-051", "A-052",
    "A-053", "A-054", "A-055", "A-056", "A-057", "A-080", "A-081",
    "A-083", "A-084", "A-085", "A-086", "A-087", "A-088", "A-089",
    "A-092", "A-093", "A-095", "A-113", "M-053"
  )
  expect_identical(job9a, job9b, ref9)

  # Return all lifestages including dead
  job10 <- find_clan_id(clan = "A", at = "1997-01-01", lifestage = "all")
  ref10 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-007", "A-008",
    "A-009", "A-010", "A-011", "A-013", "A-014", "A-015", "A-016",
    "A-017", "A-018", "A-019", "A-020", "A-040", "A-041", "A-042",
    "A-043", "A-044", "A-045", "A-046", "A-047", "A-048", "A-049",
    "A-050", "A-051", "A-052", "A-053", "A-054", "A-055", "A-056",
    "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
    "A-085", "A-086", "A-087", "A-088", "A-089", "A-092", "A-093",
    "A-095", "A-113", "M-053"
  )
  expect_identical(job10, ref10)

  # Return only dead individuals
  job11 <- find_clan_id(clan = "A", at = "1997-01-01", lifestage = "dead")
  ref11 <- c("A-007", "A-043", "A-044", "A-058", "A-082")
  expect_identical(job11, ref11)

  # Difference between job9a/b (all except dead) and job10 (all including dead) should be job11 (only dead)
  expect_identical(setdiff(job10, job9a), setdiff(job10, job9b), job11)

  # Including and negating non-possible lifestages will throw an error
  expect_error(find_clan_id(lifestage = "wrong"))
  expect_error(find_clan_id(lifestage = "!wrong"))
})

test_that("find_pop_date.birth.first works as intended", {
  ref <- as.Date("1979-04-14")
  job <- find_pop_date.birth.first()
  expect_equal(ref, job)
})


test_that("find_clan_name.all returns the correct output", {
  ref <- c("A", "E", "F", "L", "M", "N", "S", "T")
  job <- find_clan_name.all()
  expect_equal(ref, job)

  ref2 <- c("AIRSTRIP", "ENGITATI", "FOREST", "LEMALA", "MUNGE", "NGOITOKITOK",
            "SHAMBA", "TRIANGLE")
  job2 <- find_clan_name.all(full.clan.names = TRUE)
  expect_equal(ref2, job2)
})

test_that("find_pop_id.anysex.adult returns the correct output", {
  ref <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-008", "A-009",
    "A-010", "A-011", "A-013", "A-014", "A-015", "A-016", "A-017",
    "A-018", "A-019", "A-020", "A-040", "A-041", "A-042", "A-045",
    "A-046", "A-047", "A-048", "A-049", "A-050", "A-051", "A-052",
    "A-053", "A-055", "A-056", "A-057", "L-001", "L-002", "L-003",
    "L-004", "L-005", "L-008", "L-009", "L-010", "L-011", "L-012",
    "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-044",
    "L-045", "L-047", "L-048", "M-004", "M-047", "M-051", "M-053",
    "N-043", "S-043"
  )
  job <- find_pop_id.anysex.adult(at = "1997-01-01")
  expect_equal(ref, job)

  ref2 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-008", "A-009",
    "A-010", "A-011", "A-013", "A-014", "A-015", "A-016", "A-017",
    "A-018", "A-019", "A-020", "A-040", "A-041", "A-042", "A-045",
    "A-046", "A-047", "A-048", "A-049", "A-050", "A-051", "A-052",
    "A-053", "A-055", "A-056", "A-057", "L-001", "L-002", "L-003",
    "L-004", "L-005", "L-008", "L-009", "L-010", "L-011", "L-012",
    "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-044",
    "L-045", "L-047", "L-048", "M-004", "M-047", "M-051", "M-053",
    "N-043", "S-043"
  )
  job2 <- find_pop_id.anysex.adult(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)
})

test_that("find_pop_id.female.adult returns the correct output", {
  ref <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-008", "A-009",
    "A-010", "A-013", "A-014", "A-015", "A-016", "A-017", "A-018", "A-019",
    "A-020"
  )
  job <- find_clan_id.female.adult(clan = "A", at = "1997-01-01")
  expect_equal(ref, job)

  ref2 <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-008", "A-009",
    "A-010", "A-013", "A-014", "A-015", "A-016", "A-017", "A-018", "A-019",
    "A-020", "L-001", "L-002", "L-003", "L-004", "L-005", "L-008",
    "L-009", "L-010", "L-011", "L-012", "L-013", "L-014", "L-015",
    "M-004"
  )
  job2 <- find_pop_id.female.adult(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)
})

test_that("find_clan/pop_id.anysex.foreigner returns the correct output", {
  ## FIXME: In dummy data there are no longer any foreigners (all are now classed as founder males)
  ## so it's hard to test these funcs fully
  # ref <- c("A-011", "A-042", "A-045", "A-047", "A-048", "A-050", "A-051",
  #          "A-055")
  ref <- as.character(NULL)
  job <- find_clan_id.anysex.foreigner(clan = "A", at = "1997-01-01")
  expect_equal(ref, job)

  # ref2 <- c("A-011", "A-042", "A-045", "A-047", "A-048", "A-050", "A-051",
  #           "A-055", "L-040", "L-041", "L-042", "L-047", "L-048")
  ref2 <- as.character(NULL)
  job2 <- find_pop_id.anysex.foreigner(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)

  expect_error(find_clan_id.foreigner(clan = c("A", "A"), at = "1997-01-01"))
})

test_that("find_pop_id.male.all returns the correct output", {
  ref <- c(
    "A-011", "A-040", "A-041", "A-042", "A-045", "A-046", "A-047",
    "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
    "A-055", "A-056", "A-057", "A-083", "A-084", "A-085", "A-086",
    "A-087", "A-089", "A-092", "A-093", "A-095", "A-113", "M-053"
  )
  job <- find_clan_id.male.all(clan = "A", at = "1997-01-01")
  expect_equal(ref, job)

  ref2 <- c(
    "A-011", "A-040", "A-041", "A-042", "A-045", "A-046", "A-047",
    "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
    "A-055", "A-056", "A-057", "A-083", "A-084", "A-085", "A-086",
    "A-087", "A-089", "A-092", "A-093", "A-095", "A-113", "L-040",
    "L-041", "L-042", "L-044", "L-045", "L-046", "L-047", "L-048",
    "L-080", "L-081", "L-082", "L-083", "L-086", "L-089", "L-090",
    "L-093", "M-047", "M-051", "M-053", "N-043", "S-043"
  )
  job2 <- find_pop_id.male.all(at = "1997-01-01", main.clans = TRUE)
  expect_equal(ref2, job2)
})


test_that("find_clan/pop_id.dead returns the correct output", {
  ref <- c("A-007", "A-043", "A-044", "A-058", "A-082")
  job <- find_clan_id.anysex.dead(clan = "A", to = "1997-01-01")
  expect_equal(ref, job)

  ref2 <- c(
    "A-007", "A-043", "A-044", "A-058", "A-082", "L-006", "L-007",
    "L-043", "L-049", "L-091", "L-092", "S-002"
  )
  job2 <- find_pop_id.anysex.dead(to = "1997-01-01")
  expect_equal(ref2, job2)
})


test_that("find_pop_id.dummy is complete", {
  expect_equal(find_pop_id.dummy(), find_pop_id())
})

test_that("find_dyad_winner.migrant returns the correct output", {
  expect_equal(find_dyad_winner.migrant("A-011", "A-055", "1997-01-01"), "A-011")
})

test_that("find_dyad_winner.native.migrant returns the correct output", {
  expect_equal(find_dyad_winner.native.migrant("A-001", "A-011"), "A-001")
})

test_that("find_dyad_winner.native.unrelated returns the correct output", {
  expect_equal(find_dyad_winner.native.unrelated("A-001", "A-004", "1997-01-01"), "A-001")
})

test_that("find_dyad_winner.native.related returns the correct output", {
  expect_equal(find_dyad_winner.native.related("A-001", "A-010"), "A-001")
})

test_that("find_dyad_interaction.winner.from.interaction.type returns the correct output", {
  expect_equal(find_dyad_interaction.winner.from.interaction.type("A-001", "A-010", "1997-01-01", "native_related"), "A-001")
})

test_that("find_dyad_MRCA.choice returns the correct output", {
  expect_equal(find_dyad_MRCA.choice("A-001", "A-010"), "A-001")
})

test_that("find_dyad_number.supporter returns the correct output", {
  expect_equal(find_dyad_number.supporter(ID.1 = "A-001", ID.2 = "A-010", at = "1997-01-01"), 3) ## used to be 1, but depends on whether older siblings include those with same age or not; see find_id_id.sibling.older
})

test_that("find_id_id.descendant.of.youngest.offspring returns the correct output", {
  expect_equal(find_id_id.descendant.of.youngest.offspring(ID = c("A-010", "A-084"), mrcaID = "A-001"), "A-084")
})

test_that("find_id_id.sibling.older returns the correct output", {
  # expect_equal(find_id_id.sibling.older(ID = "A-018"), c("A-010", "A-046")) ## no longer true since all offspring have same age
  expect_equal(find_id_id.sibling.older(ID = "A-089"), c("A-010", "A-018", "A-046", "A-084"))
})

test_that("find_id_id.sibling returns the correct output", {
  expect_equal(find_id_id.sibling(ID = "A-084", filiation = "mother_genetic"), c("A-010", "A-018", "A-046", "A-088", "A-089"))
})

test_that("find_pop/clan_xxx that should return no individuals do so", {
  ref <- character(0)
  expect_equal(ref, find_pop_id.female.disperser())
  expect_equal(ref, find_pop_id.female.transient())
  expect_equal(ref, find_pop_id.female.natal())
})

test_that("find_pop/clan_xxx that return correct individuals when using lifestage.overlap", {
  ref <- c("A-080", "A-081", "A-088", "L-084", "L-085", "L-087", "L-094", "L-096", "L-097", "L-101", "L-102")
  job <- find_pop_id.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "any")
  expect_equal(ref, job)

  ref <- c("L-094", "L-096", "L-097", "L-101", "L-102")
  job <- find_pop_id.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "start")
  expect_equal(ref, job)

  ref <- c("L-084", "L-085", "L-087")
  job <- find_pop_id.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "end")
  expect_equal(ref, job)

  ref <- c("A-080", "A-081", "A-088")
  job <- find_pop_id.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "always")
  expect_equal(ref, job)

  ref <- character(0)
  job <- find_pop_id.female.cub(from = "1997/01/01", to = "1997/06/01", lifestage.overlap = "within")
  expect_equal(ref, job)
})

test_that("find_clan_xxx that return correct individuals when using clan.overlap", {
  ref1 <- c("L-084", "L-085", "L-087", "L-094", "L-096", "L-097", "L-101", "L-102")
  job1 <- find_clan_id.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "any")
  expect_equal(ref1, job1)

  ref2 <- c("L-094", "L-096", "L-097", "L-101", "L-102")
  job2 <- find_clan_id.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "start")
  expect_equal(ref2, job2)

  ref3 <- c("L-084", "L-085", "L-087")
  job3 <- find_clan_id.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "end")
  expect_equal(ref3, job3)

  ref4 <- character(0)
  job4 <- find_clan_id.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "always")
  expect_equal(ref4, job4)

  ref5 <- character(0)
  job5 <- find_clan_id.female.cub(clan = "L", from = "1997/01/01", to = "1997/06/01", clan.overlap = "within")
  expect_equal(ref5, job5)
})

test_that("find_clan_id and find_pop_id are equivalent", {
  expect_equal(find_clan_id(find_clan_name.all(main.clans = FALSE)), find_pop_id())
})

test_that("create_id_starting.table and fetch_id_is.alive give same result", {
  starting_table <- find_pop_id.anysex.all(at = "1997-01-01")

  extract_database_table("hyenas") %>%
    dplyr::mutate(is_alive = fetch_id_is.alive(ID, at = "1997-01-01")) %>%
    dplyr::filter(.data$is_alive) %>%
    dplyr::pull(.data$ID) -> isalive

  expect_identical(starting_table, isalive)
})

test_that("find_id_id.offspring works as expected", {
  # Gives message if using wrong filiation (i.e. father with female or mother with male)
  expect_message(find_id_id.offspring(ID = "A-001", filiation = "father"))
  expect_message(find_id_id.offspring(ID = "A-011", filiation = "mother_social"))

  # Returns NA when
  expect_equal(find_id_id.offspring(ID = "A-001", filiation = "father"), NA_character_)

  # Get correct results
  ref <- c("A-010", "A-018", "A-046", "A-084", "A-088", "A-089")
  job <- find_id_id.offspring(ID = "A-001")

  expect_equal(ref, job)
})

test_that("find_pop_date.observation.xxx works as expected", {
  ref <- extract_database_table("sightings") %>%
    dplyr::filter(.data$date_time == min(.data$date_time)) %>%
    dplyr::pull(.data$date_time) %>%
    recode_x_date()

  job <- find_pop_date.observation.first(from.conception = TRUE)

  expect_equal(ref, job)
})

test_that("Find clan immigrant can be used to recreate previous functions", {
  #### Find clan ####
  expect_warning(job1 <- find_clan_id.male.immigrant(clan = "A"))
  ref1 <- find_clan_id(
    clan = "A",
    sex = "male",
    lifestage = c("foreigner_1", "founder_male")
  )
  expect_equal(job1, ref1)

  expect_warning(job2 <- find_clan_id.female.immigrant(clan = "A"))
  ref2 <- find_clan_id(
    clan = "A",
    sex = "female",
    lifestage = c("foreigner_1")
  )
  expect_equal(job2, ref2)

  expect_warning(job3 <- find_clan_id.anysex.immigrant(clan = "A"))
  ref3 <- find_clan_id(
    clan = "A",
    lifestage = c("foreigner_1", "founder_male")
  )
  expect_equal(job3, ref3)
})

test_that("Find pop immigrant can be used to recreate previous functions", {
  #### Find pop ####
  expect_warning(job1 <- find_pop_id.male.immigrant())
  ref1 <- find_pop_id(
    sex = "male",
    lifestage = c("foreigner_1", "founder_male")
  )
  expect_equal(job1, ref1)

  expect_warning(job2 <- find_pop_id.female.immigrant())
  ref2 <- find_pop_id(
    sex = "female",
    lifestage = c("foreigner_1")
  )
  expect_equal(job2, ref2)

  expect_warning(job3 <- find_pop_id.anysex.immigrant())
  ref3 <- find_pop_id(lifestage = c("foreigner_1", "founder_male"))
  expect_equal(job3, ref3)
})

test_that("find_pop_id.founder() works as expected", {
  job1 <- find_pop_id.founder()
  ref1 <- extract_database_table("hyenas") %>%
    dplyr::filter(birthdate < find_pop_date.observation.first()) %>%
    dplyr::pull(.data$ID)
  expect_equal(job1, ref1)
})
