context("Test create_xxx functions")

test_that("all create functions return the correct type", {
  expect_equal(class(create_id_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_starting.table())[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(lifestage = c("philopatric", "disperser"), from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-12-01", to = "1997-10-30", clan.overlap = "always", lifestage.overlap = "always"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", lifestage = "philopatric", from = "1996-04-12", to = "1997-12-30", clan.overlap = "any", lifestage.overlap = "any"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start"))[1], "tbl_df")
  expect_equal(class(create_id_starting.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_offspring.table(ID = c("A-080", "L-094")))[1], "tbl_df")
  expect_equal(class(create_id_mate.conception.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_id_offspring.count(ID = c("A-001", "A-008")))[1], "tbl_df")
  expect_equal(class(create_sighting_starting.table(ID = c("A-001", "A-008")))[1], "tbl_df")
  expect_equal(class(create_sample_starting.table(at = "1996/07/30"))[1], "tbl_df")
  expect_equal(class(create_id_offspring.table(ID = "A-001"))[1], "tbl_df")
  expect_equal(class(create_cervus_input(c("A-008")))[1], "tbl_df")
  expect_equal(class(create_offspring_father.candidate.table(c("A-008")))[1], "tbl_df")
  expect_equal(class(create_dyad_table.bystander("A-011", "A-001", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_dyad_relatedness.via.filiation.table(c("A-011", "A-001"), filiation = "mother_social", verbose = FALSE))[1], "tbl_df")
  expect_equal(class(create_id_table.ancestors("A", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_clan_rank.social("A", "1996-07-30"))[1], "tbl_df")
  expect_equal(class(create_dyad_interaction.type("A-011", "A-001", "1996-07-30"))[1], "tbl_df")
})


#### CREATE_ID_STARTING.TABLE() #####

test_that("create_id_starting.table defaults are correct", {
  ############

  ### TEST 1: When no arguments are given, return all known individuals
  # Check expected outcome (ref1a) and raw data (ref1b)
  job1 <- create_id_starting.table()
  ref1a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
      "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
      "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
      "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
      "A-055", "A-056", "A-057", "A-058", "A-080", "A-081", "A-082",
      "A-083", "A-084", "A-085", "A-086", "A-087", "A-088", "A-089",
      "A-090", "A-091", "A-092", "A-093", "A-094", "A-095", "A-096",
      "A-097", "A-098", "A-099", "A-100", "A-113", "A-114", "L-001",
      "L-002", "L-003", "L-004", "L-005", "L-006", "L-007", "L-008",
      "L-009", "L-010", "L-011", "L-012", "L-013", "L-014", "L-015",
      "L-040", "L-041", "L-042", "L-043", "L-044", "L-045", "L-046",
      "L-047", "L-048", "L-049", "L-080", "L-081", "L-082", "L-083",
      "L-084", "L-085", "L-086", "L-087", "L-088", "L-089", "L-090",
      "L-091", "L-092", "L-093", "L-094", "L-095", "L-096", "L-097",
      "L-098", "L-099", "L-100", "L-101", "L-102", "L-103", "L-104",
      "L-105", "L-106", "L-108", "L-109", "L-110", "M-004", "M-047",
      "M-051", "M-053", "N-043", "S-002", "S-043"
    )),
    row.names = c(NA, -122L), class = c("tbl_df", "tbl", "data.frame")
  )
  ref1b <- extract_database_table("hyenas") %>%
    dplyr::select("ID")
  expect_equal(job1, ref1a)
  expect_equal(job1, ref1b)

  ############

  ### TEST 2: When ID is specified, return only these individuals
  job2a <- create_id_starting.table(ID = c("A-080", "L-094"))
  # No matter what else is specified!!
  job2b <- create_id_starting.table(
    ID = c("A-080", "L-094"), lifestage = "cub",
    from = "1995-01-01"
  )
  ref2 <- structure(list(ID = c("A-080", "L-094")),
    row.names = c(NA, -2L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  expect_equal(job2a, ref2)
  expect_equal(job2b, ref2)

  ############

  ### TEST 3: When only clan.birth is provided, return all individuals born into this clan
  job3 <- create_id_starting.table(clan.birth = "A")
  ref3a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
      "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
      "A-043", "A-046", "A-049", "A-052", "A-053", "A-054", "A-056",
      "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
      "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
      "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
      "A-099", "A-100", "A-113", "A-114"
    )),
    row.names = c(NA, -51L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  ref3b <- extract_database_table("hyenas") %>%
    dplyr::filter(.data$birthclan == "A") %>%
    dplyr::select("ID")
  expect_equal(job3, ref3a)
  expect_equal(job3, ref3b)
})

test_that("create_id_starting.table works when lifestage/clan.overlap are both 'always'", {
  ############

  ### TEST 4: When at date provided, return all individuals alive at that date
  # Check expected outcome (ref4/5a) and raw data (ref4/5b)
  job4 <- create_id_starting.table(at = "1996-04-12")
  ref4a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
      "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
      "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
      "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
      "A-055", "A-056", "A-057", "A-058", "A-082", "A-083", "A-084",
      "A-085", "A-113", "L-001", "L-002", "L-003", "L-004", "L-005",
      "L-006", "L-007", "L-008", "L-009", "L-010", "L-011", "L-012",
      "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-043",
      "L-044", "L-045", "L-046", "L-047", "L-048", "L-049", "L-082",
      "L-083", "L-088", "L-089", "M-004", "M-047", "M-051", "M-053",
      "N-043", "S-002", "S-043"
    )),
    row.names = c(NA, -78L), class = c("tbl_df", "tbl", "data.frame")
  )
  ref4b <- extract_database_table("hyenas") %>%
    dplyr::left_join(relationship = "many-to-many", extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1996-04-12") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select("ID")
  expect_equal(job4, ref4a)
  expect_equal(job4, ref4b)

  ############

  ### TEST 5: When from/to date provided, return all individuals alive at any point between those dates
  job5 <- create_id_starting.table(from = "1996-04-12", to = "1996-05-12")
  ref5a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-008", "A-009", "A-010", "A-011", "A-013", "A-014",
      "A-015", "A-016", "A-017", "A-018", "A-019", "A-020", "A-040",
      "A-041", "A-042", "A-043", "A-044", "A-045", "A-046", "A-047",
      "A-048", "A-049", "A-050", "A-051", "A-052", "A-053", "A-054",
      "A-055", "A-056", "A-057", "A-058", "A-082", "A-083", "A-084",
      "A-085", "A-113", "L-001", "L-002", "L-003", "L-004", "L-005",
      "L-006", "L-007", "L-008", "L-009", "L-010", "L-011", "L-012",
      "L-013", "L-014", "L-015", "L-040", "L-041", "L-042", "L-043",
      "L-044", "L-045", "L-046", "L-047", "L-048", "L-049", "L-082",
      "L-083", "L-084", "L-085", "L-088", "L-089", "M-004", "M-047",
      "M-051", "M-053", "N-043", "S-002", "S-043"
    )),
    row.names = c(NA, -80L), class = c("tbl_df", "tbl", "data.frame")
  )
  ref5b <- extract_database_table("hyenas") %>%
    dplyr::left_join(relationship = "many-to-many", extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1996-05-12") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select("ID")
  expect_equal(job5, ref5a)
  expect_equal(job5, ref5b)

  ############

  ### TEST 6: When clan, lifestage, and at date are provided will return all individuals of that lifestage, in this clan on that date
  job6 <- create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", at = "1996-04-12")
  ref6a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-009", "A-013", "A-014", "A-015", "A-016", "A-017",
      "A-020", "L-001", "L-002", "L-003", "L-004", "L-005", "L-006",
      "L-007", "L-008", "L-009", "L-011", "L-012", "L-014"
    )),
    row.names = c(NA, -25L), class = c("tbl_df", "tbl", "data.frame")
  )
  ref6b <- create_id_life.history.table() %>%
    dplyr::filter(clan %in% c("A", "L") & life_stage == "philopatric" & starting_date <= "1996-04-12" & ending_date >= "1996-04-12") %>%
    dplyr::select("ID")
  expect_equal(job6, ref6a)
  expect_equal(job6, ref6b)

  ############

  ### TEST 7: When clan, lifestage, and from/to date are provided, return all individuals that were of that lifestage and clan at any point during the time span.
  # i.e. the intervals overlap
  job7 <- create_id_starting.table(clan = c("A", "L"), lifestage = "philopatric", from = "1996-04-12", to = "1996-08-31")
  ref7a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-008", "A-009", "A-013", "A-014", "A-015", "A-016",
      "A-017", "A-020", "A-040", "L-001", "L-002", "L-003", "L-004",
      "L-005", "L-006", "L-007", "L-008", "L-009", "L-010", "L-011",
      "L-012", "L-013", "L-014", "L-015"
    )),
    row.names = c(NA, -30L), class = c("tbl_df", "tbl", "data.frame")
  )
  test_interval <- lubridate::interval(
    start = "1996-04-12",
    end = "1996-08-31"
  )
  ref7b <- create_id_life.history.table() %>%
    dplyr::filter(clan %in% c("A", "L") & life_stage == "philopatric") %>%
    dplyr::mutate(interval = lubridate::interval(
      start = starting_date,
      end = ending_date
    )) %>%
    dplyr::filter(lubridate::int_overlaps(test_interval, interval)) %>%
    dplyr::select("ID")

  expect_equal(job7, ref7a)
  expect_equal(job7, ref7b)
})

test_that("create_id_starting.table works with different values of clan.overlap", {
  ############

  ### TEST 8: When clan.overlap = "start" w/ from/to, return all individuals that started being in the clan at this point
  # This may be cubs born or dispersers
  job8 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "start")
  ref8a <- structure(
    list(ID = c(
      "A-011", "A-042", "A-044", "A-045", "A-047",
      "A-048", "A-050", "A-051", "A-055", "A-080", "A-081", "A-086",
      "A-087", "A-088", "A-089", "A-090", "A-091", "A-092", "A-093",
      "A-094", "A-095", "A-096", "A-097", "A-098", "A-099", "A-100",
      "A-114", "M-051", "M-053", "S-043"
    )),
    row.names = c(NA, -30L), class = c("tbl_df", "tbl", "data.frame")
  )

  ref8b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    # Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$first_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job8, ref8a)
  expect_equal(job8, ref8b)

  ############

  ### TEST 9: When clan.overlap = "end" w/ from/to, return all individuals that ended being in the clan at this point
  # This may be cubs born or dispersers
  job9 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "end")
  ref9a <- structure(list(ID = c("A-007", "A-043", "A-044", "A-049", "A-058", "A-082")),
    row.names = c(NA, -6L), class = c("tbl_df", "tbl", "data.frame")
  )

  ref9b <- create_id_life.history.table() %>%
    dplyr::filter(life_stage != "dead") %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    # Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$last_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job9, ref9a)
  expect_equal(job9, ref9b)

  ############

  ### TEST 10: When clan.overlap = "always" w/ from/to, return all individuals that were always in the clan during this period
  job10 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "always")
  ref10a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-008", "A-009", "A-010", "A-011", "A-013", "A-014", "A-015",
      "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
      "A-042", "A-045", "A-046", "A-047", "A-048", "A-050", "A-051",
      "A-052", "A-053", "A-054", "A-056", "A-057", "A-083", "A-084",
      "A-085", "A-113", "M-053"
    )),
    row.names = c(NA, -36L), class = c("tbl_df", "tbl", "data.frame")
  )

  ref10b <- create_id_life.history.table() %>%
    dplyr::filter(life_stage != "dead") %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    # Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(
      first_date = min(.data$starting_date),
      last_date = max(.data$ending_date),
      .groups = "drop"
    ) %>%
    dplyr::filter(.data$first_date <= "1996-04-12" & .data$last_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job10, ref10a)
  expect_equal(job10, ref10b)

  ############

  ### TEST 11: When clan.overlap = "within" w/ from/to, return all individuals that were always in the clan during this period
  job11 <- create_id_starting.table(clan = "A", from = "1996-04-12", to = "1997-12-30", clan.overlap = "within")
  ref11a <- structure(list(ID = c("A-044")),
    row.names = c(NA, -1L), class = c("tbl_df", "tbl", "data.frame")
  )

  ref11b <- create_id_life.history.table() %>%
    dplyr::filter(life_stage != "dead") %>%
    dplyr::mutate(grouped_clan = .data$clan %in% "A") %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped_clan) != 0))) %>%
    # Now that we have determined unique groups, we can remove FALSES (i.e. non-focal groups)
    dplyr::filter(.data$grouped_clan) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(
      first_date = min(.data$starting_date),
      last_date = max(.data$ending_date),
      .groups = "drop"
    ) %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job11, ref11a)
  expect_equal(job11, ref11b)

  ############

  ### TEST 12: When we give clan and clan.birth w/ from/to, return all individuals that were alive at any point between from/to AND were born in focal clan
  job12 <- create_id_starting.table(clan = "A", clan.birth = "A", from = "1996-04-12", to = "1997-12-30")
  ref12a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
      "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
      "A-043", "A-046", "A-049", "A-052", "A-053", "A-054", "A-056",
      "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
      "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
      "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
      "A-099", "A-100", "A-113", "A-114"
    )),
    row.names = c(NA, -51L), class = c("tbl_df", "tbl", "data.frame")
  )

  ref12b <- extract_database_table("hyenas") %>%
    dplyr::filter(.data$birthclan == "A") %>%
    dplyr::left_join(relationship = "many-to-many", extract_database_table("deaths"), by = "ID") %>%
    dplyr::filter(.data$birthdate <= as.Date("1997-12-30") & (is.na(.data$deathdate) | .data$deathdate >= as.Date("1996-04-12"))) %>%
    dplyr::select("ID")
  expect_equal(job12, ref12a)
  expect_equal(job12, ref12b)

  ############

  ### TEST 13: When we provide both clan.birth, clan and lifestage is given w/ from/to, return all individuals that were in this lifestage at any point between from/to AND were born in focal clan
  job13 <- create_id_starting.table(
    clan.birth = "A", clan = "L", from = "1997-01-01", to = "1997-12-31",
    lifestage = "disperser", lifestage.overlap = "any"
  )
  ref13a <- structure(list(ID = "A-049"),
    row.names = c(NA, -1L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref13b <- create_id_life.history.table() %>%
    dplyr::filter(clan == "L" & life_stage == "disperser" & fetch_id_clan.birth(ID) == "A") %>%
    dplyr::filter(.data$starting_date <= "1997-12-31" & .data$ending_date >= "1997-01-01") %>%
    dplyr::select("ID")
  expect_equal(job13, ref13a)
  expect_equal(job13, ref13b)
})

test_that("create_id_starting.table works with lifestage.overlap 'start'", {
  ############

  ### TEST 14: When lifestage.overlap = "start"  w/ from/to, return all individuals that started being in this lifestage in all clans at this point
  job14 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start")
  ref14a <- structure(
    list(ID = c(
      "A-040", "A-041", "A-046", "A-049", "A-054",
      "A-056", "A-084", "A-085", "A-113", "L-046", "L-082", "L-083",
      "L-089"
    )),
    row.names = c(NA, -13L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref14b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$starting_date >= "1996-04-12" & .data$starting_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job14, ref14a)
  expect_equal(job14, ref14b)

  ############

  ### TEST 15: When lifestage.overlap = "start" and we use multiple lifestages w/ from/to, return all individuals that started being in any of these lifestages in all clans at this point
  job15 <- create_id_starting.table(
    lifestage = c("subadult", "natal"),
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start"
  )
  ref15a <- structure(
    list(ID = c(
      "A-054", "A-058", "A-080", "A-081", "A-083",
      "A-084", "A-085", "A-086", "A-087", "A-088", "A-089", "A-092",
      "A-093", "A-095", "A-113", "L-080", "L-081", "L-082", "L-083",
      "L-084", "L-085", "L-086", "L-087", "L-088", "L-089", "L-090",
      "L-093"
    )),
    row.names = c(NA, -27L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref15b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$first_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job15, ref15a)
  expect_equal(job15, ref15b)

  ############

  ### TEST 16: When lifestage.overlap = "start" and we use multiple lifestages w/ from/to, return all individuals that started being in any of these lifestages in all clans at this point
  job16 <- create_id_starting.table(
    lifestage = "adult",
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "start"
  )
  ref16a <- structure(
    list(ID = c(
      "A-008", "A-010", "A-018", "A-019", "A-040",
      "A-041", "A-046", "A-049", "A-054", "A-056", "A-084", "A-085",
      "A-113", "L-010", "L-013", "L-015", "L-046", "L-082", "L-083",
      "L-088", "L-089"
    )),
    row.names = c(NA, -21L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref16b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c(
      "disperser",
      "foreigner",
      "natal",
      "unknown",
      "philopatric",
      "selector_2",
      "selector_3",
      "selector_4",
      "selector_5",
      "transient",
      "founder_male",
      "foreigner_2",
      "foreigner_3",
      "foreigner_4",
      "foreigner_5"
    )) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(first_date = min(.data$starting_date), .groups = "drop") %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$first_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job16, ref16a)
  expect_equal(job16, ref16b)
})

test_that("create_id_starting.table works with lifestage.overlap 'end'", {
  ############

  ### TEST 17: When lifestage.overlap = "end"  w/ from/to, return all individuals that ended being in this lifestage in all clans at this point
  job17 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "end")
  ref17a <- structure(
    list(ID = c(
      "A-040", "A-043", "A-049", "M-047", "M-051",
      "N-043", "S-043"
    )),
    row.names = c(NA, -7L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref17b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$ending_date >= "1996-04-12" & .data$ending_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job17, ref17a)
  expect_equal(job17, ref17b)

  ############

  ### TEST 18: When lifestage.overlap = "end" and we use multiple lifestage w/ from/to, return all individuals that ended being in any of these lifestages in all clans at this point
  job18 <- create_id_starting.table(
    lifestage = c("subadult", "natal"),
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "end"
  )
  ref18a <- structure(
    list(ID = c(
      "A-008", "A-010", "A-018", "A-019", "A-040",
      "A-043", "A-049", "A-058", "L-010", "L-013", "L-015",
      "L-049", "L-088", "M-047", "M-051", "N-043", "S-043"
    )),
    row.names = c(NA, -17L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref18b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$last_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job18, ref18a)
  expect_equal(job18, ref18b)

  ############

  ### TEST 19: When lifestage.overlap = "end" and we use meta-lifestage w/ from/to, return all individuals that ended being in any of these lifestages in all clans at this point
  job19 <- create_id_starting.table(
    lifestage = "adult",
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "end"
  )
  ref19a <- structure(
    list(ID = c(
      "A-007", "A-043", "A-044", "L-006", "L-007",
      "L-043", "S-002"
    )),
    row.names = c(NA, -7L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref19b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c(
      "disperser",
      "foreigner",
      "natal",
      "philopatric",
      "selector_2",
      "selector_3",
      "selector_4",
      "selector_5",
      "transient",
      "founder_male",
      "foreigner_2",
      "foreigner_3",
      "foreigner_4",
      "foreigner_5"
    )) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(last_date = max(.data$ending_date), .groups = "drop") %>%
    dplyr::filter(.data$last_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job19, ref19a)
  expect_equal(job19, ref19b)
})

test_that("create_id_starting.table works with lifestage.overlap 'always'", {
  ############

  ### TEST 20: When lifestage.overlap = "always"  w/ from/to, return all individuals that were always in this lifestage in all clans at this point
  job20 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "always")
  ref20a <- structure(list(ID = c("A-052", "A-053", "A-057", "L-044", "L-045")),
    row.names = c(NA, -5L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref20b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$starting_date <= "1996-04-12" & .data$ending_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job20, ref20a)
  expect_equal(job20, ref20b)

  ############

  ### TEST 21: When lifestage.overlap = "always" and we use multiple lifestage w/ from/to, return all individuals that were always in one of these lifestages in all clans at this point
  job21 <- create_id_starting.table(
    lifestage = c("subadult", "natal"),
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "always"
  )
  ref21a <- structure(
    list(ID = c(
      "A-041", "A-046", "A-052", "A-053", "A-056",
      "A-057", "L-044", "L-045", "L-046"
    )),
    row.names = c(NA, -9L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref21b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(
      first_date = min(.data$starting_date),
      last_date = max(.data$ending_date), .groups = "drop"
    ) %>%
    dplyr::filter(.data$first_date <= "1996-04-12" & .data$last_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job21, ref21a)
  expect_equal(job21, ref21b)

  ############

  ### TEST 22: When lifestage.overlap = "always" and we use meta-lifestage w/ from/to, return all individuals that were always in one of these lifestages in all clans at this point
  job22 <- create_id_starting.table(
    lifestage = "adult",
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "always"
  )
  ref22a <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-009", "A-011", "A-013", "A-014", "A-015", "A-016", "A-017",
      "A-020", "A-040", "A-042", "A-045", "A-047", "A-048", "A-050",
      "A-051", "A-052", "A-053", "A-055", "A-057", "L-001", "L-002", "L-003",
      "L-004", "L-005", "L-008", "L-009", "L-011", "L-012", "L-014",
      "L-040", "L-041", "L-042", "L-044", "L-045", "L-047", "L-048",
      "M-004", "M-047", "M-051", "M-053", "N-043", "S-043"
    )),
    row.names = c(NA, -47L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref22b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c(
      "disperser",
      "foreigner",
      "natal",
      "unknown",
      "philopatric",
      "selector_2",
      "selector_3",
      "selector_4",
      "selector_5",
      "transient",
      "founder_male",
      "foreigner_2",
      "foreigner_3",
      "foreigner_4",
      "foreigner_5"
    )) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(
      first_date = min(.data$starting_date),
      last_date = max(.data$ending_date), .groups = "drop"
    ) %>%
    dplyr::filter(.data$first_date <= "1996-04-12" & .data$last_date >= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job22, ref22a)
  expect_equal(job22, ref22b)
})

test_that("create_id_starting.table works with lifestage.overlap 'within'", {
  ############

  ### TEST 23: When lifestage.overlap = "within"  w/ from/to, return all individuals that started and ended in this lifestage in all clans at this point
  job23 <- create_id_starting.table(lifestage = "natal", from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "within")
  ref23a <- structure(list(ID = c("A-040", "A-049")),
    row.names = c(NA, -2L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref23b <- create_id_life.history.table() %>%
    dplyr::filter(.data$life_stage == "natal") %>%
    dplyr::filter(.data$starting_date >= "1996-04-12" & .data$ending_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job23, ref23a)
  expect_equal(job23, ref23b)

  ############

  ### TEST 24: When lifestage.overlap = "within" and we use multiple lifestage w/ from/to, return all individuals that started and ended in all of these lifestages in all clans at this point
  job24 <- create_id_starting.table(
    lifestage = c("subadult", "natal"),
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "within"
  )
  ref24a <- structure(list(ID = c("A-058", "L-088")),
    row.names = c(NA, -2L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref24b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c("subadult", "natal")) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(
      first_date = min(.data$starting_date),
      last_date = max(.data$ending_date), .groups = "drop"
    ) %>%
    dplyr::filter(.data$first_date >= "1996-04-12" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job24, ref24a)
  expect_equal(job24, ref24b)

  ############

  ### TEST 25: When lifestage.overlap = "within" and we use meta-lifestage w/ from/to, return all individuals that started and ended in all of these lifestages in all clans at this point
  job25 <- create_id_starting.table(
    lifestage = "adult",
    from = "1992-01-01", to = "1997-12-30", lifestage.overlap = "within"
  )
  ref25a <- structure(list(ID = c("A-043", "L-006", "L-043")),
    row.names = c(NA, -3L),
    class = c("tbl_df", "tbl", "data.frame")
  )

  ref25b <- create_id_life.history.table() %>%
    dplyr::mutate(grouped = .data$life_stage %in% c(
      "disperser",
      "foreigner",
      "natal",
      "unknown",
      "philopatric",
      "selector_2",
      "selector_3",
      "selector_4",
      "selector_5",
      "transient",
      "founder_male",
      "foreigner_2",
      "foreigner_3",
      "foreigner_4",
      "foreigner_5"
    )) %>%
    dplyr::mutate(group_val = cumsum(c(1, diff(.data$grouped) != 0))) %>%
    dplyr::filter(.data$grouped) %>%
    dplyr::group_by(.data$ID, .data$group_val) %>%
    dplyr::summarise(
      first_date = min(.data$starting_date),
      last_date = max(.data$ending_date), .groups = "drop"
    ) %>%
    dplyr::filter(.data$first_date >= "1992-01-01" & .data$last_date <= "1997-12-30") %>%
    dplyr::select("ID")
  expect_equal(job25, ref25a)
  expect_equal(job25, ref25b)
})

test_that("create_id_starting.table deals properly with sex and death", {
  ############

  ### TEST 26: When sex is specified same output but sex is filtered.
  job26a <- create_id_starting.table(
    lifestage = c("subadult", "natal"),
    from = "1996-04-12", to = "1997-12-30", lifestage.overlap = "within",
    sex = "male"
  )
  # Take ref24a as our starting point
  ref26a <- structure(list(ID = c("A-058", "L-088")),
    row.names = c(NA, -2L),
    class = c("tbl_df", "tbl", "data.frame")
  ) %>%
    dplyr::mutate(sex = fetch_id_sex(ID = .data$ID)) %>%
    dplyr::filter(sex == "male") %>%
    dplyr::select("ID")
  expect_equal(job26a, ref26a)

  job26b <- create_id_starting.table(clan.birth = "A", sex = "male")
  # Take ref3a as our starting point (create_id_starting.table(clan.birth = "A"))
  ref26b <- structure(
    list(ID = c(
      "A-001", "A-002", "A-003", "A-004", "A-006",
      "A-007", "A-008", "A-009", "A-010", "A-013", "A-014", "A-015",
      "A-016", "A-017", "A-018", "A-019", "A-020", "A-040", "A-041",
      "A-043", "A-046", "A-049", "A-052", "A-053", "A-054", "A-056",
      "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
      "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
      "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
      "A-099", "A-100", "A-113", "A-114"
    )),
    row.names = c(NA, -51L),
    class = c("tbl_df", "tbl", "data.frame")
  ) %>%
    dplyr::mutate(sex = fetch_id_sex(ID = .data$ID)) %>%
    dplyr::filter(sex == "male") %>%
    dplyr::select("ID")
  expect_equal(job26b, ref26b)

  ############

  ### TEST 27: When lifestage = "dead" with at, will return all individuals that have died in this clan up to and including this date.
  job27 <- create_id_starting.table(lifestage = "dead", at = "1997-01-01")
  ref27a <- structure(
    list(ID = c(
      "A-007", "A-043", "A-044", "A-058", "A-082",
      "L-006", "L-007", "L-043", "L-049", "L-091", "L-092", "S-002"
    )),
    row.names = c(NA, -12L), class = c("tbl_df", "tbl", "data.frame")
  )
  ref27b <- extract_database_table("deaths") %>%
    dplyr::filter(.data$deathdate <= "1997-01-01") %>%
    dplyr::select("ID")
  expect_identical(job27, ref27a)
  expect_identical(job27, ref27b)

  ############

  ### TEST 28: Lifestage "!dead" is the same as when lifestage is not specified.
  job28a <- create_id_starting.table(lifestage = "!dead", at = "1997-01-01")
  job28b <- create_id_starting.table(at = "1997-01-01")
  expect_equal(job28a, job28b)

  ############

  ### TEST 29: Lifestage "!dead" is the same as when lifestage is not specified.
  job29a <- create_id_starting.table(lifestage = "all", at = "1997-01-01") %>%
    dplyr::arrange(.data$ID)
  ref29 <- dplyr::bind_rows(job27, job28a) %>%
    dplyr::arrange(.data$ID)
  expect_equal(job29a, ref29)

  ############

  ### TEST 30: No args or providing from = first birth, to = last sighting should be identical
  job30a <- create_id_starting.table()
  ref30 <- create_id_starting.table(
    from = find_pop_date.birth.first(),
    to = find_pop_date.observation.last()
  )
  expect_equal(job30a, ref30)

  ############

  ### TEST 31: Providing clan with or without default from/to is identical
  job31a <- create_id_starting.table(clan = "A")
  ref31 <- create_id_starting.table(
    clan = "A",
    from = find_pop_date.birth.first(),
    to = find_pop_date.observation.last()
  )
  expect_equal(job31a, ref31)
})


test_that("create_id_offspring.table works as intended", {
  ref <- structure(
    list(
      parentID = c(
        "A-001", "A-001", "A-001", "L-003",
        "A-100", "A-011", "A-058"
      ),
      from = structure(c(8766, 8766, 8766, 8766, 8766, 8766, 8766), class = "Date"),
      to = structure(c(9131, 9131, 9131, 9131, 9131, 9131, 9131), class = "Date"),
      offspringID = c(
        "A-010", "A-018",
        "A-046", NA, NA, NA, NA
      ),
      birthdate = structure(c(9029, 9029, 9029, NA, NA, NA, NA), class = "Date"),
      filiation = c(
        "mother_social_genetic",
        "mother_social_genetic", "mother_social_genetic", NA, NA, NA, NA
      )
    ),
    row.names = c(NA, -7L),
    class = c("tbl_df", "tbl", "data.frame"),
    input = structure(
      list(
        ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
        from = structure(c(8766, 8766, 8766, 8766, 8766), class = "Date"),
        to = structure(c(9131, 9131, 9131, 9131, 9131), class = "Date")
      ),
      class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -5L)
    )
  )
  job <- create_id_offspring.table(
    ID = c("A-001", "L-003", "A-100", "A-011", "A-058"),
    from = "1994-01-01", to = "1995-01-01"
  )
  expect_equal(ref, job)
})


test_that("create_id_offspring.table handles overlap properly", {
  ## reference situation:
  job1 <- create_id_offspring.table(ID = "A-007")
  ref1 <- structure(
    list(
      parentID = "A-007",
      from = structure(3390, class = "Date"),
      to = structure(10226, class = "Date"),
      offspringID = "A-082",
      birthdate = structure(9447, class = "Date"),
      filiation = "mother_social_genetic"
    ),
    row.names = c(NA, -1L),
    class = c("tbl_df", "tbl", "data.frame"),
    input = structure(
      list(
        ID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(10226, class = "Date")
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -1L)
    )
  )
  expect_equal(ref1, job1)

  ## never list offspring if end of interval before birth for the correct overlap arguments:
  ref2 <- structure(
    list(
      parentID = "A-007",
      from = structure(3390, class = "Date"),
      to = structure(9446, class = "Date"),
      offspringID = NA_character_,
      birthdate = structure(NA_real_, class = "Date"),
      filiation = NA_character_
    ),
    row.names = c(NA, -1L),
    class = c("tbl_df", "tbl", "data.frame"),
    input = structure(
      list(
        ID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9446, class = "Date")
      ),
      class = c(
        "tbl_df",
        "tbl", "data.frame"
      ),
      row.names = c(NA, -1L)
    )
  )

  job2a <- create_id_offspring.table(ID = "A-007", to = "1995-11-12", age.overlap = "start")
  job2b <- create_id_offspring.table(ID = "A-007", to = "1995-11-12", age.overlap = "within")
  job2c <- create_id_offspring.table(ID = "A-007", to = "1995-11-12", age.overlap = "end")
  job2d <- create_id_offspring.table(ID = "A-007", to = "1995-11-12", age.overlap = "always")
  job2e <- create_id_offspring.table(ID = "A-007", to = "1995-11-12", age.overlap = "any")
  expect_equal(ref2, job2a)
  expect_equal(ref2, job2b)
  expect_equal(ref2, job2c)
  expect_equal(ref2, job2d)
  expect_equal(ref2, job2e)

  ## list offspring if start of interval after birth only for the correct overlap arguments:
  ref3_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(9448, class = "Date"),
        to = structure(10226, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(9448, class = "Date"),
          to = structure(10226, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ),
        row.names = c(NA, -1L)
      )
    )

  ref3_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(9448, class = "Date"),
        to = structure(10226, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(9448, class = "Date"),
          to = structure(10226, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ),
        row.names = c(NA, -1L)
      )
    )

  job3a <- create_id_offspring.table(ID = "A-007", from = "1995-11-14", age.overlap = "start")
  job3b <- create_id_offspring.table(ID = "A-007", from = "1995-11-14", age.overlap = "within")
  job3c <- create_id_offspring.table(ID = "A-007", from = "1995-11-14", age.overlap = "end")
  job3d <- create_id_offspring.table(ID = "A-007", from = "1995-11-14", age.overlap = "always")
  job3e <- create_id_offspring.table(ID = "A-007", from = "1995-11-14", age.overlap = "any")

  expect_equal(ref3_nooffspring, job3a)
  expect_equal(ref3_nooffspring, job3b)
  expect_equal(ref3_withoffspring, job3c)
  expect_equal(ref3_withoffspring, job3d)
  expect_equal(ref3_withoffspring, job3e)

  ## list offspring if start of interval before birth only for the correct overlap arguments:
  ref4_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(9446, class = "Date"),
        to = structure(10226, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(9446, class = "Date"),
          to = structure(10226, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ),
        row.names = c(NA, -1L)
      )
    )

  ref4_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(9446, class = "Date"),
        to = structure(10226, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(9446, class = "Date"),
          to = structure(10226, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ),
        row.names = c(NA, -1L)
      )
    )

  job4a <- create_id_offspring.table(ID = "A-007", from = "1995-11-12", age.overlap = "start")
  job4b <- create_id_offspring.table(ID = "A-007", from = "1995-11-12", age.overlap = "within")
  job4c <- create_id_offspring.table(ID = "A-007", from = "1995-11-12", age.overlap = "end")
  job4d <- create_id_offspring.table(ID = "A-007", from = "1995-11-12", age.overlap = "always")
  job4e <- create_id_offspring.table(ID = "A-007", from = "1995-11-12", age.overlap = "any")

  expect_equal(ref4_withoffspring, job4a)
  expect_equal(ref4_withoffspring, job4b)
  expect_equal(ref4_withoffspring, job4c)
  expect_equal(ref4_nooffspring, job4d)
  expect_equal(ref4_withoffspring, job4e)

  ## list offspring if end of interval before a age.max alive for the correct overlap arguments:

  ref5_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9628, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9628, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  ref5_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9628, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9628, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  job5a <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-12", age.overlap = "start")
  job5b <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-12", age.overlap = "within")
  job5c <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-12", age.overlap = "end")
  job5d <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-12", age.overlap = "always")
  job5e <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-12", age.overlap = "any")

  expect_equal(ref5_withoffspring, job5a)
  expect_equal(ref5_nooffspring, job5b)
  expect_equal(ref5_nooffspring, job5c)
  expect_equal(ref5_nooffspring, job5d)
  expect_equal(ref5_withoffspring, job5e)

  ## list offspring if end of interval after a age.max alive for the correct overlap arguments:

  ref6_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9630, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9630, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  ref6_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9630, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9630, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  job6a <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-14", age.overlap = "start")
  job6b <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-14", age.overlap = "within")
  job6c <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-14", age.overlap = "end")
  job6d <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-14", age.overlap = "always")
  job6e <- create_id_offspring.table(ID = "A-007", age.max = 6, unit = "month", to = "1996-05-14", age.overlap = "any")

  expect_equal(ref6_withoffspring, job6a)
  expect_equal(ref6_withoffspring, job6b)
  expect_equal(ref6_withoffspring, job6c)
  expect_equal(ref6_nooffspring, job6d)
  expect_equal(ref6_withoffspring, job6e)

  ## list offspring if death occurs within the interval and age.max = Inf for the correct overlap arguments:
  ref7_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9699, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9699, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  ref7_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9699, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9699, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  job7a <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.overlap = "start")
  job7b <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.overlap = "within")
  job7c <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.overlap = "end")
  job7d <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.overlap = "always")
  job7e <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.overlap = "any")

  expect_equal(ref7_withoffspring, job7a)
  expect_equal(ref7_nooffspring, job7b)
  expect_equal(ref7_nooffspring, job7c)
  expect_equal(ref7_nooffspring, job7d)
  expect_equal(ref7_withoffspring, job7e)

  ## list offspring if death occurs within the interval and age.max earlier than death for the correct overlap arguments:
  ref8_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9699, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9699, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  ref8_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9699, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9699, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ),
        row.names = c(NA, -1L)
      )
    )

  job8a <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 6, unit = "month", age.overlap = "start")
  job8b <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 6, unit = "month", age.overlap = "within")
  job8c <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 6, unit = "month", age.overlap = "end")
  job8d <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 6, unit = "month", age.overlap = "always")
  job8e <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 6, unit = "month", age.overlap = "any")

  expect_equal(ref8_withoffspring, job8a)
  expect_equal(ref8_withoffspring, job8b)
  expect_equal(ref8_withoffspring, job8c)
  expect_equal(ref8_nooffspring, job8d)
  expect_equal(ref8_withoffspring, job8e)

  ## list offspring if death occurs within the interval and age.max later than end of interval for the correct overlap arguments:
  ref9_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9699, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9699, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  ref9_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9699, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9699, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ),
        row.names = c(NA, -1L)
      )
    )

  job9a <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 12, unit = "month", age.overlap = "start")
  job9b <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 12, unit = "month", age.overlap = "within")
  job9c <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 12, unit = "month", age.overlap = "end")
  job9d <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 12, unit = "month", age.overlap = "always")
  job9e <- create_id_offspring.table(ID = "A-007", to = "1996-07-22", age.max = 12, unit = "month", age.overlap = "any")

  expect_equal(ref9_withoffspring, job9a)
  expect_equal(ref9_nooffspring, job9b)
  expect_equal(ref9_nooffspring, job9c)
  expect_equal(ref9_nooffspring, job9d)
  expect_equal(ref9_withoffspring, job9e)

  ## list offspring if death occurs after the interval and age.max later than death for the correct overlap arguments:
  ref10_withoffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9696, class = "Date"),
        offspringID = "A-082",
        birthdate = structure(9447, class = "Date"),
        filiation = "mother_social_genetic"
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9696, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ),
        row.names = c(NA, -1L)
      )
    )

  ref10_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(3390, class = "Date"),
        to = structure(9696, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(3390, class = "Date"),
          to = structure(9696, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  job10a <- create_id_offspring.table(ID = "A-007", to = "1996-07-19", age.max = 12, unit = "month", age.overlap = "start")
  job10b <- create_id_offspring.table(ID = "A-007", to = "1996-07-19", age.max = 12, unit = "month", age.overlap = "within")
  job10c <- create_id_offspring.table(ID = "A-007", to = "1996-07-19", age.max = 12, unit = "month", age.overlap = "end")
  job10d <- create_id_offspring.table(ID = "A-007", to = "1996-07-19", age.max = 12, unit = "month", age.overlap = "always")
  job10e <- create_id_offspring.table(ID = "A-007", to = "1996-07-19", age.max = 12, unit = "month", age.overlap = "any")

  expect_equal(ref10_withoffspring, job10a)
  expect_equal(ref10_nooffspring, job10b)
  expect_equal(ref10_nooffspring, job10c)
  expect_equal(ref10_nooffspring, job10d)
  expect_equal(ref10_withoffspring, job10e)

  ## never list offspring if death occurs before the interval even if age.max is in the interval:
  ref11_nooffspring <-
    structure(
      list(
        parentID = "A-007",
        from = structure(9698, class = "Date"),
        to = structure(10226, class = "Date"),
        offspringID = NA_character_,
        birthdate = structure(NA_real_, class = "Date"),
        filiation = NA_character_
      ),
      row.names = c(
        NA,
        -1L
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      input = structure(
        list(
          ID = "A-007",
          from = structure(9698, class = "Date"),
          to = structure(10226, class = "Date")
        ),
        class = c(
          "tbl_df",
          "tbl", "data.frame"
        ), row.names = c(NA, -1L)
      )
    )

  job11a <- create_id_offspring.table(ID = "A-007", from = "1996-07-21", age.max = 12, unit = "month", age.overlap = "start")
  job11b <- create_id_offspring.table(ID = "A-007", from = "1996-07-21", age.max = 12, unit = "month", age.overlap = "within")
  job11c <- create_id_offspring.table(ID = "A-007", from = "1996-07-21", age.max = 12, unit = "month", age.overlap = "end")
  job11d <- create_id_offspring.table(ID = "A-007", from = "1996-07-21", age.max = 12, unit = "month", age.overlap = "always")
  job11e <- create_id_offspring.table(ID = "A-007", from = "1996-07-21", age.max = 12, unit = "month", age.overlap = "any")

  expect_equal(ref11_nooffspring, job11a)
  expect_equal(ref11_nooffspring, job11b)
  expect_equal(ref11_nooffspring, job11c)
  expect_equal(ref11_nooffspring, job11d)
  expect_equal(ref11_nooffspring, job11e)
})


test_that("create_id_offspring.count returns output as intended", {
  ref <- structure(
    list(
      parentID = c("A-001", "A-008"),
      n_females = c(
        3L,
        NA
      ),
      n_males = c(3L, NA),
      n_unknown = c(0L, NA)
    ),
    row.names = 1:2,
    class = c(
      "tbl_df",
      "tbl", "data.frame"
    )
  )
  job <- create_id_offspring.count(ID = c("A-001", "A-008"))
  expect_equal(ref, job)
})


test_that("create_id_mate.conception.table returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "A-001", "A-001", "A-001", "A-098", "L-003"),
      mate = c("A-045", NA, NA, NA, NA, "L-043"),
      date = structure(c(8919, 8919, 9301, 9732, NA, 9240), class = "Date")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -6L)
  )
  job <- create_id_mate.conception.table(c("A-001", "L-003", "A-098"))
  expect_identical(ref, job)
})

test_that("create_id_selection.history returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "L-094"),
      clan = c("A", "L"),
      starting_date = structure(c(6715, 9896), class = "Date"),
      ending_date = structure(c(10226, 10226), class = "Date")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -2L)
  )
  job <- create_id_selection.history(c("A-001", "L-094"), censored.to.last.sighting = TRUE)
  expect_identical(ref, job)

  ref2 <-
    structure(
      list(
        ID = c("A-001", "L-094"),
        clan = c("A", "L"),
        starting_date = structure(c(6715, 9896), class = "Date"),
        ending_date = structure(c(NA_real_, NA_real_), class = "Date")
      ),
      class = c(
        "tbl_df",
        "tbl", "data.frame"
      ),
      row.names = c(NA, -2L)
    )

  job2 <- create_id_selection.history(c("A-001", "L-094"), censored.to.last.sighting = FALSE)
  expect_identical(ref2, job2)
})

test_that("create_id_life.transition.table returns the correct output", {
  ref <- structure(
    list(
      ID = c("A-001", "A-001", "A-008", "A-008", "A-044", "A-044"),
      origin = c("W", "A", "W", "A", "W", "X"),
      destination = c("A", "A", "A", "A", "X", "A"),
      date = structure(c(6715, 7445, 8906, 9636, 5254, 9598), class = "Date")
    ),
    row.names = c(NA, -6L), class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_id_life.transition.table(c("A-001", "A-008", "A-044"))
  expect_identical(ref, job)
})

test_that("create_sighting_starting.table returns output as intended", {
  ref <- structure(
    list(
      ID = c("A-001", "A-002", "A-002"),
      sighting_time = structure(c(857977740, 857977740, 857979360),
        class = c("POSIXct", "POSIXt"),
        tzone = "Africa/Dar_es_Salaam"
      ),
      latitude = c(-3.14017, -3.14017, -3.1415),
      longitude = c(35.50417, 35.50417, 35.50333),
      sighting_clan = c("A", "A", "A")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -3L)
  )
  job <- create_sighting_starting.table(ID = c("A-001", "A-002"), from = "1997-03-01", to = "1997-03-10")
  expect_equal(ref, job)

  # Check that time zone is dealt with correctly
  ref <- recode_x_date("1997-09-19")

  job <- create_sighting_starting.table(ID = "L-004", to = "1997-09-19") %>%
    dplyr::slice(dplyr::n()) %>%
    dplyr::pull(sighting_time) %>%
    recode_x_date()

  expect_true(job <= ref)
})

test_that("'include.conceptions' works as expected in create_sighting_starting.table", {
  default <- structure(
    list(
      ID = c("A-013", "A-013"),
      sighting_time = structure(c(868953600, 869978940),
        tzone = "Africa/Dar_es_Salaam",
        class = c("POSIXct", "POSIXt")
      ),
      latitude = c(-3.13867, -3.16267),
      longitude = c(35.5065, 35.49317),
      sighting_clan = c("A", "A")
    ),
    row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame")
  )

  conception_included <- structure(
    list(
      ID = c("A-013", "A-013", "A-013"),
      sighting_time = structure(c(862779600, 868953600, 869978940),
        tzone = "Africa/Dar_es_Salaam",
        class = c("POSIXct", "POSIXt")
      ),
      latitude = c(NA, -3.13867, -3.16267),
      longitude = c(NA, 35.5065, 35.49317),
      sighting_clan = c("A", "A", "A")
    ),
    row.names = c(NA, -3L), class = c("tbl_df", "tbl", "data.frame")
  )

  job1 <- create_sighting_starting.table(ID = "A-013", from = "1997-05-01", to = "1997-08-01")
  job2 <- create_sighting_starting.table(ID = "A-013", from = "1997-05-01", to = "1997-08-01", include.conception = TRUE)

  expect_equal(default, job1)
  expect_equal(conception_included, job2)
})

test_that("create_sample_starting.table works with dates provided", {
  ref <- structure(list(
    ID = c(
      "L-043", "L-043", "L-043",
      "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
      "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
      "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
      "L-043"
    ),
    sampleID = c(
      "N0001", "N0002a",
      "N0002", "N0003a", "N0003", "N0004a", "N0004", "N0005a", "N0005",
      "N0006a", "N0006", "N0007", "N0008a", "N0008b", "N0008c", "N0008d",
      "N0009a", "N0009b", "N0009", "N0010b", "N0010", "N0011", "N0012",
      "N0013", "N0014"
    ),
    collection_time = structure(c(
      838744200, 838736640, 838744200, 838737000, 838744200,
      838740600, 838744200, 838740600, 838744200, 838740600, 838744200,
      838738800, 838749600, 838746000, 838746000, 838746000, 838749600,
      838749600, 838749600, 838749600, 838749600, 838751400, 838739700,
      838745100, 838735200
    ), class = c("POSIXct", "POSIXt"), tzone = "UTC"),
    type = c(
      "testicle", "liver", "liver",
      "spleen", "spleen", "salivary gland", "salivary gland", "lymph node",
      "lymph node", "tonsil", "tonsil", "voice box", "muscle",
      "muscle", "muscle", "muscle", "brain", "brain", "brain",
      "blood", "CSF", "eye", "tongue", "gland", "penis"
    ),
    treatment = c(
      "liq N", "10% Form", "liq N", "10% Form", "liq N",
      "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
      "10% Form", "liq N", "Ethanol", "Ethanol", "10% Form", "glycerol",
      "glycerol", "liq N", "liq N", "liq N", "10% Form", "10% Form",
      "10% Form", "10% Form"
    )
  ), class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -25L))

  job <- create_sample_starting.table(
    from = "1996-07-01",
    to = "1996-08-01", verbose = FALSE
  )

  ref2 <- structure(
    list(
      ID = c(
        "L-043", "L-043", "L-043", "L-043", "L-043",
        "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
        "L-043", "L-043", "L-043", "L-043", "L-043", "L-043", "L-043",
        "L-043", "L-043", "L-043", "L-043", "L-043", "L-043"
      ),
      sampleID = c(
        "N0001",
        "N0002a", "N0002", "N0003a", "N0003", "N0004a", "N0004", "N0005a",
        "N0005", "N0006a", "N0006", "N0007", "N0008a", "N0008b", "N0008c",
        "N0008d", "N0009a", "N0009b", "N0009", "N0010b", "N0010", "N0011",
        "N0012", "N0013", "N0014"
      ),
      collection_time = structure(c(
        838744200,
        838736640, 838744200, 838737000, 838744200, 838740600, 838744200,
        838740600, 838744200, 838740600, 838744200, 838738800, 838749600,
        838746000, 838746000, 838746000, 838749600, 838749600, 838749600,
        838749600, 838749600, 838751400, 838739700, 838745100, 838735200
      ), class = c("POSIXct", "POSIXt"), tzone = "UTC"),
      type = c(
        "testicle",
        "liver", "liver", "spleen", "spleen", "salivary gland", "salivary gland",
        "lymph node", "lymph node", "tonsil", "tonsil", "voice box",
        "muscle", "muscle", "muscle", "muscle", "brain", "brain", "brain",
        "blood", "CSF", "eye", "tongue", "gland", "penis"
      ),
      treatment = c(
        "liq N",
        "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
        "10% Form", "liq N", "10% Form", "liq N", "10% Form", "liq N",
        "Ethanol", "Ethanol", "10% Form", "glycerol", "glycerol", "liq N",
        "liq N", "liq N", "10% Form", "10% Form", "10% Form", "10% Form"
      )
    ),
    class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -25L)
  )

  job2 <- create_sample_starting.table(ID = "L-043", verbose = FALSE)

  expect_equal(ref, job)
  expect_equal(ref2, job2)
})

test_that("create_clan_obsv.effort.table returns the correct output", {
  expect_equal(class(create_clan_obsv.effort.table(clan = "A", from = "1997/01/01", to = "1997/12/01"))[1], "tbl_df")

  ref <- structure(
    list(
      clan = c("A", "L"),
      from = structure(c(10074, 10074), class = "Date"),
      to = structure(c(10105, 10105), class = "Date"),
      effort_adult = c(11 / 34, 21 / 26),
      effort_cub = c(10 / 23, 16 / 20),
      effort_all = c(21 / 57, 37 / 46)
    ),
    row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame")
  )

  # We keep the new argument just to make sure we can compare new & and old method
  job <- create_clan_obsv.effort.table(clan = c("A", "L"), from = "1997-08-01", to = "1997-09-01")
  expect_equal(ref, job)
})

test_that("create_cervus_input works as intended", {
  # Works with standard and multiple individuals
  ref <- structure(
    list(
      offspringID = c(
        "A-008",
        "A-001",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086"
      ),
      sex = c(
        "female",
        "female",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male",
        "male"
      ),
      motherID = c(
        "A-015",
        NA,
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014",
        "A-014"
      ),
      birthdate = structure(
        c(
          8906,
          6715,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797,
          9797
        ),
        class = "Date"
      ),
      clan.conception = c(
        "A",
        NA, "A", "A", "A", "A", "A", "A", "A", "A", "A", "A", "A"
      ),
      potential.fatherID = c(
        NA,
        NA,
        "A-011",
        "A-040",
        "A-042",
        "A-044",
        "A-045",
        "A-047",
        "A-048",
        "A-050",
        "A-051",
        "A-055",
        "M-053"
      ),
      genotyped = c(
        NA,
        NA,
        TRUE,
        TRUE,
        TRUE,
        FALSE,
        TRUE,
        FALSE,
        TRUE,
        TRUE,
        TRUE,
        FALSE,
        TRUE
      ),
      index.candidate = c(
        "candidate1",
        "candidate1",
        "candidate1",
        "candidate2",
        "candidate3",
        "candidate4",
        "candidate5",
        "candidate6",
        "candidate7",
        "candidate8",
        "candidate9",
        "candidate10",
        "candidate11"
      ),
      N.typed = c(
        NA, NA, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L, 8L,
        8L
      ),
      N.potential = c(
        NA, NA, 11L, 11L, 11L, 11L, 11L, 11L, 11L,
        11L, 11L, 11L, 11L
      ),
      prop.typed = c(
        NA,
        NA,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727,
        0.727
      )
    ),
    row.names = c(NA, -13L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_cervus_input(offspringID = c("A-008", "A-001", "A-086"))
  expect_equal(ref, job)

  # Works with individuals conceived before the birthdate of the first founder in the dataset
  expect_warning(create_cervus_input("L-003"))
})


test_that("create_offspring_father.candidate.table works as intended", {
  # Works with standard and multiple individuals
  ref1 <- structure(
    list(
      offspringID = c(
        "A-008",
        "A-001",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086",
        "A-086"
      ),
      potential.fatherID = c(
        NA,
        NA,
        "A-011",
        "A-040",
        "A-042",
        "A-044",
        "A-045",
        "A-047",
        "A-048",
        "A-050",
        "A-051",
        "A-055",
        "M-053"
      )
    ),
    row.names = c(NA, -13L),
    class = c(
      "tbl_df",
      "tbl", "data.frame"
    )
  )
  job1 <- create_offspring_father.candidate.table(offspringID = c("A-008", "A-001", "A-086"))
  expect_equal(ref1, job1)

  # Returns warning when input contains at least one individual conceived before the birthdate of the first founder
  expect_warning(create_offspring_father.candidate.table("L-003"))
  expect_warning(create_offspring_father.candidate.table(c("L-003", "L-004")))
})

test_that("create_clan_rank.social works as intended", {
  ref <- structure(
    list(
      ID = c(
        "A-001", "A-084", "A-010", "A-018", "A-046",
        "A-015", "A-008", "A-013", "A-016", "A-019", "A-020", "A-041",
        "A-081", "A-057", "A-002", "A-003", "A-004", "A-006", "A-007",
        "A-009", "A-014", "A-017", "A-040", "A-043", "A-049", "A-052",
        "A-053", "A-056", "A-058", "A-080", "A-085", "A-054", "A-083",
        "A-113", "A-011", "A-042", "A-044", "A-045", "A-047", "A-048",
        "A-050", "A-051", "M-053"
      ),
      rank = c(
        1, 2, 3, 3, 3, 6, 7, 7, 7, 10, 10, 10, 10, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15,
        15, 15, 15, 15, 15, 15, 15, 32, 32, 32, 35, 35, 35, 35, 35, 35,
        35, 35, 35
      )
    ),
    class = c("tbl_df", "tbl", "data.frame"), row.names = c(NA, -43L)
  )
  job <- create_clan_rank.social("A", "1996-07-30")
  expect_equal(ref, job)
})

test_that("create_id_table.ancestors return a list column with ancestors", {
  expect_equal(class(create_id_table.ancestors("A", "1996-07-30")$ancestors), "list")
})

test_that("create_clan_rank.social works as intended", {
  ref <- structure(
    list(
      ID.1 = c("A-084"),
      ID.2 = c("A-001"),
      date = as.Date(c("1997-04-01")),
      ID.1_is_migrant = c(`A-084` = FALSE),
      ID.2_is_migrant = c(`A-001` = FALSE),
      mrcaID = c("A-001"),
      type = c("native_related")
    ),
    row.names = c(NA, -1L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_dyad_interaction.type(ID.1 = "A-084", ID.2 = "A-001", "1997-04-01")
  expect_equal(ref, job)
})

test_that("create_id_overlap.table works as intended", {
  # Dummy data to filter
  input <- structure(
    list(
      ID = c("A", "A", "B", "C"),
      starting_date = c("1996-01-01", "1997-01-01", "1997-01-01", "1996-05-01"),
      ending_date = c("1996-12-31", "1997-02-01", "1997-03-01", "1997-04-05")
    ),
    row.names = c(NA, -4L), class = c("tbl_df", "tbl", "data.frame")
  )

  job1 <- create_id_overlap.table(input, from = "1996-11-01", to = "1997-11-01", overlap = "start")

  ref1 <- structure(
    list(
      ID = c("A", "B"),
      starting_date = structure(c(9862, 9862), class = "Date"),
      ending_date = structure(c(9893, 9921), class = "Date")
    ),
    row.names = c(NA, -2L), class = c("tbl_df", "tbl", "data.frame")
  )

  expect_equal(job1, ref1)
})


test_that("We can get meta-data from weather stations data for single file", {
  skip("not working unless interactive, I don't understand why...")
  # File with warning
  ref <- structure(list(metadata_category = c(
    "configuration", "software",
    "location", "cellular", "cellular_hardware", "sensors", "errors"
  ), data = list(structure(list(info = c(
    "device_name", "site_name",
    "serial_number", "device_type", "firmware_version", "hardware_version",
    "measurement_interval"
  ), value = c(
    "mvua", "lemala_rim", "z6-08628",
    "zl6", "2.08.21", "3", "30_minutes"
  ), error = c(
    FALSE, FALSE,
    FALSE, FALSE, FALSE, FALSE, FALSE
  ), message = c(
    NA_character_,
    NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
    NA_character_
  )), row.names = c(NA, -7L), class = c(
    "tbl_df",
    "tbl", "data.frame"
  )), structure(list(
    info = "software_version",
    value = "1.25.1", error = FALSE, message = NA_character_
  ), row.names = c(
    NA,
    -1L
  ), class = c("tbl_df", "tbl", "data.frame")), structure(list(
    info = c(
      "latitude", "longitude", "logger_time", "time_zone",
      "satellite_vehicles", "gps_fix_status", "horizontal_accuracy",
      "altitude"
    ), value = c(
      "-3.1421947", "35.6866323", "04/04/22_15:46:50",
      "utc+03", "9", "5", "2200", "2366.7"
    ), error = c(
      FALSE, FALSE,
      FALSE, FALSE, FALSE, FALSE, FALSE, FALSE
    ), message = c(
      NA_character_,
      NA_character_, NA_character_, NA_character_, NA_character_,
      NA_character_, NA_character_, NA_character_
    )
  ), row.names = c(
    NA,
    -8L
  ), class = c("tbl_df", "tbl", "data.frame")), structure(list(
    info = c(
      "uploading", "12:00-12:59_am", "1:00-1:59_am", "2:00-2:59_am",
      "3:00-3:59_am", "4:00-4:59_am", "5:00-5:59_am", "6:00-6:59_am",
      "7:00-7:59_am", "8:00-8:59_am", "9:00-9:59_am", "10:00-10:59_am",
      "11:00-11:59_am", "12:00-12:59_pm", "1:00-1:59_pm", "2:00-2:59_pm",
      "3:00-3:59_pm", "4:00-4:59_pm", "5:00-5:59_pm", "6:00-6:59_pm",
      "7:00-7:59_pm", "8:00-8:59_pm", "9:00-9:59_pm", "10:00-10:59_pm",
      "11:00-11:59_pm", "upload_frequency"
    ), value = c(
      "false",
      "true", "false", "false", "false", "true", "true", "true",
      "true", "true", "true", "true", "true", "true", "true", "true",
      "true", "true", "true", "true", "true", "true", "true", "true",
      "false", "do_not_upload_data"
    ), error = c(
      FALSE, FALSE, FALSE,
      FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
      FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
      FALSE, FALSE, FALSE, FALSE, FALSE
    ), message = c(
      NA_character_,
      NA_character_, NA_character_, NA_character_, NA_character_,
      NA_character_, NA_character_, NA_character_, NA_character_,
      NA_character_, NA_character_, NA_character_, NA_character_,
      NA_character_, NA_character_, NA_character_, NA_character_,
      NA_character_, NA_character_, NA_character_, NA_character_,
      NA_character_, NA_character_, NA_character_, NA_character_,
      NA_character_
    )
  ), row.names = c(NA, -26L), class = c(
    "tbl_df",
    "tbl", "data.frame"
  )), structure(list(info = c(
    "sim_number",
    "modem_firmware_version", "modem_type"
  ), value = c(
    "8944500502190551201",
    "2341", "3"
  ), error = c(FALSE, FALSE, FALSE), message = c(
    NA_character_,
    NA_character_, NA_character_
  )), row.names = c(NA, -3L), class = c(
    "tbl_df",
    "tbl", "data.frame"
  )), structure(list(info = c(
    "port_#", "name",
    "port_#", "name", "serial_number", "status", "firmware_version",
    "rh_serial_num", "port_#", "name", "port_#", "name", "port_#",
    "name", "port_#", "name"
  ), value = c(
    "1", "none_selected", "2",
    "atmos_14_humidity/temp/barometer", "16422-33-738", "ok", "104",
    "0", "3", "none_selected", "4", "ecrn-100_precipitation", "5",
    "none_selected", "6", "none_selected"
  ), error = c(
    FALSE, FALSE,
    FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
    FALSE, FALSE, FALSE, FALSE, FALSE
  ), message = c(
    NA_character_,
    NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
    NA_character_, NA_character_, NA_character_, NA_character_, NA_character_,
    NA_character_, NA_character_, NA_character_, NA_character_, NA_character_
  )), row.names = c(NA, -16L), class = c("tbl_df", "tbl", "data.frame")), structure(list(info = c(
    "ereset:", "ememory:", "eclock:",
    "eradio:", "exfer:", "ecommand:", "ebattery:", "ctestbtn:", "emeasurement:",
    "esensor[1]:", "esensor[2]:", "esensor[3]:", "esensor[4]:", "esensor[5]:",
    "esensor[6]:", "esensor[7]:", "esensor[8]:", "egps:", "eble:",
    "ecellinit:", "esim:", "eattachcell:", "eip:", "last_updated"
  ), value = c(
    "0", "0", "0", "0", "0", "0", "0", "0", "0", "0",
    "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "0", "3",
    "04/02/22_00:23:46"
  ), error = c(
    FALSE, FALSE, FALSE, FALSE, FALSE,
    FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
    FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE,
    FALSE
  ), message = c(
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
    NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, "Weather station error in: \033[33meip:\033[39m\n",
    NA
  )), row.names = c(NA, -24L), class = c("tbl_df", "tbl", "data.frame"))), any_error = c(
    FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
    TRUE
  ), messages = list(
    NA_character_, NA_character_, NA_character_,
    NA_character_, NA_character_, NA_character_, "Weather station error in: \033[33meip:\033[39m\n"
  )), class = c(
    "tbl_df",
    "tbl", "data.frame"
  ), row.names = c(NA, -7L))

  job <- create_tbl_metadata(load_data_weatherstation.file(system.file("extdata/weather_Lemala",
    "z6-08628_04Apr22-1546.xlsx",
    package = "hyenaR"
  ), verbose = FALSE))

  expect_equal(job, ref)
})

test_that("We can get meta-data from weather stations data for multiple files", {
  # File without warning (otherwise it will fail!)
  ref <-
    structure(
      list(
        file_number = c(
          1L,
          1L,
          1L,
          1L,
          1L,
          1L,
          1L,
          2L,
          2L,
          2L,
          2L,
          2L,
          2L,
          2L,
          3L,
          3L,
          3L,
          3L,
          3L,
          3L,
          3L
        ),
        metadata_category = c(
          "configuration",
          "software",
          "location",
          "cellular",
          "cellular_hardware",
          "sensors",
          "errors",
          "configuration",
          "software",
          "location",
          "cellular",
          "cellular_hardware",
          "sensors",
          "errors",
          "configuration",
          "software",
          "location",
          "cellular",
          "cellular_hardware",
          "sensors",
          "errors"
        ),
        data = list(
          structure(
            list(
              info = c(
                "device_name",
                "site_name",
                "serial_number",
                "device_type",
                "firmware_version",
                "hardware_version",
                "measurement_interval"
              ),
              value = c(
                "jua",
                "ngoitokitok",
                "z6-08626",
                "zl6",
                "2.08.21",
                "3",
                "30_minutes"
              ),
              error = c(
                FALSE, FALSE,
                FALSE, FALSE, FALSE, FALSE, FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -7L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = "software_version",
              value = "1.23.7",
              error = FALSE,
              message = NA_character_
            ),
            row.names = c(NA, -1L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "latitude",
                "longitude",
                "logger_time",
                "time_zone",
                "satellite_vehicles",
                "gps_fix_status",
                "horizontal_accuracy",
                "altitude"
              ),
              value = c(
                "-3.2094987",
                "35.6006492",
                "04/04/22_13:10:18",
                "utc+03",
                "11",
                "5",
                "986",
                "1753.184"
              ),
              error = c(
                FALSE,
                FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -8L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "uploading",
                "12:00-12:59_am",
                "1:00-1:59_am",
                "2:00-2:59_am",
                "3:00-3:59_am",
                "4:00-4:59_am",
                "5:00-5:59_am",
                "6:00-6:59_am",
                "7:00-7:59_am",
                "8:00-8:59_am",
                "9:00-9:59_am",
                "10:00-10:59_am",
                "11:00-11:59_am",
                "12:00-12:59_pm",
                "1:00-1:59_pm",
                "2:00-2:59_pm",
                "3:00-3:59_pm",
                "4:00-4:59_pm",
                "5:00-5:59_pm",
                "6:00-6:59_pm",
                "7:00-7:59_pm",
                "8:00-8:59_pm",
                "9:00-9:59_pm",
                "10:00-10:59_pm",
                "11:00-11:59_pm",
                "upload_frequency"
              ),
              value = c(
                "false",
                "true",
                "false",
                "false",
                "false",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "false",
                "do_not_upload_data"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -26L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "sim_number",
                "modem_firmware_version", "modem_type"
              ),
              value = c(
                "8944500502190551847",
                "2341", "3"
              ),
              error = c(FALSE, FALSE, FALSE),
              message = c(
                NA_character_,
                NA_character_, NA_character_
              )
            ),
            row.names = c(NA, -3L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "port_#",
                "name",
                "serial_num",
                "meta",
                "value",
                "status",
                "version",
                "port_#",
                "name",
                "serial_num",
                "meta",
                "value",
                "status",
                "version",
                "port_#",
                "name",
                "serial_num",
                "meta",
                "value",
                "status",
                "version",
                "port_#",
                "name",
                "serial_num",
                "meta",
                "value",
                "status",
                "version",
                "port_#",
                "name",
                "serial_num",
                "meta",
                "value",
                "status",
                "version",
                "port_#",
                "name",
                "serial_num",
                "meta",
                "value",
                "status",
                "version"
              ),
              value = c(
                "1",
                "none_selected",
                NA,
                "0",
                "0",
                "0",
                "0",
                "2",
                "atmos_14_humidity/temp/barometer",
                "16422-04-709",
                "0",
                "0",
                "1",
                "104",
                "3",
                "none_selected",
                NA,
                "0",
                "0",
                "0",
                "0",
                "4",
                "ecrn-100_precipitation",
                NA,
                "0",
                "0",
                "0",
                "0",
                "5",
                "none_selected",
                NA,
                "0",
                "0",
                "0",
                "0",
                "6",
                "none_selected",
                NA,
                "0",
                "0",
                "0",
                "0"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -42L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "ereset:",
                "ememory:",
                "eclock:",
                "eradio:",
                "exfer:",
                "ecommand:",
                "ebattery:",
                "ctestbtn:",
                "emeasurement:",
                "esensor[1]:",
                "esensor[2]:",
                "esensor[3]:",
                "esensor[4]:",
                "esensor[5]:",
                "esensor[6]:",
                "esensor[7]:",
                "esensor[8]:",
                "egps:",
                "eble:",
                "ecellinit:",
                "esim:",
                "eattachcell:",
                "eip:",
                "last_updated"
              ),
              value = c(
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "04/04/22_00:23:31"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -24L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "device_name",
                "site_name",
                "serial_number",
                "device_type",
                "firmware_version",
                "hardware_version",
                "measurement_interval"
              ),
              value = c(
                "jua",
                "ngoitokitok",
                "z6-08626",
                "zl6",
                "2.08.21",
                "3",
                "30_minutes"
              ),
              error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -7L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = "software_version",
              value = "1.25.1",
              error = FALSE,
              message = NA_character_
            ),
            row.names = c(NA, -1L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "latitude",
                "longitude",
                "logger_time",
                "time_zone",
                "satellite_vehicles",
                "gps_fix_status",
                "horizontal_accuracy",
                "altitude"
              ),
              value = c(
                "-3.2094882",
                "35.6006538",
                "04/24/22_14:08:04",
                "utc+03",
                "12",
                "7",
                "931",
                "1757.268"
              ),
              error = c(
                FALSE,
                FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -8L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "uploading",
                "12:00-12:59_am",
                "1:00-1:59_am",
                "2:00-2:59_am",
                "3:00-3:59_am",
                "4:00-4:59_am",
                "5:00-5:59_am",
                "6:00-6:59_am",
                "7:00-7:59_am",
                "8:00-8:59_am",
                "9:00-9:59_am",
                "10:00-10:59_am",
                "11:00-11:59_am",
                "12:00-12:59_pm",
                "1:00-1:59_pm",
                "2:00-2:59_pm",
                "3:00-3:59_pm",
                "4:00-4:59_pm",
                "5:00-5:59_pm",
                "6:00-6:59_pm",
                "7:00-7:59_pm",
                "8:00-8:59_pm",
                "9:00-9:59_pm",
                "10:00-10:59_pm",
                "11:00-11:59_pm",
                "upload_frequency"
              ),
              value = c(
                "false",
                "true",
                "false",
                "false",
                "false",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "false",
                "do_not_upload_data"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -26L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "sim_number",
                "modem_firmware_version", "modem_type"
              ),
              value = c(
                "8944500502190551847",
                "2341", "3"
              ),
              error = c(FALSE, FALSE, FALSE),
              message = c(
                NA_character_,
                NA_character_, NA_character_
              )
            ),
            row.names = c(NA, -3L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "port_#",
                "name",
                "port_#",
                "name",
                "serial_number",
                "status",
                "firmware_version",
                "rh_serial_num",
                "port_#",
                "name",
                "port_#",
                "name",
                "port_#",
                "name",
                "port_#",
                "name"
              ),
              value = c(
                "1",
                "none_selected",
                "2",
                "atmos_14_humidity/temp/barometer",
                "16422-04-709",
                "ok",
                "104",
                "0",
                "3",
                "none_selected",
                "4",
                "ecrn-100_precipitation",
                "5",
                "none_selected",
                "6",
                "none_selected"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -16L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "ereset:",
                "ememory:",
                "eclock:",
                "eradio:",
                "exfer:",
                "ecommand:",
                "ebattery:",
                "ctestbtn:",
                "emeasurement:",
                "esensor[1]:",
                "esensor[2]:",
                "esensor[3]:",
                "esensor[4]:",
                "esensor[5]:",
                "esensor[6]:",
                "esensor[7]:",
                "esensor[8]:",
                "egps:",
                "eble:",
                "ecellinit:",
                "esim:",
                "eattachcell:",
                "eip:",
                "last_updated"
              ),
              value = c(
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "04/24/22_00:21:38"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -24L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "device_name",
                "site_name",
                "serial_number",
                "device_type",
                "firmware_version",
                "hardware_version",
                "measurement_interval"
              ),
              value = c(
                "jua",
                "ngoitokitok",
                "z6-08626",
                "zl6",
                "2.08.21",
                "3",
                "30_minutes"
              ),
              error = c(FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -7L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = "software_version",
              value = "1.25.1",
              error = FALSE,
              message = NA_character_
            ),
            row.names = c(NA, -1L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "latitude",
                "longitude",
                "logger_time",
                "time_zone",
                "satellite_vehicles",
                "gps_fix_status",
                "horizontal_accuracy",
                "altitude"
              ),
              value = c(
                "-3.2095092",
                "35.6006404",
                "05/31/22_14:37:24",
                "utc+03",
                "13",
                "7",
                "826",
                "1756.429"
              ),
              error = c(
                FALSE,
                FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -8L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "uploading",
                "12:00-12:59_am",
                "1:00-1:59_am",
                "2:00-2:59_am",
                "3:00-3:59_am",
                "4:00-4:59_am",
                "5:00-5:59_am",
                "6:00-6:59_am",
                "7:00-7:59_am",
                "8:00-8:59_am",
                "9:00-9:59_am",
                "10:00-10:59_am",
                "11:00-11:59_am",
                "12:00-12:59_pm",
                "1:00-1:59_pm",
                "2:00-2:59_pm",
                "3:00-3:59_pm",
                "4:00-4:59_pm",
                "5:00-5:59_pm",
                "6:00-6:59_pm",
                "7:00-7:59_pm",
                "8:00-8:59_pm",
                "9:00-9:59_pm",
                "10:00-10:59_pm",
                "11:00-11:59_pm",
                "upload_frequency"
              ),
              value = c(
                "false",
                "true",
                "false",
                "false",
                "false",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "true",
                "false",
                "do_not_upload_data"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -26L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "sim_number",
                "modem_firmware_version", "modem_type"
              ),
              value = c(
                "8944500502190551847",
                "2341", "3"
              ),
              error = c(FALSE, FALSE, FALSE),
              message = c(
                NA_character_,
                NA_character_, NA_character_
              )
            ),
            row.names = c(NA, -3L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          ),
          structure(
            list(
              info = c(
                "port_#",
                "name",
                "port_#",
                "name",
                "serial_number",
                "status",
                "firmware_version",
                "rh_serial_num",
                "port_#",
                "name",
                "port_#",
                "name",
                "port_#",
                "name",
                "port_#",
                "name"
              ),
              value = c(
                "1",
                "none_selected",
                "2",
                "atmos_14_humidity/temp/barometer",
                "16422-04-709",
                "ok",
                "104",
                "0",
                "3",
                "none_selected",
                "4",
                "ecrn-100_precipitation",
                "5",
                "none_selected",
                "6",
                "none_selected"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -16L),
            class = c("tbl_df", "tbl", "data.frame")
          ),
          structure(
            list(
              info = c(
                "ereset:",
                "ememory:",
                "eclock:",
                "eradio:",
                "exfer:",
                "ecommand:",
                "ebattery:",
                "ctestbtn:",
                "emeasurement:",
                "esensor[1]:",
                "esensor[2]:",
                "esensor[3]:",
                "esensor[4]:",
                "esensor[5]:",
                "esensor[6]:",
                "esensor[7]:",
                "esensor[8]:",
                "egps:",
                "eble:",
                "ecellinit:",
                "esim:",
                "eattachcell:",
                "eip:",
                "last_updated"
              ),
              value = c(
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "0",
                "05/31/22_00:15:32"
              ),
              error = c(
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE,
                FALSE
              ),
              message = c(
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_,
                NA_character_
              )
            ),
            row.names = c(NA, -24L),
            class = c(
              "tbl_df",
              "tbl", "data.frame"
            )
          )
        ),
        any_error = c(
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE,
          FALSE
        ),
        messages = list(
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_,
          NA_character_
        )
      ),
      row.names = c(NA, -21L),
      class = c(
        "tbl_df",
        "tbl", "data.frame"
      )
    )

  job <- create_tbl_metadata(load_data_weatherstation.all(system.file("extdata/weather_Ngoitokitok",
    package = "hyenaR"
  )))

  expect_equal(job, ref)
})


test_that("We can create weather db with create_weather_starting.table", {
  ref <- structure(list(
    station_name = c(
      "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua"
    ), site_name = c(
      "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok"
    ), date_time = structure(c(
      1648760400,
      1648762200, 1648764000, 1648765800, 1648767600, 1648769400, 1648771200,
      1648773000, 1648774800, 1648776600, 1648778400, 1648780200, 1648782000,
      1648783800, 1648785600, 1648787400, 1648789200, 1648791000, 1648792800,
      1648794600, 1648796400, 1648798200, 1648800000, 1648801800, 1648803600,
      1648805400, 1648807200, 1648809000, 1648810800, 1648812600, 1648814400,
      1648816200, 1648818000, 1648819800, 1648821600, 1648823400, 1648825200,
      1648827000, 1648828800, 1648830600, 1648832400, 1648834200, 1648836000,
      1648837800, 1648839600, 1648841400, 1648843200, 1648845000
    ), tzone = "Africa/Dar_es_Salaam", class = c(
      "POSIXct",
      "POSIXt"
    )), latitude = c(
      -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987
    ), longitude = c(
      35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492
    ),
    air_temp = c(
      17.76, 16.72, 16.24, 16.35, 15.79, 15.69, 16.28,
      16.23, 16.27, 15.42, 16.58, 16.89, 17.39, 17.17, 17.22, 16.48,
      17.57, 18.18, 18.31, 18.5, 18.66, 19.93, 21.3, 22, 21.73,
      22.49, 22.8, 23.61, 24.62, 24.6, 24.54, 24.44, 24.49, 24.15,
      23.13, 22.71, 22.17, 21.34, 20.97, 20.53, 19.74, 19.5, 19.06,
      19.5, 18.89, 18.34, 16.58, 16.96
    )
  ), row.names = c(NA, -48L), class = c("tbl_df", "tbl", "data.frame"))
  job <- create_weather_starting.table(from = "2022-04-01", to = "2022-04-01", variable = "temp", station = "jua")

  expect_equal(job, ref)
})

test_that("`create_weather_starting.table` deals with dates as expected", {
  # Ref here should be the same for both jobs because station and location are the same
  ref <- structure(list(
    station_name = c(
      "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua", "jua",
      "jua", "jua", "jua", "jua", "jua", "jua", "jua"
    ), site_name = c(
      "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok",
      "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok", "ngoitokitok"
    ), date_time = structure(c(
      1648647000, 1648648800, 1648650600,
      1648652400, 1648654200, 1648656000, 1648657800, 1648659600, 1648661400,
      1648663200, 1648665000, 1648666800, 1648668600, 1648670400, 1648672200,
      1648674000, 1648675800, 1648677600, 1648679400, 1648681200, 1648683000,
      1648684800, 1648686600, 1648688400, 1648690200, 1648692000, 1648693800,
      1648695600, 1648697400, 1648699200, 1648701000, 1648702800, 1648704600,
      1648706400, 1648708200, 1648710000, 1648711800, 1648713600, 1648715400,
      1648717200, 1648719000, 1648720800, 1648722600, 1648724400, 1648726200,
      1648728000, 1648729800, 1648731600, 1648733400, 1648735200, 1648737000,
      1648738800, 1648740600, 1648742400, 1648744200, 1648746000, 1648747800,
      1648749600, 1648751400, 1648753200, 1648755000, 1648756800, 1648758600,
      1648760400, 1648762200, 1648764000, 1648765800, 1648767600, 1648769400,
      1648771200, 1648773000, 1648774800, 1648776600, 1648778400, 1648780200,
      1648782000, 1648783800, 1648785600, 1648787400, 1648789200, 1648791000,
      1648792800, 1648794600, 1648796400, 1648798200, 1648800000, 1648801800,
      1648803600, 1648805400, 1648807200, 1648809000, 1648810800, 1648812600,
      1648814400, 1648816200, 1648818000, 1648819800, 1648821600, 1648823400,
      1648825200, 1648827000, 1648828800, 1648830600, 1648832400, 1648834200,
      1648836000, 1648837800, 1648839600, 1648841400, 1648843200, 1648845000
    ), tzone = "Africa/Dar_es_Salaam", class = c("POSIXct", "POSIXt")), latitude = c(
      -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987,
      -3.2094987, -3.2094987, -3.2094987, -3.2094987, -3.2094987
    ),
    longitude = c(
      35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492, 35.6006492, 35.6006492, 35.6006492,
      35.6006492, 35.6006492
    ), air_temp = c(
      25.26, 22.78, 21.11,
      20.75, 21.23, 21.16, 20.19, 19.96, 19.69, 19.65, 19.39, 18.62,
      18.05, 19.55, 18.75, 17.63, 16.7, 17.31, 16.18, 15.21, 14.89,
      13.97, 13.95, 14.23, 15.24, 14.68, 13.74, 14, 12.23, 13.77,
      14.04, 14.47, 16.99, 18.95, 20.87, 22.05, 22.5, 23.06, 23.06,
      23.2, 24.2, 23.82, 23.26, 24.69, 25.03, 25.58, 26.12, 25.7,
      25.56, 25.25, 24.64, 24.24, 22.51, 21.1, 20.88, 19.98, 19.87,
      18.09, 19.55, 19.3, 17.38, 18.12, 18.3, 17.76, 16.72, 16.24,
      16.35, 15.79, 15.69, 16.28, 16.23, 16.27, 15.42, 16.58, 16.89,
      17.39, 17.17, 17.22, 16.48, 17.57, 18.18, 18.31, 18.5, 18.66,
      19.93, 21.3, 22, 21.73, 22.49, 22.8, 23.61, 24.62, 24.6,
      24.54, 24.44, 24.49, 24.15, 23.13, 22.71, 22.17, 21.34, 20.97,
      20.53, 19.74, 19.5, 19.06, 19.5, 18.89, 18.34, 16.58, 16.96
    )
  ), row.names = c(NA, -111L), class = c(
    "tbl_df", "tbl",
    "data.frame"
  ))

  # Throws warning if dates are outside period in which station was active (but still returns expected output)
  expect_warning(job1 <- create_weather_starting.table(from = "2021-01-01", to = "2022-04-01", variable = "temp", station = "jua"))

  # Same if we use location
  expect_warning(job2 <- create_weather_starting.table(from = "2021-01-01", to = "2022-04-01", variable = "temp", location = "ngoitokitok"))

  expect_equal(job1, ref)
  expect_equal(job2, ref)
})
