context("Test functions related to siblings")

test_that("create_id_sibling.table works as intended", {
  ref <-
    structure(
      list(
        focalID = c("A-084", "A-084", "A-084", "A-084", "A-084"),
        parentID = c("A-001", "A-001", "A-001", "A-001", "A-001"),
        from = structure(c(3390, 3390, 3390, 3390, 3390), class = "Date"),
        to = structure(c(10226, 10226, 10226, 10226, 10226), class = "Date"),
        siblingID = c("A-010", "A-018", "A-046", "A-088", "A-089"),
        birthdate = structure(c(9029, 9029, 9029, 9842, 9842), class = "Date"),
        filiation = c(
          "mother_social_genetic",
          "mother_social_genetic",
          "mother_social_genetic",
          "mother_social_genetic",
          "mother_social_genetic"
        )
      ),
      class = c("tbl_df", "tbl", "data.frame"),
      row.names = c(NA, -5L)
    )
  job <- create_id_sibling.table(ID = "A-084")
  expect_equal(ref, job)
})

test_that("find_id_id.sibling.older works as intended", {
  ref <- c("A-010", "A-018", "A-046")
  job <- find_id_id.sibling.older(ID = "A-084", filiation = "mother_genetic")
  expect_equal(ref, job)
})

test_that("find_id_id.sibling.younger works as intended", {
  ref <- c("A-088", "A-089")
  job <- find_id_id.sibling.younger(ID = "A-084", filiation = "mother_genetic")
  expect_equal(ref, job)
})


test_that("fetch_dyad_is.sibling works as intended", {
  job1 <- fetch_dyad_is.sibling(
    ID.1 = "A-084", ID.2 = find_pop_id(),
    filiation = "mother_genetic"
  )
  job1bis <- fetch_dyad_is.sibling(
    ID.1 = "A-084", ID.2 = find_pop_id(),
    filiation = "mother_genetic", .parallel.min = 0
  )
  ref1 <- c(
    NA, NA, NA, NA, NA, NA, FALSE, NA, TRUE, NA, NA, NA, NA, NA,
    NA, TRUE, FALSE, NA, NA, FALSE, NA, NA, NA, NA, TRUE, NA, NA,
    NA, NA, NA, NA, NA, NA, NA, NA, FALSE, NA, FALSE, FALSE, FALSE,
    NA, FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, FALSE, FALSE, FALSE,
    NA, FALSE, NA, FALSE, FALSE, FALSE, FALSE, FALSE, NA, FALSE,
    NA, FALSE, NA, FALSE, FALSE, NA, NA, FALSE, FALSE, NA, FALSE,
    FALSE, FALSE, NA, NA, NA, NA, NA, NA, FALSE, FALSE, NA, NA, NA,
    NA, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
    FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
    FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
    FALSE, FALSE, FALSE, NA, NA, FALSE, NA, NA, NA, FALSE
  )
  job2 <- fetch_dyad_is.sibling(
    ID.1 = "A-018", ID.2 = find_pop_id(),
    filiation = "father"
  )
  ref2 <- c(
    NA, NA, NA, NA, NA, NA, TRUE, NA, TRUE, NA, NA, NA, NA, NA,
    NA, FALSE, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
    NA, NA, NA, FALSE, NA, NA, NA, NA, FALSE, NA, NA, NA, NA, NA,
    NA, FALSE, NA, NA, NA, NA, FALSE, NA, NA, NA, NA, NA, NA, NA,
    TRUE, NA, FALSE, NA, NA, NA, FALSE, NA, NA, NA, NA, NA, NA, NA,
    NA, FALSE, NA, NA, NA, NA, NA, NA, FALSE, NA, NA, NA, NA, NA,
    NA, NA, FALSE, FALSE, FALSE, NA, FALSE, FALSE, FALSE, FALSE,
    FALSE, NA, NA, FALSE, FALSE, FALSE, FALSE, FALSE, NA, FALSE,
    FALSE, FALSE, FALSE, NA, NA, FALSE, FALSE, FALSE, FALSE, NA,
    NA, NA, NA, NA, NA, NA, NA
  )
  expect_equal(ref1, job1)
  expect_equal(ref1, job1bis)
  expect_equal(ref2, job2)
})
