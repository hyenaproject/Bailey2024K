context("Test multifetch_xxx functions")

test_that("all multifetch functions return the correct type of output", {
  expect_equal(class({
    create_id_starting.table(clan = "A", at = "1997-01-01") %>%
      mutate(date = as.Date("1997-01-01")) %>%
      join_allranks()
  })[1], "tbl_df")
  expect_equal(class(multifetch_id_offspring.count("A-001"))[1], "tbl_df")
  expect_equal(class(multifetch_id_birth.info("A-001"))[1], "tbl_df")
})

test_that("multifetch_id_offspring.count returns the correct output", {
  ref <-
    structure(
      list(
        n_females = 3L,
        n_males = 3L,
        n_unknown = 0L
      ),
      row.names = c(NA, -1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- multifetch_id_offspring.count("A-001")
  expect_equal(ref, job)
})

test_that("multifetch_clan_obsv.effort returns the correct output", {
  expect_equal(class(multifetch_clan_obsv.effort(clan = "A", from = "1997/01/01", to = "1997/12/01"))[1], "tbl_df")

  ref <-
    structure(
      list(
        effort_adult = c(11 / 34, 21 / 26),
        effort_cub = c(10 / 23, 16 / 20),
        effort_all = c(21 / 57, 37 / 46)
      ),
      row.names = c(NA, -2L),
      class = c("tbl_df", "tbl", "data.frame")
    )

  # We keep the new argument just to make sure we can compare new & and old method
  # Use Aug 97 to check that conception sightings are removed
  job <- multifetch_clan_obsv.effort(clan = c("A", "L"), from = "1997-08-01", to = "1997-09-01")
  expect_equal(ref, job)
})

test_that("multifetch_id_birth.info works as intended", {
  ref <- structure(
    list(
      sex = c("female", "female", "male"),
      motherID = c(NA, "A-015", "A-006"),
      fatherID = c(NA, "A-045", "A-045"),
      birthdate = structure(c(6715, 8906, 10088),
        class = "Date"
      ),
      clan.birth = c("A", "A", "A"),
      clan.conception = c(NA, "A", "A")
    ),
    row.names = c(NA, -3L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  job <- multifetch_id_birth.info(ID = c("A-001", "A-008", "A-100"))
  expect_equal(ref, job)
})

test_that("multifetch_weather_temp.summary works as intended", {
  # Works for one station
  ref1 <- structure(list(
    from = "2022-04-01", to = "2022-05-31", station = "jua",
    ngoitokitok_air_temp_mean = 18.4231958762887, ngoitokitok_air_temp_max = 26.64,
    ngoitokitok_air_temp_min = 11.07, ngoitokitok_air_temp_sd = 2.94792986768024
  ), class = "data.frame", row.names = c(NA, -1L))
  data.frame(from = "2022-04-01", to = "2022-05-31", station = "jua") |>
    dplyr::mutate(multifetch_weather_temp.summary(from = from, to = to, station = station)) -> job1
  expect_equal(ref1, job1)

  # Works for multiple stations
  ref2 <- structure(list(
    from = "2022-04-01", to = "2022-05-01", lemala_rim_air_temp_mean = 14.5692069892473,
    ngoitokitok_air_temp_mean = 19.0216465053763, lemala_rim_air_temp_max = 22.27,
    ngoitokitok_air_temp_max = 26.64, lemala_rim_air_temp_min = 6.39,
    ngoitokitok_air_temp_min = 11.07, lemala_rim_air_temp_sd = 2.91679860435214,
    ngoitokitok_air_temp_sd = 3.10942404080604
  ), class = "data.frame", row.names = c(NA, -1L))
  data.frame(from = "2022-04-01", to = "2022-05-01") |>
    dplyr::mutate(multifetch_weather_temp.summary(from = from, to = to, station = c("jua", "mvua"))) -> job2
  expect_equal(ref2, job2)
})

test_that("multifetch_weather_temp.summary works as intended", {
  # Works for one station
  ref1 <- structure(list(
    from = "2022-04-01", to = "2022-05-31", station = "jua",
    ngoitokitok_precip_mean = 0.0316151202749141, ngoitokitok_precip_max = 13.6,
    ngoitokitok_precip_min = 0, ngoitokitok_precip_sd = 0.313975719554587
  ), class = "data.frame", row.names = c(NA, -1L))
  data.frame(from = "2022-04-01", to = "2022-05-31", station = "jua") |>
    dplyr::mutate(multifetch_weather_rain.summary(from = from, to = to, station = station)) -> job1
  expect_equal(ref1, job1)

  # Works for multiple stations
  ref2 <- structure(list(
    from = "2022-04-01", to = "2022-05-31", ngoitokitok_precip_mean = 0.0316151202749141,
    ngoitokitok_precip_max = 13.6, ngoitokitok_precip_min = 0,
    ngoitokitok_precip_sd = 0.313975719554587
  ), class = "data.frame", row.names = c(NA, -1L))
  data.frame(from = "2022-04-01", to = "2022-05-31") |>
    dplyr::mutate(multifetch_weather_rain.summary(from = from, to = to, station = c("jua", "upepo"))) -> job2
  expect_equal(ref2, job2)
})
