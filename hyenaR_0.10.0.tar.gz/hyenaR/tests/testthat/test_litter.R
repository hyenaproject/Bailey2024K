context("Test functions handling litter")

test_that("object types are correct", {
  expect_equal(class(create_litter_offspring.table(litterID = c("A-001_003", "A-001_002")))[1], "tbl_df")
  expect_equal(class(create_litter_starting.table(c("A-001", "L-003", "A-098")))[1], "tbl_df")
  expect_equal(class(create_litter_starting.table())[1], "tbl_df")
  expect_equal(class(create_litter_offspring.count("A-001_003"))[1], "tbl_df")
  expect_equal(class(create_litter_offspring.count())[1], "tbl_df")
  expect_equal(class(fetch_id_rank.litter(ID = c("A-018")))[1], "integer")
  expect_equal(class(fetch_litter_composition("A-001_003")), "character")
  expect_equal(class(fetch_litter_is.sampled.dna(litterID = c("A-001_003", "A-001_001", "A-001_003"))), "logical")
  expect_equal(class(fetch_id_has.twin.litter(ID = c("A-001", "A-007"), to = "1997-12-30")), "logical")
  expect_equal(class(fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001")))[1], "Date")
  expect_equal(class(fetch_id_litterID(ID = c("A-010", "A-049"), filiation = "mother_genetic")), "character")
  expect_equal(class(fetch_id_litter.count(ID = "A-001")), "integer")
})


test_that("create_litter_offspring.table returns output as intended", {
  ref <- structure(
    list(
      litterID = c("A-001_003", "A-001_003", "A-001_002"),
      mumID = c("A-001", "A-001", "A-001"),
      offspringID = c("A-088", "A-089", "A-084"),
      birthdate = structure(c(9842, 9842, 9411), class = "Date"),
      filiation = c("mother_social_genetic", "mother_social_genetic", "mother_social_genetic"),
      litterbirth = structure(c(9842, 9842, 9411), class = "Date")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -3L)
  )
  job <- create_litter_offspring.table(litterID = c("A-001_003", "A-001_002"))
  expect_equal(ref, job)
})

test_that("create_litter_offspring.count returns output as intended", {
  ref <- structure(
    list(
      litterID = "A-001_003",
      female = 1L,
      male = 1L,
      unknown = 0L,
      social.female = 0L,
      social.male = 0L,
      social.unknown = 0L
    ),
    row.names = c(NA, -1L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_litter_offspring.count("A-001_003")
  expect_equal(ref, job)
})

test_that("create_litter_starting.table return the expected output", {
  ref <- structure(
    list(
      litterID = c("A-001_001", "A-001_002", "A-001_003", "L-003_001")
    ),
    row.names = c(NA, -4L),
    class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_litter_starting.table(c("A-001", "L-003", "A-098"))
  expect_equal(ref, job)
})

test_that("fetch_litter_is.sampled.dna returns the output as intended", {
  ref <- c(TRUE, TRUE, TRUE)
  job <- fetch_litter_is.sampled.dna(litterID = c("A-001_003", "A-001_001", "A-001_003"))
  expect_equal(ref, job)
})

test_that("fetch_litter_composition returns the correct output", {
  ref <- c("f_m")
  job <- fetch_litter_composition("A-001_003")
  expect_equal(ref, job)
})

test_that("fetch_id_has.twin.litter returns the correct output", {
  ref1 <- c(TRUE, FALSE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-007"), to = "1997-12-30", first.event = "birthdate")
  expect_equal(ref1, job)
})

test_that("fetch_id_has.twin.litter works with repeated parentID", {
  ref2 <- c(TRUE, FALSE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-001"), at = c("1994-09-21", "1995-10-08"), first.event = "birthdate")
  expect_equal(ref2, job)
})

test_that("fetch_id_has.twin.litter works with duplicated input", {
  ref2 <- c(TRUE, TRUE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-001"), at = c("1994-09-21", "1994-09-21"), first.event = "birthdate")
  expect_equal(ref2, job)
})

test_that("fetch_id_has.twin.litter works with non-chronological input", {
  ref2 <- c(FALSE, TRUE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-001"), at = c("1995-10-08", "1994-09-21"), first.event = "birthdate")
  expect_equal(ref2, job)
})

test_that("fetch_litter_date.birth returns output as intended", {
  ref <- as.Date(c("1995-10-08", "1996-06-11"))
  job <- fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001"))
  expect_equal(ref, job)
})

test_that("fetch_id_litterID works as intended", {
  ref <- c("A-001_001", NA)
  job <- fetch_id_litterID(ID = c("A-010", "A-049"), filiation = "mother_genetic")
  expect_equal(ref, job)
})

test_that("fetch_id_litter.count works as intended", {
  ref <- c(3L, 3L, 0L)
  job <- fetch_id_litter.count(ID = c("A-001", "A-001", "A-008"), first.event = "birthdate")
  expect_equal(ref, job)
})

test_that("find_clan_litterID works as intended", {
  ref <- c(
    "A-001_003", "A-002_001", "A-003_002", "A-004_001", "A-006_001",
    "A-010_001", "A-013_002", "A-014_001", "A-015_002", "A-016_002",
    "A-020_002", "L-001_003", "L-002_003", "L-004_001", "L-004_002",
    "L-005_003", "L-005_004", "L-006_001", "L-008_002", "L-008_003",
    "L-009_001", "L-010_001", "L-011_001", "L-012_001", "L-013_001",
    "L-014_001", "L-015_001"
  )
  job <- find_clan_litterID(clan = c("A", "L"), first.event = "observation")
  expect_equal(ref, job)
})

test_that("find_pop_litterID works as intended", {
  ref <- c(
    "A-001_001", "A-001_002", "A-001_003", "A-002_001",
    "A-003_001", "A-003_002", "A-004_001", "A-006_001",
    "A-007_001", "A-010_001", "A-016_002", "A-013_001", "A-013_002",
    "A-014_001", "A-015_001", "A-015_002", "A-016_001", "A-020_001",
    "A-020_002", "L-001_002", "L-001_001", "L-001_003", "L-002_001",
    "L-002_002", "L-002_003", "L-003_001", "L-004_001", "L-004_002",
    "L-005_001", "L-005_002", "L-005_003", "L-005_004", "L-006_001",
    "L-007_002", "L-007_004", "L-007_001", "L-007_003", "L-007_005",
    "L-008_001", "L-008_002", "L-008_003", "L-009_001", "L-010_001",
    "L-011_001", "L-012_001", "L-013_001", "L-014_001", "L-015_001",
    "M-004_001", "S-002_001"
  )
  ref <- sort(ref)
  job <- find_pop_litterID()
  expect_equal(ref, job)
})


test_that("create_litter_offspring.table returns output as intended", {
  ref <- structure(
    list(
      litterID = c("A-001_003", "A-001_003", "A-001_002"),
      mumID = c("A-001", "A-001", "A-001"),
      offspringID = c("A-088", "A-089", "A-084"),
      birthdate = structure(c(9842, 9842, 9411), class = "Date"),
      filiation = c("mother_social_genetic", "mother_social_genetic", "mother_social_genetic"),
      litterbirth = structure(c(9842, 9842, 9411), class = "Date")
    ),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -3L)
  )
  job <- create_litter_offspring.table(litterID = c("A-001_003", "A-001_002"))
  expect_equal(ref, job)
})

test_that("create_litter_offspring.count returns output as intended", {
  ref <-
    structure(
      list(
        litterID = "A-001_003",
        female = 1L,
        male = 1L,
        unknown = 0L,
        social.female = 0L,
        social.male = 0L,
        social.unknown = 0L
      ),
      row.names = c(NA, -1L),
      class = c("tbl_df", "tbl", "data.frame")
    )
  job <- create_litter_offspring.count("A-001_003")
  expect_equal(ref, job)
})

test_that("create_litter_starting.table return the expected output", {
  ref <- structure(list(litterID = c("A-001_001", "A-001_002", "A-001_003", "L-003_001")),
    class = c("tbl_df", "tbl", "data.frame"),
    row.names = c(NA, -4L)
  )
  job <- create_litter_starting.table(c("A-001", "L-003", "A-098"))
  expect_equal(ref, job)
})

test_that("fetch_litter_is.sampled.dna returns the output as intended", {
  ref <- c(TRUE, TRUE, TRUE)
  job <- fetch_litter_is.sampled.dna(litterID = c("A-001_003", "A-001_001", "A-001_003"))
  expect_equal(ref, job)
})


test_that("fetch_litter_composition returns the correct output", {
  ref <- c("f_m")
  job <- fetch_litter_composition("A-001_003")
  expect_equal(ref, job)
})

test_that("fetch_id_has.twin.litter returns the correct output", {
  ref1 <- c(TRUE, FALSE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-007"), to = "1997-12-30", first.event = "birthdate")
  expect_equal(ref1, job)
})

test_that("fetch_id_has.twin.litter works with repeated parentID", {
  ref2 <- c(TRUE, FALSE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-001"), at = c("1994-09-21", "1995-10-08"), first.event = "birthdate")
  expect_equal(ref2, job)
})

test_that("fetch_id_has.twin.litter works with duplicated input", {
  ref2 <- c(TRUE, TRUE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-001"), at = c("1994-09-21", "1994-09-21"), first.event = "birthdate")
  expect_equal(ref2, job)
})

test_that("fetch_id_has.twin.litter works with non-chronological input", {
  ref2 <- c(FALSE, TRUE)
  job <- fetch_id_has.twin.litter(ID = c("A-001", "A-001"), at = c("1995-10-08", "1994-09-21"), first.event = "birthdate")
  expect_equal(ref2, job)
})

test_that("fetch_id_litter.count works as intended", {
  ref <- c(3L, 3L, 0L)
  job <- fetch_id_litter.count(ID = c("A-001", "A-001", "A-008"), first.event = "birthdate")
  expect_equal(ref, job)
})

test_that("fetch_id_litterID works as intended", {
  ref <- c("A-001_001", NA)
  job <- fetch_id_litterID(ID = c("A-010", "A-049"), filiation = "mother_genetic")
  expect_equal(ref, job)
})

test_that("fetch_litter_date.birth returns output as intended", {
  ref <- as.Date(c("1995-10-08", "1996-06-11"))
  job <- fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001"))
  expect_equal(ref, job)
})
