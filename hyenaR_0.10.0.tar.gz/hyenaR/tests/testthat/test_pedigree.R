context("Test pedigree functions")

test_that("create_pop_pedigree() works as intended", {
  ref <- structure(
    list(
      ID = c(
        "L-003", "L-001", "L-007", "M-004", "A-014",
        "A-044", "A-017", "L-005", "L-012", "L-042", "L-002", "A-001",
        "A-004", "A-045", "A-007", "L-041", "A-047", "A-003", "S-002",
        "L-008", "L-043", "L-009", "A-015", "A-055", "L-006", "L-040",
        "L-047", "A-016", "A-042", "A-006", "A-020", "A-013", "A-011",
        "L-048", "N-043", "A-002", "A-051", "M-053", "A-043", "A-048",
        "A-053", "A-052", "A-050", "M-047", "M-051", "L-004", "L-044",
        "L-045", "L-014", "A-009", "S-043", "L-011", "A-057", "A-040",
        "A-049", "L-013", "L-015", "A-008", "A-056", "L-010", "A-041",
        "A-019", "A-010", "A-018", "A-046", "L-046", "L-049", "A-058",
        "L-088", "L-089", "L-082", "L-083", "A-084", "A-085", "A-082",
        "A-054", "A-113"
      ),
      sire = c(
        NA, NA, NA, NA, NA, NA, NA, NA, NA,
        NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
        NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
        NA, NA, NA, NA, "L-042", "L-042", NA, NA, NA, NA, NA, NA, NA,
        NA, "L-043", NA, "A-045", NA, NA, NA, NA, "A-045", "A-045", NA,
        NA, NA, NA, "L-043", "L-043", "L-043", "L-043", NA, NA, NA, "A-011",
        NA
      ),
      dam = c(
        NA, NA, NA, NA, NA, NA, NA, "L-007", "L-001", NA,
        "L-007", NA, NA, NA, NA, NA, NA, NA, NA, "L-007", NA, "L-005",
        NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA, NA,
        NA, NA, NA, NA, NA, NA, "M-004", "L-007", "L-007", "L-008", NA,
        NA, "S-002", "L-001", "A-020", NA, NA, "L-002", NA, "A-015",
        NA, NA, "A-013", "A-016", "A-001", "A-001", "A-001", NA, NA,
        NA, "L-007", "L-003", "L-002", "L-005", "A-001", "A-003", "A-007",
        NA, NA
      )
    ),
    row.names = c(NA, -77L), class = c("tbl_df", "tbl", "data.frame")
  )
  job <- create_pop_pedigree(at = "1996/01/01")
  expect_equal(ref, job)
})


test_that("find_id_id.descendant() works as intended", {
  ref1 <- c("A-041", "A-114")
  job1 <- find_id_id.descendant(ID = "A-013")
  expect_equal(ref1, job1)

  ref2 <- "A-041"
  job2 <- find_id_id.descendant(ID = "A-013", from = "1994-01-01", to = "1995-01-01")
  expect_equal(ref2, job2)
})

test_that("fetch_id_id.descendant() works as intended", {
  IDs <- find_clan_id("A")[1:3]
  job <- fetch_id_id.descendant(ID = IDs, from = "1994-01-01", to = "1995-01-01")
  ref <- list(`A-001` = c("A-010", "A-018", "A-046"), `A-002` = character(0), `A-003` = character(0))
  expect_equal(ref, job)
})
