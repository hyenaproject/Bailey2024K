context("Test functions related to social support")

test_that("create_dyad_interaction.table returns a data.frame", {
  result <- create_dyad_interaction.table()
  expect_is(result, "data.frame")
})

test_that("create_dyad_interaction.table returns the correct number of rows", {
  expected_rows <- 837
  result <- create_dyad_interaction.table()
  expect_equal(nrow(result), expected_rows)
})

test_that("create_dyad_interaction.table returns the correct column names", {
  expected_cols <- c("party1", "party2", "winner", "looser", "date")
  result <- create_dyad_interaction.table()
  expect_equal(colnames(result), expected_cols)
})

test_that("create_dyad_interaction.table err on overdefinition", {
  expect_error(create_dyad_interaction.table(ID.1 = "A-001", sex = "male"))
})

test_that("create_dyad_interaction.table filters by sex properly", {
  result <- create_dyad_interaction.table(sex = "female")
  expect_true(all(fetch_id_sex(result$party1) == "female"))
})
#
test_that("create_dyad_interaction.table filters by lifestage properly", {
  result <- create_dyad_interaction.table(lifestage = "philopatric")
  expect_true(all(fetch_id_lifestage(result$party1, at = result$date) == "philopatric"))
})

test_that("create_dyad_interaction.table filters by dates properly", {
  result <- create_dyad_interaction.table(from = "1997-01-01", to = "1997-02-15")
  expect_true(all(result$date >= as.Date("1997-01-01") & result$date <= as.Date("1997-02-15")))
})

test_that("recode_df.interaction_matrix returns a matrix", {
  df <- create_dyad_interaction.table()
  result <- recode_df.interaction_matrix(df)
  expect_is(result, "matrix")
})

test_that("recode_df.interaction_matrix returns the correct dimensions", {
  df <- create_dyad_interaction.table()
  result <- recode_df.interaction_matrix(df)
  expected_rows <- 61
  expected_cols <- 61
  expect_equal(dim(result), c(expected_rows, expected_cols))
})

test_that("recode_df.interaction_matrix returns a null diagonal", {
  df <- create_dyad_interaction.table()
  result <- recode_df.interaction_matrix(df)
  expect_true(all(diag(result) == 0))
})

test_that("recode_df.interaction_matrix returns the correct number of wins and loses", {
  df <- create_dyad_interaction.table()
  result <- recode_df.interaction_matrix(df)
  expect_equal(nrow(df), sum(result))
})
