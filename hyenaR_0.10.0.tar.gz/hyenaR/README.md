<!-- badges: start -->
[![R build status](https://github.com/hyenaproject/hyenaR/workflows/R-CMD-check/badge.svg)](https://github.com/hyenaproject/hyenaR/actions)
<!-- badges: end -->


<img src="https://github.com/hyenaproject/hexstickers/raw/master/hyenaR/hyenaR_logo.svg" alt="hyenaR" align="right" width="200"  onerror="https://github.com/hyenaproject/hexstickers/raw/master/hyenaR/hyenaR_logo.png">

# hyenaR

The goal of hyenaR is to provide a toolkit to work with the data of the [hyena project](https://hyena-project.com/).


## Installation

Installation from the current GitHub page is not recommended for this project.

Users should instead install the package for the [drat page](https://github.com/hyenaproject/drat) and __NOT__ from here.

Developers should fork and then clone the repos using `git clone https://TOKEN@github.com/USER/hyenaR` (with their correct token and username), work in their fork and submit changes via Pull Requests.


## Usage

See https://github.com/hyenaproject/hyenaR/wiki for some help on how to use this package.


## Code of conduct

Please note that the 'hyenaR' project is released with a
[Contributor Code of Conduct](.github/CODE_OF_CONDUCT.md).

By contributing to this project, you agree to abide by its terms.
