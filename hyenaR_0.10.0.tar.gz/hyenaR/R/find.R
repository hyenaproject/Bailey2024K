#' Obtain information about clans or the population
#'
#' These functions allows for the creating of vectors with various information about given clans or
#' the whole population. There are used to find out for example which hyenas exist, which clans
#' exist, the first sighting date for the whole population and so forth.
#'
#' ```find_xxx``` functions output a vector which items are not repeated (they are unique).
#' These functions can be used with inputs of length 1 or using vector.
#'
#' @inheritParams arguments
#' @name find_family
#' @aliases find_family find
#' @examples
#' ######## Load the dummy dataset (needed for all examples below):
#' load_package_database.dummy()
NULL


#' @describeIn find_family Create a vector of all clans
#'
#' @export
#' @examples
#'
#' #### Example of find_clan_name.all usage:
#'
#' ### find all clans in the data:
#' find_clan_name.all(main.clans = FALSE)
#'
#' ### find all crater floor clans in the data:
#' find_clan_name.all()
#'
find_clan_name.all <- function(main.clans = TRUE, full.clan.names = FALSE) {
  clan_details <- extract_database_table("clans")

  clans <- sort(clan_details$clanID)

  if (main.clans) {
    clan_details %>%
      dplyr::filter(.data$location1 == "floor") %>%
      dplyr::pull(.data$clanID) -> main_possible

    clans <- clans[clans %in% main_possible]
  }

  if (full.clan.names) {
    clan_details %>%
      dplyr::filter(.data$clanID %in% clans) %>%
      dplyr::pull(.data$clanname) -> clans
  }

  clans
}


#' @describeIn find_family find date of first sighting.
#' @export
#' @examples
#'
#' #### Example of find_pop_date.observation.first usage:
#' find_pop_date.observation.first()
#' find_pop_date.observation.first(from.conception = TRUE)
find_pop_date.observation.first <- function(from.conception = FALSE) {
  if (from.conception) {
    if (exists("date.observation.first.conception", envir = .database)) {
      return(.database$date.observation.first.conception)
    } else {
      sightings <- extract_database_table("sightings")
      output <- min(recode_x_date(sightings$date_time))
      .database$date.observation.first.conception <- output
      return(output)
    }
  } else {
    if (exists("date.observation.first", envir = .database)) {
      return(.database$date.observation.first)
    } else {
      sightings <- extract_database_table("sightings")
      output <- min(recode_x_date(sightings$date_time[(is.na(sightings$context) | (!is.na(sightings$context) & sightings$context != "conception")) &
        (is.na(sightings$observer) | (!is.na(sightings$observer) & sightings$observer != "BBC")) &
        (is.na(sightings$remarks) | (!is.na(sightings$remarks) & !grepl(pattern = "one-day visit", x = sightings$remarks)))]))
      .database$date.observation.first <- output
      return(output)
    }
  }
}


#' @describeIn find_family find date of last sighting.
#' @export
#' @examples
#'
#' #### Example of find_pop_date.observation.last usage:
#' find_pop_date.observation.last()
find_pop_date.observation.last <- function() {
  if (exists("date.observation.last", envir = .database)) {
    return(.database$date.observation.last)
  } else {
    sightings <- extract_database_table("sightings")
    if (any(is.na(sightings$date_time))) {
      warning("Some sighting dates are unknown in the dataset, please correct that.")
    }
    output <- max(recode_x_date(sightings$date_time), na.rm = TRUE)
    .database$date.observation.last <- output
    return(output)
  }
}


#' @describeIn find_family Returns earliest birthdate from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.birth.first()
find_pop_date.birth.first <- function() {
  if (exists("date.birth.first", envir = .database)) {
    return(.database$date.birth.first)
  } else {
    hyenas <- extract_database_table("hyenas")
    output <- min(hyenas$birthdate)
    .database$date.birth.first <- output
    return(output)
  }
}

#' @describeIn find_family Returns latest birthdate from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.birth.last()
find_pop_date.birth.last <- function() {
  if (exists("date.birth.last", envir = .database)) {
    return(.database$date.birth.last)
  } else {
    hyenas <- extract_database_table("hyenas")
    output <- max(hyenas$birthdate)
    .database$date.birth.last <- output
    return(output)
  }
}

#' @describeIn find_family Returns earliest known conception from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.conception.first()
find_pop_date.conception.first <- function() {
  if (exists("date.conception.first", envir = .database)) {
    return(.database$date.conception.first)
  } else {
    output <- find_pop_date.birth.first() - lubridate::days(110)
    .database$date.conception.first <- output
    return(output)
  }
}

#' @describeIn find_family Returns latest known conception from all individuals in the population.
#' @export
#' @examples
#' find_pop_date.conception.last()
find_pop_date.conception.last <- function() {
  if (exists("date.conception.last", envir = .database)) {
    return(.database$date.conception.last)
  } else {
    output <- find_pop_date.birth.last() - lubridate::days(110)
    .database$date.conception.last <- output
    return(output)
  }
}

#' @describeIn find_family Returns character vector of offspring.
#'
#' @return Character vector of offspring of a given filiation.
#' @export
#'
#' @examples
#' find_id_id.offspring(ID = "A-001")
find_id_id.offspring <- function(ID = NULL, from = NULL, to = NULL, at = NULL, filiation = NULL,
                                 .fill = TRUE, first.event = "birthdate", debug = FALSE) {
  # Similar find functions (e.g. find_id_id.mate) only allow 1 ID. Here we do the same
  ID <- check_function_arg.ID(ID, arg.max.length = 1L)

  # Check filiation. Fill if left empty
  filiation <- check_function_arg.filiation(filiation, .fill = TRUE)

  # Return message if searching for mother filiation of male or visa-versa.
  if (fetch_id_sex(ID) == "male" && all(stringr::str_detect(filiation, "mother"))) {
    message("Searching for mother filiation of male. No offspring possible.")
  } else if (fetch_id_sex(ID) == "female" && all(stringr::str_detect(filiation, "father"))) {
    message("Searching for father filiation of female. No offspring possible.")
  }

  # Other variables checked inside create function
  output <- create_id_offspring.table(
    ID = ID, from = from, to = to, at = at,
    .fill = .fill, first.event = first.event, debug = debug
  ) %>%
    dplyr::filter(.data$filiation %in% !!filiation)

  check_function_output(
    input.tbl = tibble::tibble(parentID = ID), output.tbl = output, join.by = "parentID",
    duplicates = "output", debug = debug, output.IDcolumn = "offspringID"
  )
}

#' @describeIn find_family Return all founder individuals.
#'
#' @return Character vector of founder individuals.
#' @export
#'
#' @examples
#' # Find all individuals born before the first sighting date
#' find_pop_id.founder(main.clans = FALSE)
find_pop_id.founder <- function(main.clans = FALSE) {
  if (main.clans) {
    output <- create_id_starting.table(clan = find_clan_name.all(main.clans = TRUE)) %>%
      dplyr::filter(fetch_id_is.founder(ID = .data$ID))
  } else {
    output <- create_id_starting.table() %>%
      dplyr::filter(fetch_id_is.founder(ID = .data$ID))
  }

  output$ID
}
