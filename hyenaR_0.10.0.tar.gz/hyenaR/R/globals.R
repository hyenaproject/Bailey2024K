## tells R CMD check to ignore testing whether those objects have no binding

utils::globalVariables(".database")
utils::globalVariables(".")
utils::globalVariables(c("sf_hyenaR"))
utils::globalVariables("overlaps")

## enables to use .data$ in dplyr calls and thus not having to
## do var <- NULL ## to please R CMD check
## it also has the benefits of not working if a variable outside the
## data is being used.
rlang::.data ## to avoid  "Namespace in Imports field not imported from: 'rlang'" during check
