#' Welcome to the R package hyenaR
#'
#' The goal of this package is to ease the manipulation of the data of the Ngorongoro hyena
#' project (https://hyena-project.com/). Explore the vignettes we created for you for a
#' information on how to use this package.
#'
#' @name hyenaR-package
#' @aliases hyenaR-package hyenaR
#'
#' @keywords package
#' @examples
#' \dontrun{
#' browseVignettes("hyenaR")
#' }
"_PACKAGE"
