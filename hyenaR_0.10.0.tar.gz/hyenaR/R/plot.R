#' Plot common summary statistics about hyena(s)
#'
#' These functions allow for the creation of common plots that can
#' be used to investigate changes over time in hyena clans or the population
#' as a whole. All `plot_xxx` functions use the `ggplot2` package
#' to generate plots.
#'
#' All these functions take a date range and time step as an input to
#' calculate and plot summary statistics at multiple time points.
#'
#' Note for developers: if `debug` is set to `TRUE` the functions
#' output a `tibble` (instead of a plot), that shows the data used for
#' generating plots.
#'
#' @inheritParams arguments
#' @name plot_family
#' @aliases plot_family plot
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_package_database.dummy()
NULL

#' @describeIn plot_family Plot adult sex ratio (# female/# adult) for one or many clans.
#'
#' @export
#' @examples
#' # Plot sex ratio for all clans
#' plot_clan_sex.ratio.adult(from = "1996-06-01", to = "1997-01-01", by = "6 month")
#'
#' # Make the same plot for just a single clan
#' plot_clan_sex.ratio.adult(clan = "A", from = "1996-06-01", to = "1997-01-01", by = "6 month")
plot_clan_sex.ratio.adult <- function(clan = NULL, from = NULL, to = NULL,
                                      .fill = TRUE, first.event = "observation", by, main.clans = TRUE, debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  clan <- check_function_arg.clan(clan, .fill = TRUE)
  date_range <- check_function_arg.date.fromtoat(from, to,
    arg.max.length = 1,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to

  date_seq <- find_date_sequence(from = from, to = to, by = by)

  input <- expand.grid(clan = clan, date = date_seq, stringsAsFactors = FALSE) %>%
    dplyr::mutate(sexratio = fetch_clan_sex.ratio.adult(clan = .data$clan, at = .data$date))

  if (debug) {
    return(input)
  }

  title <- paste("Clan sex ratio", paste(clan, collapse = ", "))
  ## Ideally we should add some more data to the database and .database object
  ## So that we know more about the database generated (i.e. when were the underlying .csv files last updated)
  subtitle <- paste("Plot generated on", Sys.Date(), "using database from ", find_pop_date.observation.last())
  y.label <- "Adult sex ratio (#male/#adults)"
  x.label <- "Date"

  input %>%
    dplyr::group_by(.data$clan) %>%
    dplyr::slice(dplyr::n()) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(label = recode_clan_name(.data$clan)) -> label.data

  plot_clan_graph.line(
    data.plot = input, label.data = label.data, x.var = .data$date, y.var = .data$sexratio,
    title = title, subtitle = subtitle, y.label = y.label, x.label = x.label
  )
}

#' @describeIn plot_family Plot adult sex ratio (# female/# adult) for whole population.
#'
#' @export
#' @examples
#' # Plot sex ratio for main clans
#' plot_pop_sex.ratio.adult(from = "1996-06-01", to = "1997-01-01", by = "6 month")
#'
#' # Plot sex ratio for all clans (also outside crater)
#' plot_pop_sex.ratio.adult(from = "1996-06-01", to = "1997-01-01", by = "6 month", main.clans = FALSE)
plot_pop_sex.ratio.adult <- function(from = NULL, to = NULL,
                                     .fill = TRUE, first.event = "observation", by, main.clans = TRUE, debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to,
    arg.max.length = 1,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to

  date_seq <- find_date_sequence(from = from, to = to, by = by)

  input <- dplyr::tibble(date = date_seq) %>%
    dplyr::mutate(clan = "All", sexratio = fetch_pop_sex.ratio.adult(at = .data$date, main.clans = main.clans))

  if (debug) {
    return(input)
  }

  title <- paste0("Population sex ratio (", ifelse(main.clans, "Crater clans", "All clans"), ")")
  ## Ideally we should add some more data to the database and .database object
  ## So that we know more about the database generated (i.e. when were the underlying .csv files last updated)
  subtitle <- paste("Plot generated on", Sys.Date(), "using database from ", find_pop_date.observation.last())
  y.label <- "Adult sex ratio (#male/#adults)"
  x.label <- "Date"

  plot_clan_graph.line(
    data.plot = input, x.var = .data$date, y.var = .data$sexratio,
    title = title, subtitle = subtitle,
    y.label = y.label, x.label = x.label
  )
}

#' @describeIn plot_family Plot adult ratio (# adult/# individuals) for one or many clans.
#'
#' @export
#' @examples
#' # Plot adult ratio for all clans
#' plot_clan_adult.ratio(from = "1996-06-01", to = "1997-01-01", by = "6 month")
#'
#' # Make the same plot for just a single clan
#' plot_clan_adult.ratio(clan = "A", from = "1996-06-01", to = "1997-01-01", by = "6 month")
plot_clan_adult.ratio <- function(clan = NULL, from = NULL, to = NULL,
                                  .fill = TRUE, first.event = "observation", by, main.clans = TRUE, debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  clan <- check_function_arg.clan(clan, .fill = TRUE)
  date_range <- check_function_arg.date.fromtoat(from, to,
    arg.max.length = 1,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to

  date_seq <- find_date_sequence(from = from, to = to, by = by)

  input <- expand.grid(clan = clan, date = date_seq, stringsAsFactors = FALSE) %>%
    dplyr::mutate(ageratio = fetch_clan_adult.ratio(clan = .data$clan, at = .data$date))

  if (debug) {
    return(input)
  }

  title <- paste("Clan adult ratio", paste(clan, collapse = ", "))
  ## Ideally we should add some more data to the database and .database object
  ## So that we know more about the database generated (i.e. when were the underlying .csv files last updated)
  subtitle <- paste("Plot generated on", Sys.Date(), "using database from ", find_pop_date.observation.last())
  y.label <- "Adult ratio (#adult/#individuals)"
  x.label <- "Date"

  input %>%
    dplyr::group_by(.data$clan) %>%
    dplyr::slice(dplyr::n()) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(label = recode_clan_name(.data$clan)) -> label.data

  plot_clan_graph.line(
    data.plot = input, label.data = label.data, x.var = .data$date, y.var = .data$ageratio,
    title = title, subtitle = subtitle, y.label = y.label, x.label = x.label
  )
}

#' @describeIn plot_family Plot adult ratio (# adult/# individual) for whole population.
#'
#' @export
#' @examples
#' # Plot adult ratio for main clans
#' plot_pop_adult.ratio(from = "1996-06-01", to = "1997-01-01", by = "6 month")
#'
#' # Plot adult ratio for all clans (also outside crater)
#' plot_pop_adult.ratio(from = "1996-06-01", to = "1997-01-01", by = "6 month", main.clans = FALSE)
plot_pop_adult.ratio <- function(from = NULL, to = NULL,
                                 .fill = TRUE, first.event = "observation", by, main.clans = TRUE, debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to,
    arg.max.length = 1,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to

  date_seq <- find_date_sequence(from = from, to = to, by = by)

  input <- dplyr::tibble(date = date_seq) %>%
    dplyr::mutate(
      ageratio = fetch_pop_adult.ratio(at = .data$date, main.clans = main.clans),
      clan = "All"
    )

  if (debug) {
    return(input)
  }

  title <- paste0("Population sex ratio (", ifelse(main.clans, "Crater clans", "All clans"), ")")
  ## Ideally we should add some more data to the database and .database object
  ## So that we know more about the database generated (i.e. when were the underlying .csv files last updated)
  subtitle <- paste("Plot generated on", Sys.Date(), "using database from ", find_pop_date.observation.last())
  y.label <- "Adult ratio (#adult/#individuals)"
  x.label <- "Date"

  plot_clan_graph.line(
    data.plot = input, x.var = date, y.var = .data$ageratio,
    title = title, subtitle = subtitle,
    y.label = y.label, x.label = x.label
  )
}

#' @describeIn plot_family Plot total clan size for one or many clans.
#'
#' @export
#' @examples
#' # Plot clan size for all clans
#' plot_clan_number.all(from = "1996-06-01", to = "1997-01-01", by = "6 month")
#'
#' # Make the same plot for just a single clan
#' plot_clan_number.all(clan = "A", from = "1996-06-01", to = "1997-01-01", by = "6 month")
plot_clan_number.all <- function(clan = NULL, from = NULL, to = NULL,
                                 .fill = TRUE, first.event = "observation", by,
                                 main.clans = TRUE, debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  clan <- check_function_arg.clan(clan, .fill = TRUE)
  date_range <- check_function_arg.date.fromtoat(from, to,
    arg.max.length = 1,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to

  date_seq <- find_date_sequence(from = from, to = to, by = by)

  input <- expand.grid(clan = clan, date = date_seq, stringsAsFactors = FALSE) %>%
    dplyr::mutate(clansize = fetch_clan_number.anysex.all(clan = .data$clan, at = .data$date))

  if (debug) {
    return(input)
  }

  title <- paste("Clan size", paste(clan, collapse = ", "))
  ## Ideally we should add some more data to the database and .database object
  ## So that we know more about the database generated (i.e. when were the underlying .csv files last updated)
  subtitle <- paste("Plot generated on", Sys.Date(), "using database from ", find_pop_date.observation.last())
  y.label <- "Number of individuals"
  x.label <- "Date"

  input %>%
    dplyr::group_by(.data$clan) %>%
    dplyr::slice(dplyr::n()) %>%
    dplyr::ungroup() %>%
    dplyr::mutate(label = recode_clan_name(.data$clan)) -> label.data

  plot_clan_graph.line(
    data.plot = input, label.data = label.data, x.var = .data$date, y.var = .data$clansize,
    title = title, subtitle = subtitle, y.label = y.label, x.label = x.label
  )
}

#' @describeIn plot_family Plot size of whole population.
#'
#' @export
#' @examples
#' # Plot size for main clans
#' plot_pop_number.all(from = "1996-06-01", to = "1997-01-01", by = "6 month")
#'
#' # Plot size for all clans (also outside crater)
#' plot_pop_number.all(from = "1996-06-01", to = "1997-01-01", by = "6 month", main.clans = FALSE)
plot_pop_number.all <- function(from = NULL, to = NULL,
                                .fill = TRUE, first.event = "observation", by, main.clans = TRUE, debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to,
    arg.max.length = 1,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to

  date_seq <- find_date_sequence(from = from, to = to, by = by)

  input <- dplyr::tibble(date = date_seq) %>%
    dplyr::mutate(
      clansize = fetch_pop_number.anysex.all(at = .data$date, main.clans = main.clans),
      clan = "All"
    )

  if (debug) {
    return(input)
  }

  title <- paste0("Population size (", ifelse(main.clans, "Crater clans", "All clans"), ")")
  ## Ideally we should add some more data to the database and .database object
  ## So that we know more about the database generated (i.e. when were the underlying .csv files last updated)
  subtitle <- paste("Plot generated on", Sys.Date(), "using database from ", find_pop_date.observation.last())
  y.label <- "Number of individuals"
  x.label <- "Date"

  plot_clan_graph.line(
    data.plot = input, x.var = .data$date, y.var = .data$clansize,
    title = title, subtitle = subtitle,
    y.label = y.label, x.label = x.label
  )
}

################################################################
################################################################

# THEMES AND PALETTES
# These should be applied in every `plot_family` function

#' hyenaR ggplot theme.
#'
#' @inheritParams arguments
#'
#' @return A ggplot theme
#' @export
#'
#' @examples
#' library(ggplot2)
#' ggplot(iris) +
#'   geom_point(aes(x = Petal.Length, y = Petal.Width)) +
#'   theme_hyenaR()
theme_hyenaR <- function(base.size = 12, base.family = "",
                         base.line.size = base.size / 20,
                         base.rect.size = base.size / 20,
                         tick.margins = 2.0) {
  half_line <- base.size / 2

  ggplot2::theme(
    # Elements in this first block aren't used directly, but are inherited
    # by others. These set the defaults for line, rectangle and text elements.
    line = ggplot2::element_line(
      colour = "black", size = base.line.size,
      linetype = 1, lineend = "round"
    ),
    rect = ggplot2::element_rect(
      fill = "white", colour = "black",
      size = base.rect.size, linetype = 1
    ),
    text = ggplot2::element_text(
      family = base.family, face = "plain",
      colour = "black", size = base.size,
      lineheight = 0.9, hjust = 0.5, vjust = 0.5, angle = 0,
      margin = ggplot2::margin(), debug = FALSE
    ),

    # These just follow the default line characteristics
    axis.line = NULL,
    axis.line.x = NULL,
    axis.line.y = NULL,

    # These affect the ticks and tick text in all circumstances (e.g. top and bottom axis)
    axis.text = ggplot2::element_text(size = ggplot2::rel(0.8), face = "bold"),
    axis.text.x = ggplot2::element_text(margin = ggplot2::margin(t = tick.margins * half_line / 2), vjust = 1),
    axis.text.x.top = ggplot2::element_text(margin = ggplot2::margin(b = tick.margins * half_line / 2), vjust = 0),
    axis.text.y = ggplot2::element_text(margin = ggplot2::margin(r = tick.margins * half_line / 2), hjust = 1),
    axis.text.y.right = ggplot2::element_text(margin = ggplot2::margin(l = tick.margins * half_line / 2), hjust = 0),
    axis.ticks = ggplot2::element_line(colour = "black", lineend = "round", size = ),
    axis.ticks.length = grid::unit(half_line / 2, "pt"),

    # These affect the axis labels
    axis.title.x = ggplot2::element_text(
      margin = ggplot2::margin(t = half_line * 4),
      vjust = 1, face = "bold", size = base.size * 1.25
    ),
    axis.title.x.top = ggplot2::element_text(
      margin = ggplot2::margin(b = half_line),
      vjust = 0, face = "bold"
    ),
    axis.title.y = ggplot2::element_text(
      angle = 90, margin = ggplot2::margin(r = half_line * 4),
      vjust = 0, face = "bold", size = base.size * 1.25
    ),
    axis.title.y.right = ggplot2::element_text(
      angle = -90, margin = ggplot2::margin(l = half_line),
      vjust = 0, face = "bold"
    ),

    # These affect plot legends
    legend.background = ggplot2::element_rect(colour = "black", fill = NA),
    legend.spacing = grid::unit(2 * half_line, "pt"),
    legend.spacing.x = NULL,
    legend.spacing.y = NULL,
    legend.margin = ggplot2::margin(half_line, half_line, half_line, half_line),
    legend.key = ggplot2::element_rect(fill = NA, colour = "white"),
    legend.key.size = grid::unit(1.2, "lines"),
    legend.key.height = NULL,
    legend.key.width = NULL,
    legend.position = "none",
    legend.text = ggplot2::element_text(family = base.family, size = ggplot2::rel(0.8)),

    # These affect the background of the whole panel (plotting area and outside plotting area)
    panel.background = ggplot2::element_rect(fill = "white", colour = NA),
    panel.border = ggplot2::element_blank(),
    panel.grid.major = ggplot2::element_blank(),
    panel.grid.minor = ggplot2::element_blank(),
    panel.spacing = grid::unit(half_line, "pt"),
    panel.spacing.x = NULL,
    panel.spacing.y = NULL,
    panel.ontop = FALSE,

    # These affect the plot headers if faceting
    strip.background = ggplot2::element_rect(fill = NA, colour = "black"),
    strip.text = ggplot2::element_text(
      size = ggplot2::rel(0.8),
      margin = ggplot2::margin(
        half_line, half_line,
        half_line, half_line
      )
    ),
    strip.text.x = NULL,
    strip.text.y = ggplot2::element_text(angle = -90),
    strip.placement = "inside",
    strip.placement.x = NULL,
    strip.placement.y = NULL,
    strip.switch.pad.grid = grid::unit(0.1, "cm"),
    strip.switch.pad.wrap = grid::unit(0.1, "cm"),

    # These affect the plot area itself (not around the axes)
    plot.background = ggplot2::element_rect(colour = "white"),
    plot.title = ggplot2::element_text(
      size = ggplot2::rel(1.75), hjust = 0.5, vjust = 1,
      margin = ggplot2::margin(b = half_line * 1.2)
    ),
    plot.subtitle = ggplot2::element_text(
      size = ggplot2::rel(1.1), hjust = 0.5, vjust = 1,
      margin = ggplot2::margin(b = half_line * 0.9)
    ),
    plot.caption = ggplot2::element_text(
      size = ggplot2::rel(0.9), hjust = 0.5, vjust = 1,
      margin = ggplot2::margin(t = half_line * 0.9)
    ),
    plot.margin = ggplot2::margin(
      t = half_line, r = half_line * 20,
      b = half_line, l = half_line
    ),
    complete = TRUE
  )
}

#' Return a color palette used to create clan level plots
#'
#' Note that non-main clans are all given the same color
#' palette, only main clans can be distinguished. Used inside
#' [plot_family] functions.
#'
#' @inheritParams arguments
#'
#' @return A vector of hex codes.
#' @export
#'
#' @examples
#' find_clan_palette(clan = c("A", "E"))
find_clan_palette <- function(clan) {
  ## Main clans are given unique distinct colors
  ## All rim clans are given dark grey, transient in light grey

  ## N.B. This needs to be specified with a fixed dataframe because
  ## the number/names of clans will vary if you're in the dummy v. full data
  main_clan_palette <- structure(list(
    clan = c(
      "A", "B", "C", "E", "F", "K", "L", "M", "N",
      "R", "S", "T", "U", "X", "Y", "All"
    ),
    values = c(
      "#A63F67", "#333333",
      "#333333", "#FB8B24", "#E36414", "#333333", "#0F4C5C", "#864074", "#52B788",
      "#333333", "#7B8CDE", "#D90368", "#333333", "#333333", "#999999", "#333333"
    )
  ), row.names = c(NA, -16L), class = c("tbl_df", "tbl", "data.frame"))

  main_clan_palette %>%
    dplyr::filter(.data$clan %in% !!clan) %>%
    dplyr::pull(.data$values)
}

#' @describeIn plot_family Create a path plot from summary data of clans.
#'
#' This function is used internally and shouldn't be used by users directly.
#'
#' @inheritParams arguments
#'
#' @export
#' @examples
#' # A simple example with made up data
#' input <- data.frame(
#'   clan = "A",
#'   date = seq.Date(as.Date("1997-01-01"),
#'     as.Date("1997-12-01"),
#'     by = "month"
#'   ),
#'   sexratio = runif(n = 12)
#' )
#'
#' label.data <- input[nrow(input), ]
#' label.data$label <- recode_clan_name("A")
#'
#' plot_clan_graph.line(
#'   data.plot = input, label.data = label.data, x.var = date, y.var = sexratio,
#'   title = "Airstrip clan", subtitle = "Sex ratio",
#'   y.label = "Sex ratio", x.label = "Date"
#' )
plot_clan_graph.line <- function(data.plot, label.data, x.var, y.var, title, subtitle, y.label, x.label) {
  y_name <- rlang::quo_name(rlang::enquo(y.var))

  baseplot <- ggplot2::ggplot(data = data.plot) +
    ggplot2::coord_cartesian(clip = "off") +
    ggplot2::geom_line(ggplot2::aes(x = {{ x.var }}, y = {{ y.var }}, colour = .data$clan), size = 3) +
    ggplot2::scale_colour_manual(values = find_clan_palette(unique(data.plot$clan)), name = "Clan name") +
    ggplot2::labs(title = title, subtitle = subtitle, y = y.label, x = x.label) +
    theme_hyenaR()

  if (y_name %in% c("sexratio", "ageratio")) {
    baseplot +
      ggplot2::geom_hline(yintercept = 0.5, lty = 2) +
      ggplot2::scale_y_continuous(limits = c(0, 1)) -> baseplot
  }

  if (data.plot$clan[1] != "All") {
    # Add labels with ggrepel if available
    if (!requireNamespace("ggrepel", quietly = TRUE)) {
      message("Plots work best with ggrepel installed. Consider installing ggrepel.")

      baseplot +
        ggplot2::geom_text(
          data = label.data, ggplot2::aes(x = {{ x.var }}, y = {{ y.var }}, colour = .data$clan, label = .data$label),
          hjust = 0, size = 7
        ) -> baseplot
    } else {
      loadNamespace("ggrepel")

      baseplot +
        ggrepel::geom_text_repel(
          data = label.data, ggplot2::aes(x = {{ x.var }}, y = {{ y.var }}, colour = .data$clan, label = .data$label),
          hjust = 0, size = 7
        ) -> baseplot
    }
  }

  baseplot
}
