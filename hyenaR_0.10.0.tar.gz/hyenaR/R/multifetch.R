#' Add multiple information about given hyena(s)
#'
#' These functions allows for extending a table containing at least the
#' column `id` by adding to it the information that is requested.
#'
#' Note for developers: if `debug` is set to `TRUE` the functions
#' output a tibble, with detailed information on what is
#' used for the computation.
#'
#' @inheritParams arguments
#' @name join_family
#' @aliases join_family join
#' @examples
#'
#'
#' ######## Load the dummy dataset (needed for all examples below):
#'
#' load_package_database.dummy()
NULL


#' @describeIn join_family Add a logical column for agonistic interactions
#' @export
#' @examples
#'
#' #### Simple example of join_agonistic usage:
#'
#' if (require(tibble)) { ## you need to load tibble to run this example
#'   tibble(
#'     party1 = c("A-001", "A-0x3", "A-001"),
#'     party2 = c("A-002", "A-002", "A-010+A-100"),
#'     winner = c("A-012", "A-0x3", "A-010+A-100")
#'   ) %>%
#'     join_agonistic()
#' }
#'
join_agonistic <- function(tbl) {
  winner <- party1 <- party2 <- diff_ID <- clear_winner <- NULL

  if (!"party1" %in% colnames(tbl)) stop("This function requires a column 'party1'.")
  if (!"party2" %in% colnames(tbl)) stop("This function requires a column 'party2'.")
  if (!"winner" %in% colnames(tbl)) stop("This function requires a column 'winner'.")

  tbl %>%
    dplyr::mutate(
      clear_winner = winner == party1 | winner == party2,
      diff_ID = party1 != party2,
      agonistic = clear_winner & diff_ID
    ) %>%
    dplyr::select(-"clear_winner", -"diff_ID")
}


#' @describeIn join_family All social rank information of a given individual on a given date.
#'
#' See [create_rank_python.table] for details on the lower level function used to retrieve such information.
#' @export
#' @examples
#'
#' if (require(dplyr)) { ## you need to load dplyr to run these examples
#'
#'   #### Simple example of join_allranks usage:
#'   create_id_starting.table(clan = "A", at = "1997-01-01") %>%
#'     mutate(date = as.Date("1997-01-01")) %>%
#'     join_allranks()
#'
#'   #### Same but output.nested:
#'   create_id_starting.table(clan = "A", at = "1997-01-01") %>%
#'     mutate(date = as.Date("1997-01-01")) %>%
#'     join_allranks(output.nested = TRUE)
#' }
#'
#' \dontrun{
#' if (require(dplyr)) {
#'   #### Example with missing information:
#'   create_id_starting.table() %>%
#'     mutate(date = fetch_id_date.birth(ID = ID)) %>%
#'     join_allranks()
#' }
#' }
#'
join_allranks <- function(tbl, output.nested = FALSE, debug = FALSE) {
  if (!"ID" %in% colnames(tbl)) stop("This function requires a column 'ID'.")
  if (!"date" %in% colnames(tbl)) stop("This function requires a column 'date'.")

  data_all_ranks <- create_id_rank.table(ID = tbl$ID, at = tbl$date)

  if (debug) {
    return(data_all_ranks)
  }

  tbl %>%
    dplyr::left_join(
      relationship = "many-to-many", data_all_ranks %>%
        dplyr::group_by(ID, date) %>%
        tidyr::nest(all_ranks = colnames(data_all_ranks %>%
          dplyr::select(-"ID", -"date", -"clan"))),
      by = c("ID", "date")
    ) -> output

  if (!output.nested) {
    output %>%
      tidyr::unnest("all_ranks") -> output
  }

  ID <- date <- clan <- NULL ## To please R CMD check

  output
}


#' @describeIn join_family Add a logical column for dyadic interactions
#' @export
#' @examples
#'
#' #### Simple example of join_dyadic usage:
#' if (require(tibble)) { ## you need to load tibble to run this example
#'   tibble(
#'     party1 = c("A-001", "A-0x3", "A-001"),
#'     party2 = c("A-002", "A-002", "A-010+A-100")
#'   ) %>%
#'     join_dyadic()
#' }
#'
join_dyadic <- function(tbl) {
  party1 <- party2 <- n_party1 <- n_party2 <- dyadic1 <- dyadic2 <- NULL

  if (!"party1" %in% colnames(tbl)) stop("This function requires a column 'party1'.")
  if (!"party2" %in% colnames(tbl)) stop("This function requires a column 'party2'.")


  tbl %>%
    dplyr::mutate(
      n_party1 = stringr::str_count(party1),
      n_party2 = stringr::str_count(party2),
      dyadic1 = n_party1 == 5 & n_party2 == 5,
      dyadic2 = stringr::str_detect(party1, ".-\\d{3}") & stringr::str_detect(party2, ".-\\d{3}"),
      dyadic = dyadic1 & dyadic2
    ) %>%
    dplyr::select(-"n_party1", -"n_party2", -"dyadic1", -"dyadic2")
}

#' @describeIn join_family returns several vectors that can be simply added to an already existing table
#' by mean of `dplyr::mutate()`. The output will contain 3 columns about the number of daughters, sons and
#' offspring with unknown sex (according to the filiation argument) that the ID gave birth to in the entire life.
#' @export
#' @examples
#'
#' #### Simple example of multifetch_id_offspring.count:
#' multifetch_id_offspring.count(ID = c("A-001", "A-008"))
#'
multifetch_id_offspring.count <- function(ID, filiation = c("mother_genetic", "mother_social_genetic", "father"), debug = FALSE) {
  ID <- check_function_arg.ID(ID)
  filiation <- check_function_arg.filiation(filiation)

  id_offspring.count <- create_id_offspring.count(ID, filiation = filiation)

  if (debug) {
    return(id_offspring.count)
  }

  id_offspring.count %>%
    dplyr::select(-"parentID")
}



#' @describeIn join_family returns several vectors that can be simply added to an already existing table
#' by mean of `dplyr::mutate()`. The output will contain 3 columns with different measures of observer effort
#' during the focal period: proportion of known adults sighted at least once, proportion of known cubs sighted
#' at least once, and proportion of all known individuals sighted at least once.
#' NOTE: This assumes that number of individuals sighted is related to observer effort.
#'
#' @export
#' @examples
#'
#' #### Simple examples of multifetch_clan_obsv.effort
#'
#' # Multiple clans over a date range
#' multifetch_clan_obsv.effort(
#'   clan = c("A", "L", "A"),
#'   from = c("1997-01-01", "1997-02-01", "1997-01-01"),
#'   to = c("1997-02-01", "1997-03-01", "1997-02-01")
#' )
#'
#' # Multiple clans on a single date
#' multifetch_clan_obsv.effort(
#'   clan = c("A", "L"),
#'   at = c("1997-01-01", "1997-02-01")
#' )
#'
multifetch_clan_obsv.effort <- function(clan = NULL, from = NULL, to = NULL, at = NULL,
                                        .fill = TRUE, first.event = "observation",
                                        debug = FALSE, CPUcores = NULL,
                                        .parallel.min = 200) {
  # Argument are checked inside the create function
  create_clan_obsv.effort.table(
    clan = clan, from = from, to = to, at = at,
    .fill = .fill, first.event = first.event, debug = debug,
    CPUcores = CPUcores,
    .parallel.min = .parallel.min
  ) %>%
    dplyr::select("effort_adult", "effort_cub", "effort_all") -> output

  output
}


#' @describeIn join_family returns several vectors that can be simply added to an already existing table
#' by mean of `dplyr::mutate()`. The output will contain 6 columns with different basic information
#' about the birth and the conception of the given IDs.
#'
#' @export
#' @examples
#'
#' #### Simple examples of multifetch_id_birth.info
#'
#' multifetch_id_birth.info(ID = c("A-001", "A-008", "A-100"))
#' multifetch_id_birth.info(ID = "A-001")
#' multifetch_id_birth.info(ID = c("A-008", "A-001"))
#'
multifetch_id_birth.info <- function(ID, debug = FALSE) {
  input <- tibble::tibble(ID = check_function_arg.ID(ID))


  input %>%
    dplyr::mutate(
      sex = fetch_id_sex(.data$ID),
      motherID = fetch_id_id.mother.genetic(.data$ID),
      fatherID = fetch_id_id.father(.data$ID),
      birthdate = fetch_id_date.birth(.data$ID),
      clan.birth = fetch_id_clan.birth(.data$ID),
      clan.conception = dplyr::if_else(is.na(.data$motherID), NA_character_,
        fetch_id_clan.current(
          .data$motherID,
          .data$birthdate - 110
        )
      )
    ) -> output
  output %>%
    dplyr::select(-"ID")
}

#' @describeIn join_family Fetch basic summary statistics of temperature for given weather station(s) on given date.
#'
#' @return A tibble with mean, max, min, and standard deviation of temperature in the focal period.
#' @export
#'
#' @examples
#' data.frame(
#'   from = "2022-04-01", to = "2022-04-30",
#'   station = "jua"
#' ) %>%
#'   dplyr::mutate(multifetch_weather_temp.summary(from = from, to = to, station = station))
multifetch_weather_temp.summary <- function(from = NULL, to = NULL, at = NULL,
                                            station = NULL, location = NULL) {
  fetch_weather_temp.mean(from = from, to = to, at = at, station = station, location = location) %>%
    dplyr::bind_cols(fetch_weather_temp.max(from = from, to = to, at = at, station = station, location = location)) %>%
    dplyr::bind_cols(fetch_weather_temp.min(from = from, to = to, at = at, station = station, location = location)) %>%
    dplyr::bind_cols(fetch_weather_temp.sd(from = from, to = to, at = at, station = station, location = location))
}

#' @describeIn join_family Fetch basic summary statistics of rainfall for given weather station(s) on given date.
#'
#' @return A tibble with mean, max, min, and standard deviation of rainfall in the focal period.
#' @export
#'
#' @examples
#' data.frame(
#'   from = "2022-04-01", to = "2022-04-30",
#'   station = "jua"
#' ) %>%
#'   dplyr::mutate(multifetch_weather_rain.summary(from = from, to = to, station = station))
multifetch_weather_rain.summary <- function(from = NULL, to = NULL, at = NULL,
                                            station = NULL, location = NULL) {
  fetch_weather_rain.mean(from = from, to = to, at = at, station = station, location = location) %>%
    dplyr::bind_cols(fetch_weather_rain.max(from = from, to = to, at = at, station = station, location = location)) %>%
    dplyr::bind_cols(fetch_weather_rain.min(from = from, to = to, at = at, station = station, location = location)) %>%
    dplyr::bind_cols(fetch_weather_rain.sd(from = from, to = to, at = at, station = station, location = location))
}
