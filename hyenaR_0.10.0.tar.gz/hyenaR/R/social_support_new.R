#' New set of functions to compute and plot the social support
#'
#' This set of functions will progressively superseed the functions used for the
#' NatEcoEvo paper on social support.
#'
#' @section Working with observed dyadic interactions:
#'
#' The main functions to work with observed dyadic interactions are
#' `create_dyad_interaction.table()` and `recode_df.interaction_matrix()`. The
#' first function allows to extract all dyadic interactions, while the second
#' function allows to turn the output of the first function into a winner-looser
#' matrix. The output of `create_dyad_interaction.table()` can be directly used
#' as an input for `recode_df.interaction_matrix()`. Yet, in practice it can be
#' useful to first filter the output of `create_dyad_interaction.table()` based
#' on characteristics of the individuals involved in the interactions or on the
#' characteristics of the interactions themselves. For retrieving the characteristics
#' of individuals, just use one of the `fetch_id_xxx()` functions. For retrieving
#' the characteristics of the interactions, use the `extracolumns` argument of
#' `create_dyad_interaction.table()`.
#'
#' @section Working with the social support algorithm:
#'
#' The main functions to work with the social support algorithm are
#' `create_clan_number.supporter()`, `recode_df.supporter_matrix()` and
#' `plot_clan_social.support()`. The plotting function is a shortcut since it
#' calls `create_clan_number.supporter()` and `recode_df.supporter_matrix()`
#' internally and plot the results. The function
#' `create_clan_number.supporter()` computes the number of social supporters for
#' all possible pairs of individuals in a clan. The function
#' `recode_df.supporter_matrix()` turns that output into a matrix of supporter
#' where the number correspond to the number of supporter for the individual in
#' row when it interacts with the individual in column.
#'
#'
#' @name social_support
#' @aliases social_support support socialsupport
#' @inheritParams arguments
#'
#' @examples
#'
#' ## loading dummy data for examples
#'
#' load_package_database.dummy()
#'
#'
#' #--------------------------------------------------------
#' ## Examples for how to use create_clan_number.supporter()
#' #--------------------------------------------------------
#'
#' ## mind that running this example takes a few minutes...
#' \dontrun{
#' ## compute the number of social supporters for all ID.1 against all ID.2 in a clan
#' support_tbl <- create_clan_number.supporter(clan = "A", at = "1997-10-01")
#'
#' ## turn the output into a tournament matrix
#' recode_df.supporter_matrix(support_tbl)
#' }
#'
#'
#' #----------------------------------------------------
#' ## Examples for how to use plot_clan_social.support()
#' #----------------------------------------------------
#'
#' ## mind that running this example takes a few minutes...
#' \dontrun{
#' plot_clan_social.support(clan = "A", at = "1997-01-01")
#' }
#'
#'
#' #---------------------------------------------------------
#' ## Examples for how to use create_dyad_interaction.table()
#' #---------------------------------------------------------
#'
#' ## simple extraction of interactions between two individuals
#' create_dyad_interaction.table("L-007", "L-042")
#'
#' ## extraction of all interactions in a clan between 2 dates
#' res <- create_dyad_interaction.table(clan = "L", from = "1997-01-01", to = "1997-02-15")
#' res
#' ## reshape as winner-looser matrix
#' recode_df.interaction_matrix(res)
#'
#' ## extraction of all interactions in between adult males
#' create_dyad_interaction.table(lifestage = "adult", sex = "male")
#'
#' ## extracting more information from the raw table storing interactions
#' create_dyad_interaction.table(extracolumns = c("power_context", "category"))
#'
NULL


#' @describeIn social_support compute the number of social supporter for all
#' individuals in a clan. The function assess the social support of all
#' individuals in a clan at a given time using the social support algorithm. It
#' considers that each clan member interacts with all other clan member. The
#' number of social supporters is reported for `ID.1` in the context of an
#' interaction between `ID.1` and `ID.2`. This function returns a tibble with
#' all pairwise combination of clan number and their social support.
#' @export
#'
create_clan_number.supporter <- function(clan, at, verbose = TRUE) {
  clan <- check_function_arg.clan(clan)
  date <- check_function_arg.date(at)

  IDs <- find_clan_id(clan = clan, at = date)

  expand.grid(ID.1 = IDs, ID.2 = IDs, stringsAsFactors = FALSE) |>
    as.data.frame() |>
    tibble::as_tibble() -> tbl

  if (verbose) message(paste("Computing social support for", nrow(tbl), "pairs of individuals... (be patient)"))

  ## rowwise version: 10-20% faster but no progress bar
  # tbl |>
  #   dplyr::rowwise() |>
  #   dplyr::mutate(n.supporters = find_dyad_number.supporter(ID.1 = .data$ID.1, ID.2 = .data$ID.2, at = !!date, verbose = FALSE)) |> ## or v(.data$ID.1), ID.2 = v(.data$ID.2)
  #   dplyr::ungroup() -> tbl

  ## map version: 10-20% slower but with progress bar
  tbl$n.supporters <- purrr::map2_vec(
    .x = tbl$ID.1, .y = tbl$ID.2, .f = find_dyad_number.supporter, # or v(tbl$ID.1), .y = v(tbl$ID.2)
    at = date, verbose = FALSE, .progress = TRUE
  ) ## slower
  tbl
}


#' @describeIn social_support turn a dataframe produced by
#' `create_clan_number.supporter()` into a matrix.
#' @export
#'
recode_df.supporter_matrix <- function(df) {
  df_wide <- tidyr::pivot_wider(df, names_from = "ID.2", values_from = "n.supporters")
  df_matrix <- as.matrix(df_wide[, -1])
  rownames(df_matrix) <- df_wide[, 1, drop = TRUE]
  df_matrix
}


#' @describeIn social_support Compute and plot the ranks according to social
#' support defined by the social support algorithm vs the observed ranks. The
#' function simulates a tournament between all individuals within a clan. Under
#' the default settings of the function, cubs are not displayed.
#' @export
#'
plot_clan_social.support <- function(clan, at, lifestage = "!cub") {
  if (!requireNamespace("EloRating", quietly = TRUE)) {
    stop("You must install the package EloRating to use this function, so copy/paste the following in your console:\n install.packages('EloRating')")
  }

  if (!requireNamespace("ggrepel", quietly = TRUE)) {
    stop("You must install the package ggrepel to use this function, so copy/paste the following in your console:\n install.packages('ggrepel')")
  }

  ## simulate a tournament between all pairs of individuals
  create_clan_number.supporter(clan = clan, at = at) |>
    recode_df.supporter_matrix() -> matrix_tournament

  ## select the ID corresponding to the lifestages to be included:
  create_id_starting.table(clan = clan, at = at, lifestage = lifestage) |>
    dplyr::pull(.data$ID) -> ID_to_keep

  ## compute David's score on tournament results
  results <- EloRating::DS(matrix_tournament[ID_to_keep, ID_to_keep])

  ## reformat the data for plotting
  results |>
    dplyr::arrange(dplyr::desc(.data$DS)) |>
    dplyr::mutate(
      migrant = fetch_id_is.migrant(.data$ID, at = !!at),
      sex = fetch_id_sex(.data$ID),
      rank = dplyr::dense_rank(fetch_id_rank(.data$ID, at = !!at))
    ) -> data_for_plot

  ## plotting
  ggplot2::ggplot(data_for_plot) +
    ggplot2::aes(y = .data$normDS, x = .data$rank, label = .data$ID, colour = .data$sex, shape = .data$migrant) +
    ggplot2::geom_point(size = 2) +
    ggrepel::geom_label_repel(max.overlaps = Inf, key_glyph = "point") +
    ggplot2::scale_x_reverse(limits = c(NA, 1), breaks = 1:500) +
    ggplot2::scale_y_continuous(breaks = seq(0, 50, by = 5), limits = c(0, NA)) +
    ggplot2::scale_color_manual(values = c("#8624F5", "#1FC3AA")) + # from telegraph: https://blog.datawrapper.de/gendercolor/
    ggplot2::labs(
      title = paste(recode_clan_name(clan, verbose = FALSE), at),
      x = "Observed ordinal rank",
      y = "Predicted cardinal rank (normDS)"
    ) +
    theme_hyenaR() +
    ggplot2::theme(legend.position = "right")
}


#' @describeIn social_support extract recorded interactions between two
#' individuals with the possibility to filter by date and sex, as well as by
#' clan and lifestage on the day of the interaction. The function returns a
#' tibble with all interactions.
#' @export
#'
create_dyad_interaction.table <- function(ID.1 = NULL, ID.2 = NULL, clan = NULL, main.clans = TRUE,
                                          from = NULL, to = NULL, at = NULL,
                                          lifestage = NULL,
                                          sex = NULL,
                                          extracolumns = NULL) {
  clan <- check_function_arg.clan(clan = clan, .fill = TRUE, main.clans = main.clans)
  lifestage <- check_function_arg.lifestage(lifestage, .fill = TRUE)

  if (!is.null(sex)) {
    if (!is.null(ID.1) || !is.null(ID.2)) {
      stop("You cannot provide `sex` if both `ID.1` or `ID.2` are specified in `create_dyad_interaction.table()`.")
    }
    sex <- check_function_arg.sex(sex, .fill = FALSE)
  } else {
    sex <- check_function_arg.sex(sex, .fill = TRUE)
  }

  ## guess IDs if ID.1 or ID.2 are not provided based on the clan, sex and range of dates
  ## Note: this overshoot since it will capture individuals that are not in the clan at the interaction date
  ## which is why we filter again after the extraction (see "## apply filters")
  if (is.null(ID.1)) {
    ID.1 <- find_clan_id(clan = clan, from = from, to = to, at = at, sex = sex)
  } else {
    ID.1 <- unique(check_function_arg.ID(ID.1, .fill = FALSE))
  }

  if (is.null(ID.2)) {
    ID.2 <- find_clan_id(clan = clan, from = from, to = to, at = at)
  } else {
    ID.2 <- unique(check_function_arg.ID(ID.2, .fill = FALSE))
  }

  ## select interaction involving the 2 IDs
  extract_database_table(tbl.names = "interactions") |>
    dplyr::select("party1", "party2", "winner", date = "date_time", !!extracolumns) |>
    ## we only retain cases for which pary1, party2 and winner are single individuals and not groups or other info
    dplyr::filter(
      nchar(.data$party1) == 5 & grepl("[A-Z]-\\d{3}", .data$party1),
      nchar(.data$party2) == 5 & grepl("[A-Z]-\\d{3}", .data$party2),
      nchar(.data$winner) == 5 & grepl("[A-Z]-\\d{3}", .data$winner)
    ) |>
    ## we only retain cases including ID.1 and ID.2 (which can be vectors)
    dplyr::filter((.data$party1 %in% ID.1 & .data$party2 %in% ID.2) |
      (.data$party1 %in% ID.2 & .data$party2 %in% ID.1)) |>
    ## we format the date properly
    dplyr::mutate(date = as.Date(.data$date)) |>
    ## we order the IDs in party1 and party2
    dplyr::mutate(
      party1_sorted = ifelse(.data$party1 < .data$party2, .data$party1, .data$party2),
      party2_sorted = ifelse(.data$party1 < .data$party2, .data$party2, .data$party1),
      party1 = .data$party1_sorted,
      party2 = .data$party2_sorted
    ) |>
    dplyr::select(-"party1_sorted", -"party2_sorted") |>
    ## we add the looser
    dplyr::mutate(
      looser = ifelse(.data$winner == .data$party1, .data$party2, .data$party1),
      .after = "winner"
    ) -> dyad_interaction_all

  ## we add information needed for filtering
  dyad_interaction_all |>
    dplyr::mutate(
      sex1 = fetch_id_sex(.data$party1),
      sex2 = fetch_id_sex(.data$party2),
      clan1 = fetch_id_clan.current(.data$party1, at = .data$date),
      clan2 = fetch_id_clan.current(.data$party2, at = .data$date),
      lifestage1 = fetch_id_lifestage(.data$party1, at = .data$date),
      lifestage2 = fetch_id_lifestage(.data$party2, at = .data$date)
    ) -> dyad_interaction_all

  ## apply filters
  dyad_interaction_all |>
    dplyr::filter(
      .data$sex1 %in% !!sex,
      .data$sex2 %in% !!sex,
      .data$clan1 %in% !!clan,
      .data$clan2 %in% !!clan,
      .data$lifestage1 %in% !!lifestage,
      .data$lifestage2 %in% !!lifestage
    ) -> dyad_interaction

  ## filter by dates
  min.date <- find_pop_date.observation.first()
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(
    from = from, to = to, at = at,
    .fill = TRUE,
    min.date = min.date,
    max.date = max.date,
    arg.max.length = Inf
  )

  from <- date_range$from
  to <- date_range$to

  dyad_interaction |>
    dplyr::filter(date >= from & date <= to) -> dyad_interaction

  ## final cleanup (we remove columns that can easily be rebuilt using fetch functions)
  dyad_interaction |>
    dplyr::select(-"clan1", -"clan2", -"lifestage1", -"lifestage2", -"sex1", -"sex2")
}


#' @describeIn social_support turn a dataframe produced by
#' `create_dyad_interaction.table()` into a winner-looser matrix.
#' @export
#'
recode_df.interaction_matrix <- function(df) {
  df |>
    dplyr::summarise(
      wins = sum(.data$winner == .data$party1),
      losses = sum(.data$winner == .data$party2),
      .by = c("party1", "party2")
    ) -> df_results

  expand.grid(
    party1 = unique(c(df_results$party1, df_results$party2)),
    party2 = unique(c(df_results$party1, df_results$party2))
  ) |>
    dplyr::left_join(df_results, by = c("party1", "party2")) |>
    dplyr::mutate(
      wins = ifelse(is.na(.data$wins), 0, .data$wins),
      losses = ifelse(is.na(.data$losses), 0, .data$losses)
    ) |>
    dplyr::arrange(.data$party1, .data$party2) -> df_full

  df_full |>
    dplyr::select(-"losses") |>
    tidyr::pivot_wider(names_from = "party2", values_from = "wins") |>
    tibble::column_to_rownames("party1") |>
    as.matrix() -> matrix_wins

  df_full |>
    dplyr::select(-"wins") |>
    tidyr::pivot_wider(names_from = "party1", values_from = "losses") |>
    tibble::column_to_rownames("party2") |>
    as.matrix() -> matrix_loses

  matrix_wins + matrix_loses
}
