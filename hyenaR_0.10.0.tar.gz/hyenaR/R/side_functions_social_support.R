#' Check if an individual is a migrant at a given time.
#'  Migrant being consider as any individuals that left the native clan at least once.
#'
#' @describeIn fetch_family fetch the migratory status of ID.
#' @return Returns a logical indicating if an ID is a migrant.
#' @export
#' @examples
#' fetch_id_is.migrant(ID = c("A-084", "A-010"), at = "1997-04-01", migrant.mother.as.native = TRUE)
#'
fetch_id_is.migrant <- function(ID, at, migrant.mother.as.native = FALSE) {
  input <- tibble::tibble(
    ID = check_function_arg.ID(ID),
    date = check_function_arg.date(at)
  )

  ## simplified and more robust way of finding migrants including selector xxx.
  possible_life_stage <- check_function_arg.lifestage(.fill = TRUE)
  migrants <- possible_life_stage[!possible_life_stage %in% c("cub", "natal", "philopatric", "subadult", "dead")]

  if (migrant.mother.as.native) {
    input %>%
      dplyr::distinct() %>%
      dplyr::mutate(
        life_stage = fetch_id_lifestage(.data$ID, .data$date),
        migrant = .data$life_stage %in% migrants,
        sex = fetch_id_sex(.data$ID),
        first_litter = fetch_id_date.birth.first(.data$ID),
        migrant = ifelse(.data$migrant & .data$sex == "female" & .data$first_litter <= .data$date, FALSE, .data$migrant)
      ) -> output
  } else {
    input %>%
      dplyr::distinct() %>%
      dplyr::mutate(
        life_stage = fetch_id_lifestage(.data$ID, .data$date),
        migrant = .data$life_stage %in% migrants
      ) -> output
  }

  check_function_output(input,
    output,
    join.by = c("ID", "date"),
    duplicates = "input",
    output.IDcolumn = "migrant"
  )
}

#' Check if an individual is the descendant of another individual.
#' As the function uses
#'
#' @describeIn fetch_family is descendant.
#'
#' Note that if several ancestorID are provided, the same lot will be used each time to match each ID (it won't match one ID to one ancestorID even if the vectors are of same length).
#'
#' @return Returns a logical vector indicating if each ID is a descendant of at least one ancestorID.
#' @export
#' @examples
#' fetch_id_is.descendant(ID = c("A-010", "A-084"), ancestorID = c("A-001"))
#'
fetch_id_is.descendant <- function(ID, ancestorID, filiation = "mother_social") {
  filiation <- check_function_arg.filiation(filiation)
  input <- tibble::tibble(
    ID = check_function_arg.ID(ID),
    ancestorID = list(check_function_arg.ID(ancestorID, argument.name = "ancestorID"))
  ) ## as list to keep it similar for all IDs.


  input %>%
    dplyr::distinct() %>%
    dplyr::rowwise() %>%
    dplyr::mutate(
      ancestors = list(find_id_id.ancestor.all(.data$ID, filiation = {{ filiation }})),
      is.descendant = any(.data$ancestors %in% .data$ancestorID)
    ) -> output

  check_function_output(
    input.tbl = input,
    output.tbl = output,
    join.by = "ID",
    output.IDcolumn = "is.descendant",
    duplicates = "input"
  )
}


#' @describeIn fetch_family fetch the ID of the offspring of an ancestor in the line of the focal individual
#' @return The ID of the offspring of the ancestor in the line of the individual.
#' @export
#' @examples
#' fetch_id_id.offspring.from.ancestor(ID = "A-084", ancestorID = c("A-001"))
#'
fetch_id_id.offspring.from.ancestor <- function(ID, ancestorID, filiation = "mother_social") {
  input <- tibble::tibble(
    ID = check_function_arg.ID(ID),
    ancestorID = check_function_arg.ID(ancestorID, argument.name = "ancestorID")
  )


  output <- input %>%
    dplyr::distinct() %>%
    dplyr::rowwise() %>%
    dplyr::mutate(
      ancestors = list(find_id_id.ancestor.all(.data$ID, .data$ancestorID, filiation = {{ filiation }})),
      offspringID = .data$ancestors[(length(.data$ancestors) - 1)]
    ) ## take the previous one...


  check_function_output(input,
    output,
    join.by = "ID",
    duplicates = "input",
    output.IDcolumn = "offspringID"
  )
}

#' Find the descendant of the youngest offspring of a given ancestor.
#'
#' @describeIn find_family find the ID of the descendant of the youngest offspring of the MRCA.
#' @return Returns a logical indicating if an ID is a migrant.
#' @export
#' @examples
#' find_id_id.descendant.of.youngest.offspring(ID = c("A-010", "A-084"), mrcaID = "A-001")
find_id_id.descendant.of.youngest.offspring <- function(ID, mrcaID, filiation = "mother_social", debug = FALSE) {
  input <- tibble::tibble(
    ID = check_function_arg.ID(ID),
    mrcaID = check_function_arg.ID(mrcaID, argument.name = "mrcaID")
  )

  input %>%
    dplyr::distinct() %>%
    dplyr::mutate(
      offspringID = fetch_id_id.offspring.from.ancestor(.data$ID, .data$mrcaID),
      birthdate = fetch_id_date.birth(.data$offspringID)
    ) -> output ## change here to use litter

  ### check output here can be useful for debug.
  out <- check_function_output(input,
    output,
    join.by = "ID",
    duplicates = "input",
    debug = debug
  )

  out2 <- out$ID[out$birthdate == max(out$birthdate)] ## NA if any NA in birthdates, otherwise 2 winner if equal.

  if (length(out2) > 1) {
    NA
  } else {
    out2
  } ## Note: NA if more than 1 winner, but could be changed to work with more
}


#################################################################################

#' find_id_id.mate
#' @describeIn find_family find all the mates to an ID.
#' @return A vector of ID.
#' @export
#' @examples
#' find_id_id.mate(ID = "L-003")
find_id_id.mate <- function(ID) { ## TODO: add from, to, at

  input <- tibble::tibble(ID = check_function_arg.ID(ID, arg.max.length = 1))

  hyenas <- extract_database_table("hyenas")

  which_females <- which(hyenas$mothergenetic %in% ID)
  which_males <- which(hyenas$father %in% ID)
  mates_of_females <- unique(hyenas$mothergenetic[which_males])
  mates_of_males <- unique(hyenas$father[which_females])
  mates <- c(mates_of_females, mates_of_males)
  mates[!is.na(mates)]
}

#################################################################################

#' @describeIn find_family find all ID that are present in the dummy dataset
#' @return A vector of ID.
#' @export
#' @examples
#' find_pop_id.dummy()
#'
find_pop_id.dummy <- function() {
  ID.possible <- c(
    "A-001", "A-002", "A-003", "A-004", "A-006", "A-007", "A-008",
    "A-009", "A-010", "A-011", "A-013", "A-014", "A-015", "A-016",
    "A-017", "A-018", "A-019", "A-020", "A-040", "A-041", "A-042",
    "A-043", "A-044", "A-045", "A-046", "A-047", "A-048", "A-049",
    "A-050", "A-051", "A-052", "A-053", "A-054", "A-055", "A-056",
    "A-057", "A-058", "A-080", "A-081", "A-082", "A-083", "A-084",
    "A-085", "A-086", "A-087", "A-088", "A-089", "A-090", "A-091",
    "A-092", "A-093", "A-094", "A-095", "A-096", "A-097", "A-098",
    "A-099", "A-100", "A-113", "A-114", "L-001", "L-002", "L-003",
    "L-004", "L-005", "L-006", "L-007", "L-008", "L-009", "L-010",
    "L-011", "L-012", "L-013", "L-014", "L-015", "L-040", "L-041",
    "L-042", "L-043", "L-044", "L-045", "L-046", "L-047", "L-048",
    "L-049", "L-080", "L-081", "L-082", "L-083", "L-084", "L-085",
    "L-086", "L-087", "L-088", "L-089", "L-090", "L-091", "L-092",
    "L-093", "L-094", "L-095", "L-096", "L-097", "L-098", "L-099",
    "L-100", "L-101", "L-102", "L-103", "L-104", "L-105", "L-106",
    "L-108", "L-109", "L-110", "M-004", "M-047", "M-051", "M-053",
    "N-043", "S-002", "S-043"
  ) ## Note: this is hard coded, but the tests do check that the list is up to date!
  ## This is much easier than reloading the dummy on the fly or than filtering IDs based
  ## on rules used to build the dummy dataset that may change...
  ID.possible
}
