#' Determine the rank of given hyena(s) on a given date
#'
#' Uses python functions to determine the rank and standardized rank of given
#' individuals at a given date.
#'
#' @inheritParams arguments
#' @return Will return a tibble with ranks calculated for each individual
#' @export
#'
#' @examples
#'
#' # Run with dummy database
#' load_package_database.dummy()
#' input_df <- data.frame(
#'   ID = c("M-047", "A-001"),
#'   date = c("1997-09-30", "1997-01-01"),
#'   stringsAsFactors = FALSE
#' )
#' create_rank_python.table(py.input.tbl = input_df)
#'
create_rank_python.table <- function(py.input.tbl) {
  ## Check the input file is in the correct format:
  if (class(py.input.tbl)[1] == "matrix" || (is.vector(py.input.tbl) && !class(py.input.tbl)[1] == "list")) {
    stop("py.input.tbl must be either a dataframe, tibble or named list")
  }

  ## check and improve input (used to reshape output):
  py.input.tbl$ID <- check_function_arg.ID(py.input.tbl$ID)
  py.input.tbl$date <- check_function_arg.date(py.input.tbl$date) ## turns date as Date if needed
  if (!"tbl_df" %in% class(py.input.tbl)) {
    py.input.tbl <- tibble::as_tibble(py.input.tbl)
  }

  ## copy not to modify raw py.input.tbl:
  input_for_py <- py.input.tbl

  if (inherits(input_for_py$date, "Date")) {
    input_for_py$date <- as.character(input_for_py$date)
  }

  ## Run python code to include extra functions and Ilja's function library:
  reticulate::py_run_file(system.file("extdata", "ranks.py", package = "hyenaR", mustWork = TRUE))
  reticulate::py_run_file(system.file("extdata", "other_func.py", package = "hyenaR", mustWork = TRUE))

  ## Run the main_R function to get ranks of all individuals:
  ### Before we can do this, we reshape the input as a list
  ### with each item being another list with hyena ID and date

  input_list <- apply(input_for_py, 1, function(i) list(ID = i[[1]][1], date = i[[2]][1]))

  ## Run the python function on this input::
  output_file <- reticulate::py$main_R(.database$db.path, input_list)

  # output_file is a dictionary.
  # It behaves like a dataframe (you can extract a column with dataframe$x)
  # However, it doesn't display and can't be indexed!
  # Therefore, we turn the dictionary into a list
  output_R_temp <- lapply(names(output_file), function(x) output_file[x])
  # we then assign list names from the original file
  names(output_R_temp) <- names(output_file)
  # And finally, we use bind_rows to convert it into a dataframe
  # Python provides None when data is missing...R translates this into NULL rather than NA.
  # For cases where no rank could be determined, we need to map through and replace these with NAs.

  prototype <- list(
    ID = NA_character_,
    clan = NA_character_,
    date = NA_character_,
    clantotal = NA_integer_,
    clanadults = NA_integer_,
    rank = NA_integer_,
    rank_std = NA_real_,
    gender_rank = NA_integer_,
    gender_rank_std = NA_real_,
    sel_rank = NA_integer_,
    sel_rank_std = NA_real_,
    nat_rank = NA_integer_,
    nat_rank_std = NA_real_,
    adnat_rank = NA_integer_,
    adnat_rank_std = NA_real_
  )

  recode_dict_list <- function(dict, prototype) {
    for (var in names(dict)) {
      if (length(dict[[var]]) > 1) {
        for (i in seq_along(dict[[var]])) {
          if (is.null(dict[[var]][[i]])) {
            dict[[var]][i] <- prototype[[var]][[1]]
          }
        }
        dict[[var]] <- unlist(dict[[var]])
      }
      if (is.null(dict[[var]][[1]])) {
        dict[[var]] <- prototype[[var]][[1]]
      }
      class(dict[[var]][[1]]) <- class(prototype[[var]][[1]])
    }
    dict[names(prototype)]
  }

  ## Replace nested NULL by NA and fix classes using prototype:
  output_R_temp_for_df <- recode_dict_list(output_R_temp, prototype)

  tibble::as_tibble(output_R_temp_for_df) |>
    ## Convert to proper data type.
    ## 'rank' columns should be integer because it is a count of position.
    ## 'rank_std' columns should be numeric because they are standardized and so are not always whole numbers.
    ## 'date' column should by Date.
    dplyr::mutate(dplyr::across(tidyselect::contains("rank") & !tidyselect::contains("rank_"), .fns = as.integer)) |>
    dplyr::mutate(dplyr::across(tidyselect::contains("rank_std"), .fns = as.numeric)) |>
    dplyr::mutate(date = as.Date(date)) -> output_R

  ## Reorder as in input:
  output_R <- dplyr::left_join(relationship = "many-to-many", py.input.tbl, output_R, by = c("ID", "date"))

  ## Check to see if any have failed and throw a warning:
  apply(output_R, 1, FUN = function(x) {
    if (all(is.na(x[!names(x) %in% c("ID", "clan", "date")]))) {
      warning(paste0("Could not recover rank information for individual ", x["ID"], " on date ", x["date"], "."))
    }
  })

  ## Output:
  output_R
}
