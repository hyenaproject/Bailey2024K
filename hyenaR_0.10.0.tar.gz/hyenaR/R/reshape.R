#' Find dates along a sequence
#'
#' Creates a vector of dates at regular intervals. This
#' is particularly useful to prepare dates used to retrieved characteristics
#' of hyenas that vary over their life. See [reshape_row_date.seq()] for a wrapper
#' function that uses this function to directly expand a table created with functions from the create
#' family (e.g. [create_id_starting.table()]). As in [seq.Date()], you can here choose just 2 out of the four
#' arguments `from`, `to`, `by`, `length.out` and the others will be deduced.
#'
#' @inheritParams arguments
#' @export
#' @seealso [seq.Date()], [reshape_row_date.seq()], [reshape_row_age.seq()]
#'
#' @examples
#'
#' ### we first load the database (needed to test the inputs!):
#' load_package_database.dummy()
#'
#' ### create 10 dates, every month, starting from one date:
#' find_date_sequence(from = "1997/01/01", by = "month", length.out = 10)
#'
#' ### create 10 dates, every 2 months, starting from one date:
#' find_date_sequence(from = "1997/01/01", by = "2 month", length.out = 10)
#'
#' ### create as many dates as necessary, every month, between two dates:
#' find_date_sequence(from = "1997/01/01", to = "1997/10/01", by = "month")
#'
#' ### create as many dates as necessary, every 30 days, between two dates:
#' find_date_sequence(from = "1997/01/01", to = "1997/10/01", by = "30 days")
#'
#' ### create as many dates as necessary, every 30 days, for the whole
#' ### observation period:
#' find_date_sequence(by = "30 days")
#'
find_date_sequence <- function(from = NULL, to = NULL, by = NULL, length.out = NULL,
                               .fill = TRUE,
                               min.date = find_pop_date.observation.first(),
                               max.date = find_pop_date.observation.last()) {
  ## NA date if something is missing:
  if (!is.null(from) && is.na(from)) {
    return(as.Date(NA))
  }
  if (!is.null(to) && is.na(to)) {
    return(as.Date(NA))
  }
  if (!is.null(by) && is.na(by)) {
    return(as.Date(NA))
  }
  if (!is.null(length.out) && is.na(length.out)) {
    return(as.Date(NA))
  }

  ## test arguments
  daterange <- check_function_arg.date.fromtoat(from, to,
    .fill = .fill,
    max.date = max.date,
    min.date = min.date
  )
  from <- daterange$from

  # When length.out is provided we cannot have a `to` value (seq will fail!)
  # We need to explicit assign it to NULL because it will be filled in with
  # last observation by default when .fill = TRUE
  if (!is.null(length.out) && !is.null(by)) {
    to <- NULL
  } else {
    to <- daterange$to
  }

  by <- check_function_arg.period(period = by, null.ok = TRUE, coerce = FALSE)
  ## FIXME: test argument length.out

  ## create argument list to convert NULL as missing:
  argList <- list(from = from, to = to, by = by, length.out = length.out)
  argList <- argList[!unlist(lapply(argList, function(arg) {
    is.null(arg)
  }))]

  ## convert arguments to date:
  if (!is.null(from)) argList$from <- as.Date(from)
  if (!is.null(to)) argList$to <- as.Date(to)

  ## guessing missing arguments
  if (is.null(from) && is.null(to) && (!is.null(by) || !is.null(length.out))) {
    argList$from <- min.date
    argList$to <- max.date
  }

  ## create the sequence:
  do.call(seq.Date, argList)
}


#' Reshape a table by repeating rows for different dates
#'
#' This function allows for repeating rows in a table so to obtain one row
#' per date with dates spanned at regular intervals. It
#' is particularly useful to prepare a table to which the characteristic of
#' individuals will be retrieved along their life. If you need to stretch
#' a table to gather information on hyenas at given ages, use
#' [reshape_row_age.seq()] instead.
#'
#' To keep columns such as `ID` in your output, you must mention such columns in
#' the function call. There is no argument for that, it simply follows the
#' tidyselect approach as in [dplyr::select()]
#'
#' This function internally relies on [find_date_sequence()].
#'
#' @param ... one or more unquoted expressions separated by commas indicating which
#' variables to keep in the output. Variable names can be used as if they were
#' positions in the data frame, so expressions like x:y can be used to
#' select a range of variables (see [dplyr::select()] for details).
#' @inheritParams arguments
#'
#' @export
#' @seealso [find_date_sequence()], [reshape_row_age.seq()]
#'
#' @examples
#' #### Detailed example of reshape_row_date.seq usage:
#'
#' ### we want to retrieve if hyenas from clan "A" where alive of not every 6 months
#' ### during the entire observation period
#'
#' ## step 1. we load the database:
#' load_package_database.dummy()
#'
#' ## step 2. we create the hyena table of individuals from clan "A":
#' my_hyenas <- create_id_starting.table(clan = "A")
#'
#' ## step 3. we expand the hyena table to repeat each row at each date
#' ## and add survival info:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'
#'   my_hyenas %>%
#'     reshape_row_date.seq(
#'       by = "6 month",
#'       ID
#'     ) %>%
#'     mutate(surv = fetch_id_is.alive(ID = ID, at = date))
#'
#'   ### Other example: we want to retrieve the rank of hyenas from clan "A"
#'   ### every 6 months until they reach 2 years old (or the end of the
#'   ### observation period):
#'   my_hyenas %>%
#'     mutate(
#'       birthdate = fetch_id_date.birth(ID = ID),
#'       enddate = fetch_id_date.at.age(ID = ID, age = 2)
#'     ) %>%
#'     filter(enddate < find_pop_date.observation.last()) %>%
#'     reshape_row_date.seq(ID, from = birthdate, to = enddate, by = "6 months") %>%
#'     mutate(rank = fetch_id_rank(ID = ID, at = date))
#'   ## note: expect many NAs on dummy dataset
#' }
#'
reshape_row_date.seq <- function(tbl, ..., from = NULL, to = NULL, by = NULL, length.out = NULL,
                                 .fill = TRUE,
                                 min.date = find_pop_date.observation.first(),
                                 max.date = find_pop_date.observation.last()) {
  table <- check_function_arg.tbl(tbl)

  ## Testing from, to and by is extremely difficult to do here properly because these arguments can refer to actual values,
  ## a placeholder to a column name, or a place holder to an object.
  ## Therefore, we delay the test of such argument within the inner function find_date_sequence() since
  ## any placeholder would have been evaluated in there.

  ## Similarly, ... is not tested here because it would be tricky to handle that in a way that would fully support NSE.
  ## Since dplyr does the test, let's rely on the error message produced by it.

  ## TODO? add ID to ... if present in table

  ## turn arguments into columns:
  table %>%
    tibble::rownames_to_column(var = ".row") %>%
    dplyr::mutate(
      from = {{ from }},
      to = {{ to }},
      by = {{ by }},
      length.out = {{ length.out }}
    ) -> input

  ## expand the table:
  input %>%
    dplyr::group_by(.data$.row, ...) %>%
    dplyr::mutate(date = list(find_date_sequence(
      from = from, ## No .data$ here since we want dplyr to default to !!arg when column is missing (which happens if arg is NULL)
      to = to,
      by = by,
      length.out = length.out,
      min.date = min.date,
      max.date = max.date
    ))) %>% ## Note: group_modify changes the order of rows, so better use nest/unnest approach
    tidyr::unnest("date") %>%
    dplyr::ungroup() %>%
    dplyr::select(..., "date") -> output

  output
}


#' Reshape a table by repeating rows for different ages
#'
#' This function allows for repeating rows in a table so to obtain one row
#' per age with age spanned at any intervals. It
#' is particularly useful to prepare a table to which the characteristic of
#' individuals will be retrieved along their life. If you need to stretch
#' a table to gather information on hyenas at given dates, use
#' [reshape_row_date.seq()] instead.
#'
#' To keep columns such as `ID` in your output, you must mention such columns in
#' the function call. There is no argument for that, it simply follows the
#' tidyselect approach as in [dplyr::select()].
#'
#' @inheritParams reshape_row_date.seq
#' @inheritParams arguments
#' @export
#' @seealso [find_date_sequence()], [reshape_row_age.seq()]
#'
#' @examples
#' #### Simple example of reshape_row_age.seq usage:
#'
#' ## step 1. we load the databse:
#' load_package_database.dummy()
#'
#' ## step 2. we create the hyena table of individuals alive at 1st January 1997:
#' my_hyenas <- create_id_starting.table(at = "1997/01/01")
#'
#' ## step 3. application:
#' reshape_row_age.seq(my_hyenas, ID, age = c(1, 2, 5))
#'
#' reshape_row_age.seq(my_hyenas, ID, age = c(6, 2), unit = c("month", "year"))
#'
#'
#' #### Advanced example of reshape_row_age.seq usage:
#'
#' ### Getting the survival at 0, 2, 6, 120 months:
#'
#' if (require(dplyr)) { ## you need to load dplyr to run this example
#'   my_hyenas %>%
#'     reshape_row_age.seq(age = c(0, 2, 6, 120), unit = "month", ID) %>%
#'     mutate(
#'       date = fetch_id_date.at.age(ID = ID, age = age, unit = "month"),
#'       surv = fetch_id_is.alive(ID = ID, at = date)
#'     )
#' }
#'
reshape_row_age.seq <- function(tbl, ..., age, unit = "year") {
  ## format the input (assume that age cannot be in tbl since the point is to repeat it):
  tibble::tibble(age = {{ age }}) -> input

  ## testing input:

  tbl <- check_function_arg.tbl(tbl)
  ### TODO: test age?
  ### ... is not tested here because it would be tricky to handle that in a way that would fully support NSE.
  ### Since dplyr does the test, let's rely on the error message produced by it.
  ### Note: unit is tested at the end of this function!

  ## TODO? add ID to ... if present in tbl

  ## add unit to input only if not in tbl:
  ## Note: this is complex but this allows for unit to be potentially defined by a column in the tbl...
  if (!is.symbol(substitute(unit)) || check_function_class.is.character(unit)) {
    ## the double test is needed because we want to capture here both
    ## argument defined in function call and placeholder that do not refer to a column in the tbl
    input$unit <- unit
    unit_in_tbl <- FALSE
  } else {
    unit_in_tbl <- TRUE
  }

  ## expand the tbl:

  ### add row number for main grouping:
  tbl %>%
    tibble::rownames_to_column(var = ".row") -> output_temp

  ### depending on where unit is located, we need to adjust the tbl:
  if (unit_in_tbl) {
    output_temp %>%
      dplyr::group_by(.data$.row, {{ unit }}, ...) %>%
      dplyr::mutate(age = list(input$age), unit = {{ unit }}) -> output_temp
  } else {
    output_temp %>%
      dplyr::group_by(.data$.row, ...) %>%
      dplyr::mutate(age = list(input$age), unit = list(input$unit)) -> output_temp
  }

  ## expansion per se:
  output_temp %>%
    tidyr::unnest(c("age", "unit")) %>%
    dplyr::ungroup() %>%
    dplyr::select(..., "age", "unit") -> output

  ## we test the argument unit at the end, to avoid tackling NSE:
  output$unit <- check_function_arg.unit(output$unit)

  output
}
