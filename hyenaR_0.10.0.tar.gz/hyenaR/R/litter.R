#' Extract or compute information about litters
#'
#' This set of functions allows to extract or compute information about litters.
#' The main powerhouse function behind the scene is
#' `create_offspring_litter.table()`, which takes as input IDs of the mothers
#' and extract their offspring and classify them into litters. Note that this
#' function considers genetic and social offspring. When social offspring are
#' adopted within 110 days before or after the birth of genetic cubs, they are
#' considered as part of the same litter. The same individual can sometimes thus
#' belong to two different litters (in one, it is included as a genetic cub and
#' in the other it is included as a social cub). From a user's perspective, the
#' most useful functions are probably `create_litter_starting.table()`, which
#' allows to start with a table with a single column listing litters; and
#' `fetch_id_litterID()`, which retrieves the litter ID in which the given ID(s)
#' are "born". See section **Functions** below for explanation on what all
#' functions do.
#'
#' @name litter
#' @aliases litter litters
#' @inheritParams arguments
#' @seealso [offspring]
#'
#' @examples
#'
#' ## loading dummy data for examples
#'
#' load_package_database.dummy()
#'
#'
#' #---------------------------------------------------------
#' ## Examples for how to use create_offspring_litter.table()
#' #---------------------------------------------------------
#'
#' ## Display all cubs and litters of 3 parents:
#' create_offspring_litter.table(c("A-001", "L-003", "A-098"))
#'
#'
#' #--------------------------------------------------------
#' ## Examples for how to use create_litter_starting.table()
#' #--------------------------------------------------------
#'
#' ## Extract just the litter IDs of 3 parents:
#' create_litter_starting.table(c("A-001", "L-003", "A-098"))
#'
#'
#' #---------------------------------------------------------
#' ## Examples for how to use create_litter_offspring.count()
#' #---------------------------------------------------------
#'
#' ## Show detail about the offspring number behind a litter:
#' create_litter_offspring.count("A-001_003")
#'
#'
#' #---------------------------------------------------------
#' ## Examples for how to use create_litter_offspring.table()
#' #---------------------------------------------------------
#'
#' ## Show detail about the offspring behind 2 litters:
#' create_litter_offspring.table(litterID = c("A-001_003", "A-001_002"))
#'
#'
#' #----------------------------------------------------
#' ## Examples for how to use fetch_litter_date.birth()
#' #----------------------------------------------------
#'
#' ## Extract the litterbirth of 2 litters:
#' fetch_litter_date.birth(litterID = c("A-001_002", "A-002_001"))
#'
#'
#' #----------------------------------------------------
#' ## Examples for how to use fetch_litter_composition()
#' #----------------------------------------------------
#'
#' ## Show detail about the offspring number behind a litter as a code:
#' fetch_litter_composition(litterID = "A-001_003")
#'
#' ## Same for all litters in the database:
#' table(fetch_litter_composition(find_pop_litterID()))
#'
#'
#' #-------------------------------------------------------
#' ## Examples for how to use fetch_litter_is.sampled.dna()
#' #-------------------------------------------------------
#'
#' ## Check if a litter has at least one sampled individual in 3 litters:
#' fetch_litter_is.sampled.dna(litterID = c("A-001_003", "A-001_001", "A-001_003"))
#'
#' ## Same for all litters in the database:
#' table(fetch_litter_is.sampled.dna(find_pop_litterID()))
#'
#'
#' #---------------------------------------------
#' ## Examples for how to use fetch_id_litterID()
#' #---------------------------------------------
#'
#' ## Extract the litter ID of 2 individuals using their genetic mother:
#' fetch_id_litterID(ID = c("A-010", "A-049"), filiation = "mother_genetic")
#'
#' ## Extract the litter ID of 2 individuals using their social mother:
#' fetch_id_litterID(ID = c("A-010", "A-049"), filiation = "mother_social")
#'
#'
#' #----------------------------------------------------
#' ## Examples for how to use fetch_id_has.twin.litter()
#' #----------------------------------------------------
#'
#' ## Do these two mothers have produced at least one twin litter?
#' fetch_id_has.twin.litter(ID = c("A-001", "A-007"))
#'
#'
#' #--------------------------------------------------
#' ## Examples for how to use fetch_id_litter.count()
#' #--------------------------------------------------
#'
#' ## Count the number of litters produced by 2 mothers since the first observation:
#' fetch_id_litter.count(ID = c("A-001", "A-002"), first.event = "observation")
#'
#' ## Count the number of litters produced by 2 mothers over their entire life,
#' ## which started before the first observation:
#' fetch_id_litter.count(ID = c("A-001", "A-002"))
#'
#'
#' #------------------------------------------------
#' ## Examples for how to use fetch_id_rank.litter()
#' #------------------------------------------------
#'
#' ## Extract the dominance status of 2 individuals within their litter:
#' fetch_id_rank.litter(ID = c("A-018", "A-046"))
#'
#'
#' #----------------------------------------------
#' ## Examples for how to use find_clan_litterID()
#' #----------------------------------------------
#'
#' ## Find all litters of born in clans A and L since the first observation:
#' find_clan_litterID(clan = c("A", "L"), first.event = "observation")
#'
#' ## Find all litters of born in clans A and L during a particular period:
#' find_clan_litterID(clan = c("A", "L"), from = "1994-01-01", to = "1995-01-01")
#'
#'
#' #---------------------------------------------
#' ## Examples for how to use find_pop_litterID()
#' #---------------------------------------------
#'
#' ## Find all litters existing in the database:
#' find_pop_litterID()
#'
#' ## Find all litters existing in the database between 2 dates:
#' find_pop_litterID(from = "1994-01-01", to = "1995-01-01")
#'
NULL

#' @describeIn litter create a tidy table of offspring (all, i.e. social,
#' genetic, or both) with their litter ID and other characteristics, from their
#' mothers.
#' @export
#'
create_offspring_litter.table <- function(mumID = NULL, debug = FALSE) {
  # do not define a filiation arguments since output must always be complete for litterID to be correct!

  threshold <- 110 ## days limits when considering social cubs as part of the same litter than genetic cubs

  ## If no parent is given, use all females
  if (is.null(mumID)) {
    mumID <- find_pop_id(sex = "female") ## used to include sex NA but this is useless since all individuals known to have reproduced have a sex
  } else {
    mumID <- check_function_arg.ID(mumID, argument.name = "mumID")
  }

  parent <- tibble::tibble(mumID = unique(mumID))

  ## Check the sex of the given ID
  sex <- fetch_id_sex(parent$mumID)
  if (any(!is.na(sex) & sex == "male")) stop("The function works only with mothers (don't use fathers)")

  ## Fetch the birthdate to calculate whether to include social cubs or not in the litter
  create_id_offspring.table(
    ID = parent$mumID,
    filiation = c("mother_genetic", "mother_social", "mother_social_genetic"),
    drop.fromto = TRUE
  ) |>
    dplyr::rename(mumID = "parentID") |>
    dplyr::arrange(.data$mumID, .data$birthdate) -> offspring.with.birthdate

  ## For social cubs we need to retrieve the closest birthdates of the genetic cubs whith whom they share the litter
  offspring.with.birthdate |>
    dplyr::filter(any(.data$filiation == "mother_social"), .by = "mumID") |>
    dplyr::mutate(genetic = .data$filiation %in% c("mother_genetic", "mother_social_genetic")) -> cases.with.social.offspring

  ## Begin handling social cubs
  if (nrow(cases.with.social.offspring) > 0) {
    social.offspring <- tibble::tibble(
      mumID = character(0),
      offspringID = character(0),
      previous_genetic_birthdate = as.Date(character(0))
    )

    for (mumID in unique(cases.with.social.offspring$mumID)) {
      d <- cases.with.social.offspring[cases.with.social.offspring$mumID == mumID, ]
      for (social_offspring in unique(d$offspringID[!d$genetic])) {
        focal_date <- d$birthdate[d$offspringID == social_offspring]
        previous_genetic_birthdate <- d$birthdate[d$birthdate <= focal_date & d$genetic]
        next_genetic_birthdate <- d$birthdate[d$birthdate > focal_date & d$genetic]
        if (length(previous_genetic_birthdate) == 0) {
          previous_genetic_birthdate <- NA
        } else {
          previous_genetic_birthdate <- max(previous_genetic_birthdate)
        }
        if (length(next_genetic_birthdate) == 0) {
          next_genetic_birthdate <- NA
        } else {
          next_genetic_birthdate <- min(next_genetic_birthdate)
        }
        social.offspring <- dplyr::bind_rows(
          social.offspring,
          data.frame(
            mumID = mumID, offspringID = social_offspring,
            previous_genetic_birthdate = previous_genetic_birthdate,
            next_genetic_birthdate = next_genetic_birthdate
          )
        )
      }
    }

    cases.with.social.offspring |>
      dplyr::full_join(social.offspring, by = c("mumID", "offspringID")) |>
      dplyr::mutate(
        diff_prev = .data$birthdate - .data$previous_genetic_birthdate,
        diff_next = .data$next_genetic_birthdate - .data$birthdate
      ) -> cases.with.social.offspring.diff

    ### Safety check 1
    cases.with.social.offspring.diff |>
      dplyr::filter(!.data$genetic & .data$diff_prev <= threshold & .data$diff_next <= threshold & .data$diff_prev != 0 & .data$diff_next != 0) -> test

    if (nrow(test) > 0) {
      warning("`create_offspring_litter.table()` encountered a new situation not yet handled:
                social cubs closely distant to 2 competing genetic litters.")
    }
    rm(test)

    cases.with.social.offspring.diff |>
      dplyr::mutate(litterbirth = dplyr::case_when(.data$genetic ~ .data$birthdate,
        !.data$genetic & .data$diff_prev <= threshold & .data$diff_next <= threshold &
          .data$diff_prev != 0 & .data$diff_next != 0 ~ NA,
        !.data$genetic & .data$diff_next <= threshold ~ .data$next_genetic_birthdate,
        !.data$genetic & .data$diff_prev <= threshold ~ .data$previous_genetic_birthdate,
        .default = .data$birthdate
      )) -> cases.with.social.offspring.dated

    ### Safety check 2
    cases.with.social.offspring.dated |>
      dplyr::filter(!.data$genetic) |>
      dplyr::summarise(
        min_diff = min(.data$litterbirth - dplyr::lag(.data$litterbirth)),
        .by = "mumID"
      ) |>
      dplyr::filter(!is.na(.data$min_diff)) -> test

    if (nrow(test) > 0) {
      warning("`create_offspring_litter.table()` encountered a new situation not yet handled:
                social cubs with close birthdates and no genetic cubs have been assigned to different litters but they should probably be combined.")
    }
    rm(test)

    ### Merging cases with social offspring to other cases
    dplyr::left_join(offspring.with.birthdate,
      cases.with.social.offspring.dated |>
        dplyr::select("mumID", "offspringID", "birthdate", "filiation", "litterbirth"),
      by = c("mumID", "offspringID", "birthdate", "filiation"),
      relationship = "one-to-one"
    ) |>
      dplyr::mutate(litterbirth = dplyr::if_else(is.na(.data$litterbirth),
        .data$birthdate,
        .data$litterbirth
      )) -> offspring_from_females
  } else { ## End handling social cubs / Now dealing with simple case where there are no social cubs
    offspring.with.birthdate |>
      dplyr::mutate(litterbirth = .data$birthdate) -> offspring_from_females
  }

  ## litterID will be "mothercode-00+litterorder", if parent didn't have offspring will be NA:
  offspring_from_females |>
    dplyr::group_by(.data$mumID) |>
    dplyr::mutate(
      litter_order = dplyr::dense_rank(.data$litterbirth),
      litterID = dplyr::if_else(is.na(.data$offspringID) | is.na(.data$litterbirth), NA_character_,
        paste(.data$mumID, formatC(.data$litter_order, width = 3, flag = "0"), sep = "_")
      )
    ) |>
    dplyr::ungroup() |>
    dplyr::select(-"litter_order") -> littersID_females

  check_function_output(
    input.tbl = parent, output.tbl = littersID_females, join.by = "mumID",
    duplicates = "output", debug = debug
  )
}


#' @describeIn litter create a tidy table with the litter ID(s).
#' @export
#'
create_litter_starting.table <- function(mumID = NULL) {
  ## TODO implement selection from sibID and add filters.
  ## Note that filiation would not make sense since the difference between social and genetic
  ##   makes sense at the level of offspring but not so much at the level of litters.

  ## Reading the full table and keeping only one row for each litterID:
  create_offspring_litter.table(mumID = mumID) |>
    dplyr::select("litterID") |>
    dplyr::distinct() |>
    dplyr::filter(!is.na(.data$litterID))
}


#' @describeIn litter create a tidy table with the number of daughters, sons and
#' cubs with unknown sex for the given litter ID(s). The function does produce
#' counts differentiated between genetic and social offspring.
#' @export
#'
create_litter_offspring.count <- function(litterID = NULL) {
  litterID <- check_function_arg.litter.ID(litterID, .fill = TRUE)
  litter.df <- tibble::tibble(litterID = unique(litterID))
  mumID <- substr(litterID, 1, 5)

  create_offspring_litter.table(unique(mumID)) |>
    dplyr::mutate(sex_offspring = ifelse(.data$filiation == "mother_social",
      paste("social", fetch_id_sex(.data$offspringID), sep = "."),
      fetch_id_sex(.data$offspringID)
    )) -> input

  input$sex_offspring[!is.na(input$offspringID) & is.na(input$sex_offspring) &
    (input$filiation == "mother_genetic" | input$filiation == "father" | input$filiation == "mother_social_genetic")] <- "unknown"
  input$sex_offspring[!is.na(input$offspringID) & is.na(input$sex_offspring) & input$filiation == "mother_social"] <- "social.unknown"

  input |>
    dplyr::mutate(sex_offspring = factor(.data$sex_offspring,
      levels = c(
        "female",
        "male",
        "unknown",
        "social.female",
        "social.male",
        "social.unknown"
      )
    )) -> tbl_offspring_litters

  ## Each row becomes a litter:
  tbl_litters_long <- dplyr::count(tbl_offspring_litters, .data$mumID, .data$litterID, .data$sex_offspring, .drop = FALSE)
  tbl_litters_wide <- tidyr::pivot_wider(tbl_litters_long, names_from = "sex_offspring", values_from = "n", values_fill = list(n = 0))

  check_function_output(
    input.tbl = litter.df,
    output.tbl = dplyr::select(tbl_litters_wide, -"mumID"), join.by = "litterID",
    duplicates = "output", debug = FALSE
  )
}

#' @describeIn litter create a tidy table with all information about the
#' offspring given their litter ID(s).
#' @export

create_litter_offspring.table <- function(litterID = NULL) {
  litterID <- check_function_arg.litter.ID(litterID, .fill = TRUE)
  litter.table <- tibble::tibble(litterID = litterID)

  offspring.litter.table <- create_offspring_litter.table(mumID = unique(substring(litterID, first = 1, last = 5)))

  litter.table |>
    dplyr::left_join(relationship = "many-to-many", offspring.litter.table, by = "litterID")
}


#' @describeIn litter fetch the "birthdate" of a given litter (i.e.
#' litterbirth).
#' @export
#'
fetch_litter_date.birth <- function(litterID, debug = FALSE) {
  litterID <- check_function_arg.litter.ID(litterID)
  input <- tibble::tibble(litterID = litterID)

  mumID <- unique(substr(litterID, 1, 5))
  create_offspring_litter.table(mumID = unique(mumID)) |>
    dplyr::filter(.data$litterID %in% !!litterID) |>
    dplyr::summarise(litterbirth = unique(.data$litterbirth), .by = "litterID") -> output

  check_function_output(input, output,
    join.by = "litterID",
    debug = debug, duplicates = "input", output.IDcolumn = "litterbirth"
  )
}


#' @describeIn litter fetch a code describing the composition of each given
#' litter. Each litter is defined by a combination of letter, (f = female, m =
#' male, u = cub with unknown sex, prefixed with 's' if the cub is social, or
#' not prefixed otherwise).
#' @export
#'
fetch_litter_composition <- function(litterID, debug = FALSE) {
  litterID <- check_function_arg.litter.ID(litterID, .fill = FALSE)

  create_litter_offspring.count(litterID) |>
    dplyr::mutate(type = recode_offspring.sex_litter.type(
      .data$female,
      .data$male,
      .data$unknown,
      .data$social.female,
      .data$social.male,
      .data$social.unknown
    )) -> output

  if (debug) {
    return(output)
  }

  output$type
}


#' @describeIn litter fetch if at least one member of the litter has been
#' genetically typed.
#' @export
#'
fetch_litter_is.sampled.dna <- function(litterID, debug = FALSE) {
  litterID <- check_function_arg.litter.ID(litterID, .fill = FALSE)

  mumID <- unique(substr(litterID, 1, 5))
  litter <- tibble::tibble(litterID = litterID)
  all.litters <- create_offspring_litter.table(mumID = unique(mumID))
  litter |>
    dplyr::left_join(relationship = "many-to-many", all.litters, by = "litterID") |>
    dplyr::select("offspringID", "litterID", "filiation") |>
    dplyr::mutate(dna = fetch_id_is.sampled.dna(.data$offspringID)) |>
    dplyr::mutate(litter_dna = any(.data$dna), .by = "litterID") |>
    dplyr::select("litterID", "litter_dna") |>
    dplyr::distinct() -> output_distinct

  check_function_output(
    input.tbl = litter, output.tbl = output_distinct, join.by = "litterID",
    duplicates = "input", output.IDcolumn = "litter_dna", debug = debug
  )
}


#' @describeIn litter fetch the litter ID in which the given ID(s) are "born"
#' according to filiation argument. If filiation is 'mother_genetic' the
#' function retrieves the genetic litter. If filiation is 'mother_social' the
#' function retrieves the social litters where cubs have been adopted. If the
#' cub has never been adopted and filiation is 'mother_social' the function
#' returns NA. For this function, the filiation 'mother_social_genetic' does not
#' make sense and cannot thus be used, use 'mother_genetic' to obtain the litter
#' ID via the genetic mother.
#' @export
#'
fetch_id_litterID <- function(ID, filiation, debug = FALSE) {
  ID <- check_function_arg.ID(ID)
  filiation <- check_function_arg.filiation(filiation, .fill = FALSE)
  ## The function accepts only 'mother_genetic' and 'mother_social'
  if (!(filiation %in% c("mother_genetic", "mother_social"))) {
    stop("The function works only with 'mother_genetic' or 'mother_social'. 'mother_social_genetic' in this case is included in 'mother_genetic")
  }
  offspring <- tibble::tibble(offspringID = ID)

  if (filiation == "mother_genetic") {
    ## We keep only the genetic mothers to retrieve the genetic litters.
    offspring |>
      dplyr::mutate(mumID = fetch_id_id.mother.genetic(.data$offspringID)) -> mother.offspring
    ## create_offspring_litter.table is based on create_id_offspring.table that returns all
    ## offspring, both genetic and social. A cub could then a duplicate in the output.tbl, because genetic
    ## offspring of a female in 'mother' column but also social offspring of another female in 'mother' column.
    ## To avoid this we filter the correct filiation.
    create_offspring_litter.table(mumID = unique(mother.offspring$mumID)) |>
      dplyr::filter(.data$filiation %in% c("mother_genetic", "mother_social_genetic")) -> litters.mother
  } else if (filiation == "mother_social") {
    offspring |>
      ## We keep only the social mothers who adopted for real the offspring to retrieve the social litters.
      dplyr::mutate(
        mumID = fetch_id_id.mother.social(.data$offspringID),
        gen.mumID = fetch_id_id.mother.genetic(.data$offspringID)
      ) |>
      dplyr::filter(.data$gen.mumID != .data$mumID) |>
      dplyr::select("offspringID", "mumID") -> mother.offspring
    create_offspring_litter.table(mumID = unique(mother.offspring$mumID)) |>
      dplyr::filter(.data$filiation == "mother_social") -> litters.mother
  }

  check_function_output(
    input.tbl = offspring, output.tbl = litters.mother, join.by = "offspringID",
    duplicates = "input", output.IDcolumn = "litterID", debug = debug
  )
}


#' @describeIn litter fetch whether individuals have produced any twin litter.
#' @export
#'
fetch_id_has.twin.litter <- function(ID, from = NULL, to = NULL, at = NULL,
                                     na.as.FALSE = TRUE,
                                     .fill = TRUE, first.event = "birthdate", debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  na.as.FALSE <- check_function_arg.logical(na.as.FALSE)
  ID <- check_function_arg.ID(ID)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to

  input <- dplyr::tibble(
    mumID = ID,
    from = from, to = to
  )

  unique_input <- input |>
    dplyr::distinct()

  create_offspring_litter.table(mumID = unique(ID)) |>
    dplyr::left_join(unique_input, by = "mumID", relationship = "many-to-many") |> # Join in from/to to allow for a vector of different from/to dates
    dplyr::filter(.data$birthdate >= .data$from & .data$birthdate <= .data$to) |>
    dplyr::group_by(.data$mumID, .data$from, .data$to, .data$litterID) |>
    dplyr::summarise(litter_size = dplyr::n(), .groups = "drop_last") |> # Find litter size for each litter
    dplyr::summarise(twin = any(!is.na(.data$litterID) & .data$litter_size > 1)) -> output_raw

  check_function_output(input, output_raw,
    join.by = c("mumID", "from", "to"),
    debug = debug, duplicates = "input", output.IDcolumn = "twin"
  ) -> output

  if (na.as.FALSE) {
    output <- ifelse(is.na(output), FALSE, output)
  }

  output
}


#' @describeIn litter fetch the total number of litters produced by given
#' mother(s) during a given period of time.
#' @export
#'
fetch_id_litter.count <- function(ID, from = NULL, to = NULL, at = NULL,
                                  .fill = TRUE, first.event = "birthdate", debug = FALSE) {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  ID <- check_function_arg.ID(ID)
  date_range <- check_function_arg.date.fromtoat(from, to, at,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to
  input <- tibble::tibble(mumID = ID)

  create_offspring_litter.table(mumID = unique(ID)) |>
    dplyr::mutate(
      include = .data$litterbirth >= from & .data$litterbirth <= to,
      include = ifelse(is.na(.data$include), 0, .data$include)
    ) |>
    dplyr::select("mumID", "litterbirth", "litterID", "include") |>
    dplyr::slice(1L, .by = "litterID") |>
    dplyr::summarise(litters.count = sum(.data$include), .by = "mumID") -> litters.tbl

  check_function_output(
    input.tbl = input, output.tbl = litters.tbl,
    join.by = "mumID", duplicates = "input", output.IDcolumn = "litters.count", debug = debug
  )
}

#' @describeIn litter fetch the dominance status of given hyena(s) within their
#' litter. If the litter is composed of only one individual, the function
#' returns NA.
#' @export
#'
fetch_id_rank.litter <- function(ID) {
  ID <- check_function_arg.ID(ID)
  fetch_database_column(column = "litterdominance", tbl.name = "hyenas", ID = ID)
}


#' @describeIn litter find litters born in the given clan(s) at a given time.
#' @export
#'
find_clan_litterID <- function(clan,
                               from = NULL, to = NULL, at = NULL,
                               .fill = TRUE, first.event = "birthdate") {
  min.date <- switch(first.event,
    birthdate = find_pop_date.birth.first(),
    observation = find_pop_date.observation.first(),
    conception = find_pop_date.conception.first()
  )
  max.date <- find_pop_date.observation.last()

  date_range <- check_function_arg.date.fromtoat(from, to, at,
    .fill = .fill,
    min.date = min.date,
    max.date = max.date
  )
  from <- date_range$from
  to <- date_range$to
  clan <- check_function_arg.clan(clan)

  create_id_offspring.table(ID = find_pop_id(), from = from, to = to) |>
    dplyr::mutate(birth.clan = fetch_id_clan.birth(.data$offspringID)) |>
    dplyr::filter(!is.na(.data$offspringID) & .data$birth.clan %in% clan) -> offspring.table

  offspring.table |>
    dplyr::mutate(litterID = fetch_id_litterID(.data$offspringID, filiation = "mother_genetic")) -> litter.genetic

  offspring.table |>
    dplyr::mutate(litterID = fetch_id_litterID(.data$offspringID, filiation = "mother_social")) -> litter.social

  rbind(litter.genetic, litter.social) |>
    dplyr::filter(!is.na(.data$litterID)) |>
    dplyr::distinct(.data$litterID) -> litters

  sort(litters$litterID)
}


#' @describeIn litter find litters born in the population at a given time.
#' @export
#'
find_pop_litterID <- function(from = NULL, to = NULL, at = NULL,
                              .fill = TRUE, main.clans = TRUE, first.event = "birthdate") {
  clan <- find_clan_name.all(main.clans = main.clans)

  find_clan_litterID(
    clan = clan,
    from = from, to = to, at = at,
    .fill = .fill, first.event = first.event
  )
}
