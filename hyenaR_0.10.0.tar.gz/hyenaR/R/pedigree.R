#' Create and use genetic pedigrees
#'
#' The following functions help build a genetic pedigree and extract information
#' for it. This is particularly useful for exploring family relationship,
#' studying inbreeding and performing quantitative genetics analyses. Just as a
#' reminder and the word *sire* refer to the father, the word *dam* refers to
#' the genetic mother. The functions dealing with pedigrees are the following:
#' - `create_pop_pedigree()`: this is the function to use to create a pedigree.
#' It takes an argument 'at' since the pedigree must be computed at a given
#' date. All individuals present in the data that were born until this date are
#' considered. If 'at' is not provided, the default behavior of the function is
#' to return a complete pedigree for the whole population. In this function, you
#' must decide if you want the pedigree with IDs represented as usual (the
#' default), or if you want that IDs are turned into numbers (useful for some
#' functions in other packages), or if you want a table with both types of IDs
#' labeling. This is handled by the argument 'pedigree.format'. Note that for a
#' smoother interaction with other packages, a pedigree produced with
#' "pedigree.format = 'numeric'" returns missing IDs labeled as 0s rather than
#' NAs, and is of format data.frame rather than tibble.
#' - `find_id_id.descendant()`: this function creates a vector with the genetic
#' descendants of *one* individual. It does understand the 'from/to/at' arguments,
#' which it applies to the birth date at which the descendants are born.
#' - `fetch_id_id.descendant()`: this is the fetch counterpart of the previous function.
#' So compared to `find_id_id.descendant()` it can be used to get the
#' descendants of many individuals simultaneously. It returns a list column
#' where each element contains all the descendants of a given ID. The function
#' takes the same arguments as `find_id_id.descendant()`, as well as 'CPUcores'
#' which allows for you to use several core CPUs to speed up the computation if
#' your computer allows it. By default, 'CPUcores' will use the number stored
#' in hyenaR options, which is given by `getOption("hyenaR_CPUcores")` and can
#' be manually defined for all the functions in hyenaR with
#' `options(hyenaR_CPUcores = xx)`, replacing 'xx' by a number of cores CPUs to
#' be used. Using the argument 'CPUcores' in `fetch_id_id.descendant()` instead
#' of changing the hyenaR options only influences the setting for the particular
#' call to this function.
#'
#' @name pedigree
#' @inheritParams arguments
#'
#' @examples
#' ## loading dummy data for examples
#' load_package_database.dummy()
#'
NULL


#' @describeIn pedigree Create the (genetic) pedigree of the population.
#'
#' @export
#' @examples
#' ## compute full pedigree
#' create_pop_pedigree()
#'
#' ## compute pedigree until a given date
#' create_pop_pedigree(at = "1997/01/01")
#'
#' ## use a pedigree with IDs labelled as numbers
#' ## (ggroups::pedcheck() provides information about potential errors in the pedigree)
#'
#' if (require("ggroups")) { ## you need to have installed {ggroups}
#'   ped <- create_pop_pedigree(pedigree.format = "numeric")
#'   pedcheck(ped = ped)
#' }
#'
create_pop_pedigree <- function(at = NULL, pedigree.format = c("character", "numeric", "both")) {
  at <- check_function_arg.date(at, argument.name = "at", arg.max.length = 1, .fill = TRUE, fill.value = find_pop_date.observation.last())

  pedigree.format <- pedigree.format[1] ## no check here since the argument is only used here and it is tested while returning the output (see below)

  create_id_starting.table(verbose = FALSE) |>
    dplyr::mutate(
      sire = fetch_id_id.father(.data$ID),
      dam = fetch_id_id.mother.genetic(.data$ID),
      birthdate = fetch_id_date.birth(.data$ID)
    ) |>
    dplyr::filter(.data$birthdate <= at) |>
    dplyr::arrange(.data$birthdate) |>
    dplyr::select(-"birthdate") -> pedigree

  ## Don't continue in simplest case
  if (pedigree.format == "character") {
    return(pedigree)
  }

  ## Add numbers corresponding to labels (for use in e.g. {ggroups})
  pedigree |>
    dplyr::mutate(
      ID_num = match(.data$ID, pedigree$ID),
      sire_num = match(.data$sire, pedigree$ID),
      dam_num = match(.data$dam, pedigree$ID)
    ) -> pedigree_both

  ## NA must be "0" for use in {ggroups}
  pedigree_both$ID_num[is.na(pedigree_both$ID_num)] <- 0
  pedigree_both$sire_num[is.na(pedigree_both$sire_num)] <- 0
  pedigree_both$dam_num[is.na(pedigree_both$dam_num)] <- 0

  pedigree_both |>
    dplyr::select(
      ID = "ID_num",
      sire = "sire_num",
      dam = "dam_num"
    ) -> pedigree_num

  ## Return outputs
  if (pedigree.format == "character") {
    return(pedigree)
  } else if (pedigree.format == "numeric") {
    return(as.data.frame(pedigree_num)) ## data.frame for use in other pkgs (e.g. ggroups which test the class and does not recognise tibbles)
  } else if (pedigree.format == "both") {
    return(pedigree_both)
  }
  stop("value of argument 'pedigree.format' unknown, please check ?pedigree")
}


#' @describeIn pedigree Find the (genetic) descendants of one individual.
#'
#' @export
#' @examples
#' ## return all genetic descendants of an individual
#' find_id_id.descendant(ID = "A-013")
#'
#' ## return all genetic descendants of an individual, with descendants born between 2 dates
#' find_id_id.descendant(ID = "A-013", from = "1994-01-01", to = "1995-01-01")
#'
find_id_id.descendant <- function(ID, from = NULL, to = NULL, at = NULL) {
  ID <- check_function_arg.ID(ID = ID, .fill = FALSE, arg.max.length = 1L)
  ## Don't test from / to / at since those will be tested within find_id_id.offspring()

  create_id_descendant.table.internal <- function(ID, .generation = 1L) {
    descendants <- tibble::tibble(
      parent = ID, ## note: using data frame instead does not save time
      offspring = find_id_id.offspring(
        ID = ID, from = from, to = to, at = at,
        filiation = c("mother_genetic", "mother_social_genetic", "father"),
        .fill = TRUE, ## filling from, to, at if not provided
        first.event = "birthdate"
      ), ## first.event should not have any effect here
      generation = .generation
    )

    descendants <- descendants[!is.na(descendants$offspring), ]

    if (nrow(descendants) > 0L) {
      result <- purrr::map2(
        .x = descendants$offspring,
        .y = descendants$generation,
        \(.x, .y) create_id_descendant.table.internal(ID = .x, .generation = .y + 1L)
      ) ## recursive call
      result <- do.call("rbind", result)
      descendants <- rbind(descendants, result)
    }
    descendants
  }

  create_id_descendant.table.internal(ID = ID) |>
    dplyr::arrange(.data$generation) -> table_descendants

  table_descendants$offspring
}


#' @describeIn pedigree Fetch the (genetic) descendants of individual(s).
#'
#' @export
#' @examples
#' ## fetch all genetic descendants of 4 individuals in clan A
#' if (require("dplyr")) {
#'   create_id_starting.table(clan = "A") |>
#'     slice(1:4) |>
#'     mutate(descendants = fetch_id_id.descendant(ID = ID))
#' }
#'
#' ## same using parallel processing (here with 4 CPU cores)
#' if (require("dplyr") && parallel::detectCores() >= 4) {
#'   create_id_starting.table(clan = "A") |>
#'     slice(1:4) |>
#'     mutate(descendants = fetch_id_id.descendant(ID = ID, CPUcores = 4))
#' }
#'
#' ## same with the unnesting of the list column
#' if (require("dplyr") && require("tidyr")) {
#'   create_id_starting.table(clan = "A") |>
#'     slice(1:4) |>
#'     mutate(descendants = fetch_id_id.descendant(ID = ID)) |>
#'     unnest(descendants)
#' }
#'
#' ## fetch all genetic descendants of 4 individuals, with descendants born between 2 dates
#' if (require("dplyr")) {
#'   create_id_starting.table(clan = "A") |>
#'     slice(1:4) |>
#'     mutate(descendants = fetch_id_id.descendant(ID = ID, from = "1994-01-01", to = "1995-01-01"))
#' }
#'
fetch_id_id.descendant <- function(ID, from = NULL, to = NULL, at = NULL, CPUcores = NULL, .parallel.min = 1) {
  input <- tibble::tibble(ID = !!ID, from = !!from, to = !!to, at = !!at) ## Checked internally, so no need to do it here

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(input) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if (is.null(CPUcores)) {
    CPUcores <- 1
  }

  ## We loop ## TODO: we should loop only on unique combination, but we need a general wrapper for that...
  if (CPUcores > 1 && nrow(input) >= .parallel.min) {
    output <- furrr::future_pmap(input, ~ do.call("find_id_id.descendant", list(...)),
      .progress = TRUE,
      .options = furrr::furrr_options(globals = ".database")
    )
    future::plan("sequential") ## close connections (see https://cran.r-project.org/web/packages/future/vignettes/future-7-for-package-developers.html)
  } else {
    if (CPUcores > 1 && (nrow(input) < .parallel.min)) message(paste("Argument CPUcores ignored as less than", .parallel.min, "case(s) to compute."))
    output <- purrr::pmap(input, ~ unique(do.call("find_id_id.descendant", list(...))))
  }

  names(output) <- ID

  output
}
