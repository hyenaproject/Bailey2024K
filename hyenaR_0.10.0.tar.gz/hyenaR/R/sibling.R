#' Extract or compute information about siblings
#'
#' These functions extract and compute information about the siblings of
#' individuals. The main function `create_id_sibling.table()` is strongly based
#' on [`create_id_offspring.table()`]. It therefore inherits from all the
#' filtering possibilities offered by the latter function (see section
#' **Filtering by age** and **Filtering by filiation** below). Another useful
#' function is `fetch_dyad_is.sibling()` which can be used to test if two
#' individuals are siblings (given a specified filiation).
#'
#' @inheritSection offspring Filtering by age
#'
#' @section Filtering by filiation:
#'
#' There is a crucial difference between `create_id_sibling.table()` and
#' [`create_id_offspring.table()`] in how the filtering by filiation behaves. In
#' `create_id_sibling.table()`, the `filiation` argument can only take a single
#' input value. This is because the siblings are extracted based on a single
#' parent of the single individual. Also, in contrast to
#' [`create_id_offspring.table()`] which strictly follows the definition of the
#' `filiation` argument, here, both `filiation = "mother_genetic"` and
#' `filiation = "mother_social"` return both social and genetic siblings. For
#' `create_id_sibling.table()`, the default for the filiation is
#' `"mother_social"`.
#'
#' @name sibling
#' @aliases sibling siblings
#' @inheritParams arguments
#' @seealso [offspring]
#'
#' @examples
#'
#' ## loading dummy data for examples
#'
#' load_package_database.dummy()
#'
#' #----------------------------------------------------------------------------
#' ## Examples for how to use create_id_sibling.table()
#' #----------------------------------------------------------------------------
#'
#' # Note: other functions show here are heavily dependent on this function
#' # so it is best to first well understand this function.
#' # Also, this function itself depends on create_id_offspring.table(),
#' # and the help of the latter function illustrates many more filtering
#' # possibilities that also apply to create_id_sibling.table().
#'
#' ### Retrieve siblings of "A-084"
#' create_id_sibling.table(ID = "A-084")
#'
#' ### Retrieve siblings of "A-084" born after 1995-01-01
#' create_id_sibling.table(ID = "A-084", from = "1995-01-01")
#'
#'
#' #----------------------------------------------------------------------------
#' ## Examples for how to use fetch_dyad_is.sibling()
#' #----------------------------------------------------------------------------
#'
#' fetch_dyad_is.sibling(
#'   ID.1 = "A-084", ID.2 = c("A-088", "A-089", "A-090"),
#'   filiation = "mother_genetic"
#' )
#' fetch_dyad_is.sibling(
#'   ID.1 = "A-084", ID.2 = c("A-088", "A-089", "A-090"),
#'   filiation = "father"
#' )
#'
#'
#' #----------------------------------------------------------------------------
#' ## Examples for how to use find_id_id.sibling()
#' #----------------------------------------------------------------------------
#'
#' find_id_id.sibling(ID = "A-084", filiation = "mother_genetic")
#'
#'
#' #----------------------------------------------------------------------------
#' ## Examples for how to use find_id_id.sibling.older()
#' #----------------------------------------------------------------------------
#'
#' find_id_id.sibling.older(ID = "A-084", filiation = "mother_genetic")
#'
#'
#' #----------------------------------------------------------------------------
#' ## Examples for how to use find_id_id.sibling.younger()
#' #----------------------------------------------------------------------------
#'
#' find_id_id.sibling.younger(ID = "A-084", filiation = "mother_genetic")
#'
NULL


#' @describeIn sibling create a tidy table with siblings retained after
#'   applying selection criteria (see section **Selection criteria**). The table
#'   also contains the `from` and `to` interval scanned to detect them, the
#'   birthdates of the siblings, and the offspring-parent relationship
#'   (mother_genetic, mother_social, mother_social_genetic, father) which is
#'   called 'filiation'. Note that by default the functions returns at least one
#'   row per parent, so even if no offspring exists a row will be present. You
#'   can override this default by setting `drop.na.offspring = TRUE`.
#' @export
#'
#'
create_id_sibling.table <- function(ID, filiation = "mother_social", include.focal = FALSE,
                                    from = NULL, to = NULL, at = NULL,
                                    age.min = 0, age.max = Inf, age.overlap = "start", unit = "year",
                                    drop.fromto = FALSE,
                                    first.event = "birthdate",
                                    .fill = TRUE,
                                    debug = FALSE) {
  ID <- check_function_arg.ID(ID, .fill = FALSE)

  filiation <- check_function_arg.filiation(filiation, arg.max.length = 1, mother.social.genetic.distinguised = FALSE)

  if (filiation == "mother_social") {
    fun <- fetch_id_id.mother.social
    filiation <- c("mother_social", "mother_social_genetic") ## for filtering below
  } else if (filiation == "mother_genetic") {
    fun <- fetch_id_id.mother.genetic
    filiation <- c("mother_genetic", "mother_social_genetic") ## for filtering below
  } else if (filiation == "father") {
    fun <- fetch_id_id.father
  } else {
    stop("create_id_sibling.table only works with filiation defined either as mother_social, mother_genetic, or father")
  }

  table1 <- tibble::tibble(focalID = ID, parentID = fun(ID))

  table2 <- create_id_offspring.table(
    ID = fun(ID), from = from, to = to, at = at,
    age.min = age.min, age.max = age.max, age.overlap = age.overlap, unit = unit,
    filiation = c("mother_genetic", "mother_social", "mother_social_genetic", "father"),
    drop.na.offspring = TRUE, drop.fromto = drop.fromto,
    first.event = first.event,
    .fill = .fill
  ) |>
    dplyr::rename(siblingID = "offspringID")

  dplyr::right_join(table1, table2, by = c("parentID")) |>
    dplyr::filter(.data$filiation %in% !!filiation) -> output

  if (!include.focal) {
    output |>
      dplyr::filter(.data$siblingID != .data$focalID) -> output
  }

  output
}


#################################################################################

#' find_id_id.sibling
#' @describeIn sibling find all the siblings to an ID given the specific filiation
#' @export
#'
find_id_id.sibling <- function(ID, filiation = "mother_social", include.focal = FALSE,
                               from = NULL, to = NULL, at = NULL,
                               age.min = 0, age.max = Inf, age.overlap = "start", unit = "year",
                               drop.fromto = FALSE,
                               first.event = "birthdate",
                               .fill = TRUE,
                               debug = FALSE) {
  create_id_sibling.table(
    ID = ID, filiation = filiation, include.focal = FALSE,
    from = from, to = to, at = at,
    age.min = age.min, age.max = age.max, age.overlap = age.overlap, unit = unit,
    drop.fromto = drop.fromto,
    first.event = first.event,
    .fill = .fill
  ) |>
    dplyr::pull(.data$siblingID)
}


#################################################################################

#' find_id_id.sibling.older
#' @describeIn sibling find all the younger siblings to an ID given the specific filiation
#' @export
#'
find_id_id.sibling.older <- function(ID, filiation = "mother_social", include.focal = FALSE,
                                     from = NULL, to = NULL, at = NULL,
                                     age.min = 0, age.max = Inf, age.overlap = "start", unit = "year",
                                     drop.fromto = FALSE,
                                     first.event = "birthdate",
                                     .fill = TRUE,
                                     debug = FALSE) {
  create_id_sibling.table(
    ID = ID, filiation = filiation, include.focal = TRUE,
    from = from, to = to, at = at,
    age.min = age.min, age.max = age.max, age.overlap = age.overlap, unit = unit,
    drop.fromto = drop.fromto,
    first.event = first.event,
    .fill = .fill
  ) |>
    dplyr::mutate(birthdate_focal = .data$birthdate[.data$focalID == .data$siblingID], .by = "focalID") |>
    dplyr::filter(.data$birthdate < .data$birthdate_focal) |> ## FIXME: shall we include the sibling with same birthdate?
    dplyr::pull(.data$siblingID)
}


#################################################################################

#' find_id_id.sibling.younger
#' @describeIn sibling find all the older siblings to an ID given the specific filiation
#' @export
#'
find_id_id.sibling.younger <- function(ID, filiation = "mother_social", include.focal = FALSE,
                                       from = NULL, to = NULL, at = NULL,
                                       age.min = 0, age.max = Inf, age.overlap = "start", unit = "year",
                                       drop.fromto = FALSE,
                                       first.event = "birthdate",
                                       .fill = TRUE,
                                       debug = FALSE) {
  create_id_sibling.table(
    ID = ID, filiation = filiation, include.focal = TRUE,
    from = from, to = to, at = at,
    age.min = age.min, age.max = age.max, age.overlap = age.overlap, unit = unit,
    drop.fromto = drop.fromto,
    first.event = first.event,
    .fill = .fill
  ) |>
    dplyr::mutate(birthdate_focal = .data$birthdate[.data$focalID == .data$siblingID], .by = "focalID") |>
    dplyr::filter(.data$birthdate > .data$birthdate_focal) |> ## FIXME: shall we include the sibling with same birthdate?
    dplyr::pull(.data$siblingID)
}

#################################################################################

#' fetch_dyad_is.sibling
#' @describeIn sibling determine if pairs of individuals are siblings or not given the specific filiation
#' @export
fetch_dyad_is.sibling <- function(ID.1, ID.2, filiation, CPUcores = NULL, .parallel.min = 1000) {
  filiation <- check_function_arg.filiation(filiation, arg.max.length = 1, mother.social.genetic.distinguised = FALSE)

  ## non-vectorised fn dealing with a single pair of potential siblings
  create_dyad_is.sibling_1pair <- function(ID.1, ID.2, filiation) {
    ## test if parents unknown
    parents_unknown <- switch(filiation,
      mother_social = is.na(fetch_id_id.mother.social(ID.1)) || is.na(fetch_id_id.mother.social(ID.2)),
      mother_genetic = is.na(fetch_id_id.mother.genetic(ID.1)) || is.na(fetch_id_id.mother.genetic(ID.2)),
      father = is.na(fetch_id_id.father(ID.1)) || is.na(fetch_id_id.father(ID.2))
    )

    if (parents_unknown) {
      return(data.frame(ID.1 = ID.1, ID.2 = ID.2, filiation = filiation, siblings = NA))
    }

    ## in case parents are known, find siblings
    ID1_siblings <- find_id_id.sibling(ID = ID.1, filiation = filiation)
    ID2_siblings <- find_id_id.sibling(ID = ID.2, filiation = filiation)

    ## are focal among siblings
    include_sibling <- any(ID.2 %in% ID1_siblings) || any(ID.1 %in% ID2_siblings)

    data.frame(ID.1 = ID.1, ID.2 = ID.2, filiation = filiation, siblings = include_sibling)
  }

  ## preparing data for repeated use of the function just defined
  input_all <- tibble::tibble(ID.1 = !!ID.1, ID.2 = !!ID.2, filiation = !!filiation) ## ID checked internally, so no need to do it here
  input <- unique(input_all)

  ## Only trigger parallel if necessary to avoid overhead for small job
  if (nrow(input) >= .parallel.min) {
    CPUcores <- load_parallel_processing(CPUcores = CPUcores)
  } else if (is.null(CPUcores)) {
    CPUcores <- 1
  }

  ## We loop
  if (CPUcores > 1 && nrow(input) >= .parallel.min) {
    output <- furrr::future_pmap_dfr(input, ~ do.call("create_dyad_is.sibling_1pair", list(...)),
      .progress = TRUE,
      .options = furrr::furrr_options(globals = ".database")
    )
    future::plan("sequential") ## close connections (see https://cran.r-project.org/web/packages/future/vignettes/future-7-for-package-developers.html)
  } else {
    if (CPUcores > 1 && (nrow(input) < .parallel.min)) message(paste("Argument CPUcores ignored as less than", .parallel.min, "case(s) to compute."))
    output <- purrr::pmap_dfr(input, ~ do.call("create_dyad_is.sibling_1pair", list(...)))
  }

  ## We reduplicate the output
  check_function_output(
    input.tbl = input_all,
    output.tbl = output,
    join.by = c("ID.1", "ID.2", "filiation"),
    duplicates = "input",
    output.IDcolumn = "siblings",
    debug = FALSE
  )
}
