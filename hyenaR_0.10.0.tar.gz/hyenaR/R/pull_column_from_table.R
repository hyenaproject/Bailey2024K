#' Extract a column in a table.
#'
#' This function is used internally to pull columns from a table without dropping NAs.
#' It should not be directly used by the user.
#'
#' @inheritParams arguments
#'
#' @return a vector.
#' @export
#' @examples
#'
#' ######## Load the dummy dataset:
#' load_package_database.dummy()
#'
#' ######## pull sex from hyenas table for 2 individuals:
#' fetch_database_column(column = "sex", tbl.name = "hyenas", ID = c("A-001", "L-002", NA))
#'
#' ######## pull sex from hyenas table for all individuals:
#' fetch_database_column(column = "sex", tbl.name = "hyenas")
#'
fetch_database_column <- function(column, tbl.name, ID = NULL) {
  column <- check_function_arg.column(column = column, tbl.name = tbl.name)
  tbl <- extract_database_table(tbl.names = tbl.name)
  if (length(tbl$ID) > length(unique(tbl$ID))) {
    warning("fetch_database_column only retrieves the first occurence when ID are repeated in the table")
  }
  if (is.null(ID)) {
    return(tbl[, column, drop = TRUE])
  }
  tbl[match(ID, tbl$ID), column, drop = TRUE]
}
