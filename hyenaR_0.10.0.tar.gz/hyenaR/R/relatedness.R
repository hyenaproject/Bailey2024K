#' Compute the genetic relatedness between pairs of hyenas
#'
#' These functions compute the relatedness between pairs of hyenas. The
#' relatedness is computed as twice the kinship coefficient. Technically, if
#' individual $J$ is ancestral to individuals $j$ and $j′$, the relatedness is
#' thus here computed as \eqn{r = 2\times\sum(0.5)^n\times(1 + F_J)}{r =
#' 2sum(0.5)^n(1 + FJ)}, where FJ is the pedigree inbreeding coefficient of J
#' and the sum is over all ancestors J and all paths joining j to j′ through J.
#' With the current implementation based on [kinship2::kinship()], missing
#' parents and founders are all assumed unrelated to all individuals (including
#' to each others) but themselves. As a consequence, if different offspring of
#' the same litter don't have a known father, it is assumed that it is _not_ the
#' same unknown male that is the father of them all, but as many males as they
#' are offspring. Also, since inbreeding is accounted for, siblings with same
#' parents can have relatedness greater that the expectation of 0.5 (and the
#' same applies for any other comparisons, including for comparisons of
#' individuals with themselves).
#'
#' @name relatedness
#'
#' @examples
#'
#' ## loading dummy data for examples
#'
#' load_package_database.dummy()
#'
#' if (require("kinship2")) {
#'   ## simple usage not involving data frames
#'
#'   fetch_dyad_relatedness(ID.1 = "L-008", ID.2 = "L-009")
#'
#'
#'   ## comparing pairs of individuals with dplyr
#'
#'   data.frame(ID.1 = c("L-008", "L-009"), ID.2 = c("L-002", "L-004")) %>%
#'     dplyr::mutate(rel = fetch_dyad_relatedness(ID.1 = ID.1, ID.2 = ID.2))
#'
#'   ## comparing one individual to many with dplyr
#'
#'   data.frame(
#'     ID.1 = "L-008",
#'     ID.2 = c("A-049", "L-001", "L-002", "L-003", "L-004", "L-005")
#'   ) |>
#'     dplyr::mutate(rel = fetch_dyad_relatedness(ID.1 = ID.1, ID.2 = ID.2))
#'
#'
#'   ## computing relatedness matrix for the whole population
#'
#'   A <- create_pop_relatedness.matrix()
#'   A["L-002", "L-008"] # check one cell in that matrix
#' }
#'
NULL

#' @describeIn relatedness Compute the matrix of relatedness between all hyenas in the population.
#'
#' @export

create_pop_relatedness.matrix <- function() {
  if (!requireNamespace("kinship2", quietly = TRUE)) {
    stop("You must installed the R package kinship2 to use this function")
  }

  ## prepare pedigree info (with no test for accuracy)
  create_id_starting.table(verbose = FALSE) |>
    dplyr::mutate(
      father = fetch_id_id.father(ID = .data$ID),
      mother = fetch_id_id.mother.genetic(ID = .data$ID),
      sex = fetch_id_sex(ID = .data$ID),
      sex = dplyr::case_when(
        .data$sex == "male" ~ 1,
        .data$sex == "female" ~ 2
      )
    ) -> ped_info

  ## compute kinship matrix
  K <- kinship2::kinship(
    id = ped_info$ID, dadid = ped_info$father, momid = ped_info$mother,
    sex = ped_info$sex, chrtype = "autosome"
  )
  K * 2
}


#' @describeIn relatedness Fetch the relatedness between pairs of hyenas.
#'
#' In this function, ID.1 and ID.2 can contain one or several IDs.
#'
#' @inheritParams arguments
#' @export

fetch_dyad_relatedness <- function(ID.1, ID.2) {
  if (!requireNamespace("kinship2", quietly = TRUE)) {
    stop("You must installed the R package kinship2 to use this function")
  }

  ## check inputs
  ID.1 <- check_function_arg.ID(ID = ID.1, strict = TRUE, .fill = FALSE)
  ID.2 <- check_function_arg.ID(ID = ID.2, strict = TRUE, .fill = FALSE)

  ## compute relatedness matrix
  A <- create_pop_relatedness.matrix()

  ## select pairs
  d <- data.frame(ID.1 = ID.1, ID.2 = ID.2)

  ## extract relatedness for relevant pairs
  A[as.matrix(d)]
}
