#include <Rcpp.h>
using namespace Rcpp;

//' Compute mean genetic relatedness
//'
//' calculate the mean genetic relatedness in the population, return a vector with coefficients of average similarity per loci in the population,
//' used to calculate genetic relatedness between individuals relatively to a "base population" (which is in our case the present population)
//' calculated using the frequency of one allele in a case of diallelic locus in Hardy Weinberg ,eq 20.23c p.694 Wash & Lynch, 2018.
//' We could also calculate it by averaging the genetic relatedness of all possible pairs in the population (it give the same values , I tested it).
//'
//' ~~~~~~~~~~ References ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//' Wash & Lynch, 2018. Evolution and selection of quantitative traits. Oxford University Press
//' Day-Williams et al. 2011. Linkage analysis without defined pedigrees. Gen. Epid. 35:360-370.
//' Oliehoek et al. 2006. Estimating relatedness between individuals in general populations with a focus on their use in conservation programs. Genetics 173: 483–496
//'
//'
//'
//'
//'
//' @param dna List with dna of all individuals in the population
//' @useDynLib SHIM
//' @import Rcpp
//' @export
//' @examples
//'\dontrun{
//'  sim_test <- simulation$new(number_years = 10, number_clans = 1,
//'                             start_clan_size = 10, sex_ratio = 0.5,
//'                             mean_age = 72, burnins = 0)
//' mean_genetic_relatedness <- mean_genetic_relatedness(purrr::flatten(lapply(sim_test$crater_ID$clans,
//' function(x){ lapply(x$inhabitants, function(y){
//'                               y$genome$dna
//'                             })
//'                           })))
//' }
//'
// [[Rcpp::export]]

NumericVector mean_genetic_relatedness (List dna) {

  // number of individuals in the population
    int nb = dna.size();
  // number of loci in dna
    NumericMatrix dna_subset = dna[1];
    int loci_number = dna_subset.nrow();
  //frequence of alleles 1 per loci in the population
  // sum allelic values per loci on all individuals
    NumericVector sum_per_loci(loci_number);
    for ( int ind = 0; ind<nb; ind ++) {
      NumericMatrix dnai = dna[ind];
      for (int l = 0; l<loci_number; l++) {
        sum_per_loci[l] += (dnai(l, 0) + dnai(l, 1));
      }
    }
    // division per the number of individuals and 2 because loci are diallelic, if sum_per_loci = 2*popSize => freq allele 1 = 1
    NumericVector freq_per_loci = sum_per_loci/ (nb*2);
    // sum of average similarities per loci
    NumericVector s_average = pow(freq_per_loci, 2.0)+ pow( 1- freq_per_loci, 2.0) ;

    return (s_average);
}

