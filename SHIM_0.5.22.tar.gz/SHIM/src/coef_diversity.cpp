
#include <Rcpp.h>
using namespace Rcpp;

//' Calcul coef of diversity
//'
//' genetique diversity in the population (Neil & Kumar book p.251 eq.12.54)
//' @param dna List with dna of all individuals in the population
//' @useDynLib SHIM
//' @import Rcpp
//' @export
//'
// [[Rcpp::export]]
NumericVector diversity_coef (List dna) {

  double nb = dna.size();
  NumericMatrix dna_subset = dna[1];
  int loci_number = dna_subset.nrow();
  NumericVector diversity_coef (loci_number);
  for ( int ind1 = 0; ind1<(nb-1); ind1 ++) {
    NumericMatrix dna1 = dna[ind1];
    for (int ind2 = ind1+1; ind2<nb; ind2 ++ ){
      NumericMatrix dna2 = dna[ind2];
      NumericVector d_locus (loci_number);
      // calculate the number of different alleles per loci
      for (int i = 0; i < loci_number; i++) {
        //double sum_locus = 0;
        double sum_id1 = dna1(i, 0) + dna1(i, 1);
        double sum_id2 = dna2(i, 0) + dna2(i, 1);
        // sum over the column (i.e. the two alleles) of the matrix to calculate a per loci similarity
        d_locus [i]=  abs(sum_id1 - sum_id2);
        // sum the similarity  over loci
      }

      diversity_coef = diversity_coef + d_locus ;
    }

  }
  // correct by the number of possible pairs n*(n-1)/2
  diversity_coef = 2*diversity_coef/( nb*(nb-1));
  return(diversity_coef);
}
