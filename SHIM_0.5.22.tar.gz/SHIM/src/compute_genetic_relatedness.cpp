#include <Rcpp.h>
using namespace Rcpp;

//' Calculate_genetic_relatedness
//'
//' between a focal female and all males in the clan.
//'
//'  Genetic relatedness is the proportion of similar alleles identical by descent.
//'  Because similar alleles can be identical by descent or identical by state,
//'  the genetic relatedness  must be corrected by the average genetic relatedness in the base population (Wash & Lynch 2018, p.693)
//'  therefore genetic relatedness can be <0 if individuals are less related than average,
//'  The coefficient of genetic relatedness we calculate here is also called the Day-Williams estimator (Day-Williams et al. 2011, eq 1 and 2 and Wash & Lynch, 2018 eq.20.23d p694)
//' - this estimator perform well compare to others in structured population- Oliehoek et al. 2006.
//'  we first calculate the coefficient of molecular similarity per loci,
//'  then we average it over all the loci and correct it with he average genetic relatedness in the base population over all loci
//'
//' ~~~~~~~~~~ References ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//' Wash & Lynch, 2018. Evolution and selection of quantitative traits. Oxford University Press
//' Day-Williams et al. 2011. Linkage analysis without defined pedigrees. Gen. Epid. 35:360-370.
//' Oliehoek et al. 2006. Estimating relatedness between individuals in general populations with a focus on their use in conservation programs. Genetics 173: 483–496
//'
//' @param dna_f matrix with female dna (row: loci, column: alleles).
//' @param dna_males a list of males dna (i.e list of matrix).
//' @param s_average a measure of average similarity in the base population (calculated with allelic frequencies in the base population).
//' @useDynLib SHIM
//' @import Rcpp
//' @export
//' @return vector with coefficients of similarity between the focal female and males
//' @examples
//' \dontrun{
//' sim_test <- simulation$new(number_years = 10, number_clans = 1,
//'                             start_clan_size = 10, sex_ratio = 0.5,
//'                             mean_age = 72, burnins = 0)
//' potential_males <-
//' sim_test$crater$clans[[1]]$inhabitants[seq(2:length(sim_test$crater$clans[[1]]$inhabitants))]
//' sim <- similarity(sim_test$crater$clans[[1]]$inhabitants[[1]]$genome$dna,lapply(
//' potential_males, function(x){x$genome$dna}), s_average = rep(0.5, sim_test$loci_number))
//'}
//'
// [[Rcpp::export]]

NumericVector compute_genetic_relatedness (NumericMatrix dna_f, List dna_males, NumericVector s_average){

  int nb_m = dna_males.size();
  // vector containing similarity scores between the focal female and every suitable males
  NumericVector relatedness_pairs(nb_m);
  int loci_number = dna_f.nrow();
  int k = 0;
  NumericVector similarity_locus (loci_number);
  // loop on males
  for ( int ind = 0; ind<nb_m; ind ++) {
    NumericMatrix dna_m = dna_males[ind];
    double sum_relative_simi = 0;
    //calculate the coefficient of similarity per loci, that is the proportion of similar alleles between 2 individuals
    // the calcul (sum_id1 - 1) * (sum_id2 - 1) + 1 is a trick to simplify calculation.
    // coefficient of similarity per loci :
    //S = 1 if loci_ind1 = 0 1 and loci_ind2 = 0 1 ,
    //S = 0.5 if  loci_ind1 = 0 0 and loci_ind2 = 0 1, or loci_ind1 = 1 1 and loci_ind2 = 0 1
    //S = 0 if loci_ind1 = 0 0 and loci_ind2 = 1 1, or vice versa
    for (int i = 0; i < loci_number; i++) {
      //double sum_locus = 0;
      double sum_id1 = dna_f(i, 0) + dna_f(i, 1);
      double sum_id2 = dna_m(i, 0) + dna_m(i, 1);
      // sum over the column (i.e. the two alleles) of the matrix to calculate a per loci similarity
      similarity_locus [i]=  ((sum_id1 - 1) * (sum_id2 - 1) + 1)/2;
      // correct the similarity per the average similarity in the population and sum the similarity over loci
      // to calculate an average similarity over all loci
      sum_relative_simi +=  (similarity_locus [i]- s_average[i])/(1 - s_average[i]);
    }

    relatedness_pairs[k]= sum_relative_simi/loci_number;
    //relatedness_pairs[k] = (sum(sum_locus)-sum(s_average))/(loci_number-sum(s_average)); // an other way to write the calculation, gives the same result
    k = k + 1;
  }
  return(relatedness_pairs);
 }
