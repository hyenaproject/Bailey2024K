library(testthat)
library(SHIM)

test_check("SHIM")
