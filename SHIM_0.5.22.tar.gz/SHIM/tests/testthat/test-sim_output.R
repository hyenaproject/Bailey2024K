context("Test general simulation behaviour...")

test_that("A simulation object was initialised properly in setup", {

  #Check that an R6 simulation object was created
  expect_identical(class(sim_test), c("simulation", "R6"))

  #Check that simulation has a version number
  expect_true(all(class(sim_test$version) %in% c("package_version", "numeric_version")))

})

test_that("All individuals should have rank data", {

  #Test that both standardised and ordinal rank are correctly recorded at all times
  expect_true(all(!is.na(sim_test$Rawdata_tbl$stand_rank)))
  expect_true(all(!is.na(sim_test$Rawdata_tbl$ord_rank)))

})

test_that("Simulations do not create duplicate individuals", {

  #Check for duplicate individuals in simulated start data
  sim_test_rows <- sim_test$crater$snapshot_data %>%
    dplyr::bind_rows() %>%
    dplyr::group_by(.data$ID, .data$current_date) %>%
    dplyr::filter(dplyr::n() > 1) %>%
    nrow()

  #Check for multiple birthdates for an individual in simulated start data
  sim_test_birthdates <- sim_test$crater$snapshot_data %>%
    dplyr::bind_rows() %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::filter(length(unique(.data$birth_date)) > 1) %>%
    nrow()

  expect_equal(sim_test_rows, 0L)
  expect_equal(sim_test_birthdates, 0L)

  #Check for duplicate individuals in 'real' start data
  sim_test_real_rows <- sim_test_real$crater$snapshot_data %>%
    dplyr::bind_rows() %>%
    dplyr::group_by(.data$ID, .data$current_date) %>%
    dplyr::filter(dplyr::n() > 1) %>%
    nrow()

  #Check for multiple birthdates for an individual in simulated start data
  sim_test_real_birthdates <- sim_test_real$crater$snapshot_data %>%
    dplyr::bind_rows() %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::filter(length(unique(.data$birth_date)) > 1) %>%
    nrow()

  expect_equal(sim_test_real_rows, 0L)
  expect_equal(sim_test_real_birthdates, 0L)

})

test_that("Running sim with `simulation_fitrun` produces same result as regular two step fitting", {

  expect_equal(sim_test_fitrun$Rawdata_tbl, sim_test$Rawdata_tbl)

})

test_that("full and summary outputs match", {

  txt_file <- read.csv(here::here("./test.txt"), sep = ",")

  ## POPULATION SIZE
  txt_popsize <- txt_file$pop_size

  summary_popsize <- sim_test_txt$Summarydata_tbl %>%
    dplyr::pull(.data$pop_size)

  full_popsize <- sim_test$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(pop_size = dplyr::n()) %>%
    dplyr::pull(.data$pop_size)

  #Test text and summary are the same
  expect_equal(txt_popsize, summary_popsize)
  #Test summary and full are the same
  expect_equal(summary_popsize, full_popsize)

  ## MOTHERS AND FATHERS
  txt_mothers_fathers <- txt_file %>%
    dplyr::rowwise() %>%
    dplyr::transmute(mothers = sum(dplyr::c_across(cols = dplyr::ends_with("mothers"))),
                     fathers = sum(dplyr::c_across(cols = dplyr::ends_with("fathers"))))

  txt_mothers <- txt_mothers_fathers$mothers
  txt_fathers <- txt_mothers_fathers$fathers

  summary_mothers_fathers <- sim_test_txt$Summarydata_tbl %>%
    dplyr::rowwise() %>%
    dplyr::transmute(mothers = sum(dplyr::c_across(cols = dplyr::ends_with("mothers"))),
                     fathers = sum(dplyr::c_across(cols = dplyr::ends_with("fathers"))))

  summary_mothers <- summary_mothers_fathers$mothers
  summary_fathers <- summary_mothers_fathers$fathers

  full_mothers_fathers <- sim_test$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(mothers = length(unique(stats::na.omit(mother[age == 0]))),
                     fathers = length(unique(stats::na.omit(father[age == 0]))))

  full_mothers <- full_mothers_fathers$mothers
  full_fathers <- full_mothers_fathers$fathers

  #Test text and summary are the same
  expect_equal(txt_mothers, summary_mothers)
  expect_equal(txt_fathers, summary_fathers)
  #Test summary and full are the same
  expect_equal(summary_mothers, full_mothers)
  expect_equal(summary_fathers, full_fathers)

  ## DEATHS
  ## NOTE: This one is a bit tricky. In the summary output, each row is a snapshot
  ## in time. The 'deaths' is a snapshot of those that have died UP UNTIL THIS POINT
  ## (i.e. deaths in the past time step).
  ## In comparison, in the full data deaths are assigned the day after the last sighting.
  ## To make these two comparable we need to transpose the dates from one group to match
  ## the other.
  ## We will round up the full data to show the deaths in the previous timestep.
  dates <- txt_file %>%
    dplyr::select("date") %>%
    dplyr::mutate(date = as.Date(.data$date))

  txt_dead <- txt_file %>%
    dplyr::rowwise() %>%
    dplyr::transmute(dead = sum(dplyr::c_across(cols = dplyr::ends_with("dead")))) %>%
    dplyr::pull(.data$dead)

  summary_dead <- sim_test_txt$Summarydata_tbl %>%
    dplyr::rowwise() %>%
    dplyr::transmute(dead = sum(dplyr::c_across(cols = dplyr::ends_with("dead")))) %>%
    dplyr::pull(.data$dead)

  full_death_counts <- sim_test$Deaths_tbl %>%
    dplyr::group_by(.data$deathdate) %>%
    dplyr::summarise(dead = dplyr::n()) %>%
    dplyr::mutate(date = .data$deathdate)

  full_dead_output <- dplyr::left_join(dates, full_death_counts, by = "date") |>
    dplyr::mutate(dead = tidyr::replace_na(.data$dead, 0L)) %>%
    dplyr::pull(.data$dead)

  #Test text and summary are the same
  expect_equal(txt_dead, summary_dead)
  #Test summary and full are the same
  expect_equal(summary_dead, full_dead_output)

  ## DISPERSER MALES
  txt_disp <- txt_file %>%
    #Remove 1st row. There will always be 0 dispersers at the start of the study
    dplyr::slice(-1) %>%
    dplyr::rowwise() %>%
    dplyr::transmute(disp = sum(dplyr::c_across(cols = dplyr::contains("disp") & !dplyr::contains("dead")))) %>%
    dplyr::pull(.data$disp)

  summary_disp <- sim_test_txt$Summarydata_tbl %>%
    #Remove 1st row. There will always be 0 dispersers at the start of the study
    dplyr::slice(-1) %>%
    dplyr::rowwise() %>%
    dplyr::transmute(disp = sum(dplyr::c_across(cols = dplyr::contains("disp") & !dplyr::contains("dead")))) %>%
    dplyr::pull(.data$disp)

  full_disp <- sim_test$Selections_tbl %>%
    dplyr::filter(.data$origin != .data$destination) |>
    #Take the first dispersal date
    dplyr::group_by(.data$ID) %>%
    dplyr::slice(1) %>%
    #Add the death date
    dplyr::left_join(multiple = "all", sim_test$Deaths_tbl, by = "ID") %>%
    dplyr::select("ID", "date", "deathdate") %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::summarise(deathdate = deathdate,
                     date = list(seq.Date(from = .data$date,
                                          to = max(sim_test$Rawdata_tbl$current_date), by = "months"))) %>%
    tidyr::unnest("date") %>%
    dplyr::filter(is.na(.data$deathdate) | .data$date < .data$deathdate) %>%
    dplyr::group_by(.data$date) %>%
    dplyr::summarise(disp = dplyr::n()) %>%
    dplyr::pull(.data$disp)

  #Test text and summary are the same
  expect_equal(txt_disp, summary_disp)
  #Test summary and full are the same
  expect_equal(summary_disp, full_disp)

})

test_that("File has txt and RDS output", {

  skip_if(!test_parallel)

  test <- readRDS(sim_iterate[[1]]$save_files$RDS_file)

  expect_true("RDS_file" %in% names(test$save_files))

})

test_that("tmp files are unique", {

  #Run two short sims with same seed
  short_sim <- simulation$new(step_size = 1,
                              number_clans = 2, start_clan_size = 2,
                              sex_ratio = 0.5, mean_age = 72,
                              calc_SS = FALSE, seed = 400)
  short_sim$run_sim(number_steps = 2)

  short_sim2 <- simulation$new(step_size = 1,
                              number_clans = 2, start_clan_size = 2,
                              sex_ratio = 0.5, mean_age = 72,
                              calc_SS = FALSE, seed = 400)
  short_sim2$run_sim(number_steps = 2)

  #Txt files should be unique
  expect_false(identical(short_sim$save_files$txt_file, short_sim2$save_files$txt_file))

  #But content of the files should be identical
  expect_identical(read.delim(short_sim$save_files$txt_file, sep = ","),
                   read.delim(short_sim2$save_files$txt_file, sep = ","))

})
