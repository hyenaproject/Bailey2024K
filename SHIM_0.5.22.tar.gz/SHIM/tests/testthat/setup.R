# Teardown procedure
# Run after all tests are completed
## Define this first so that everything is removed if there is a failure during setup
withr::defer(remove(sim_test_loweffort), teardown_env())
withr::defer(remove(sim_test_fitrun), teardown_env())
withr::defer(remove(sim_test_txt), teardown_env())
withr::defer(remove(sim_test_real), teardown_env())
withr::defer(remove(sim_test_6mo), teardown_env())
withr::defer(file.remove(here::here("./test.txt")), teardown_env())
withr::defer(file.remove(here::here("./test_die.txt")), teardown_env())
withr::defer(file.remove(here::here("./test_6mo.txt")), teardown_env())

## Boolean that affects which tests are run
withr::defer(remove(test_elasticity), teardown_env())
withr::defer(remove(test_parallel), teardown_env())
withr::defer(remove(test_genome), teardown_env())

## For speed, we are skipping these for now
test_elasticity <- FALSE
test_parallel <- FALSE
test_genome <- FALSE

#Run small simulation to check everything is working
print("Fit and run separately...")
sim_test <- simulation$new(step_size = 1,
                           ## Use generated data so that it's faster
                           start_pop = NULL,
                           number_clans = 2, start_clan_size = 10,
                           sex_ratio = 0.5, mean_age = 72,
                           calc_SS = FALSE, seed = 10)
sim_test$run_sim(number_steps = 10)

print("Change simulation predictors...")
sim_test_loweffort <- simulation$new(step_size = 1,
                                     ## Use generated data so that it's faster
                                     start_pop = NULL,
                                     number_clans = 2, start_clan_size = 10,
                                     sex_ratio = 0.5, mean_age = 72,
                                     calc_SS = FALSE, seed = 10,
                                     predictors = list(after1y_effort_all = \(...) 0.05))
sim_test_loweffort$run_sim(number_steps = 10)

print("Run simulation_fitrun...")
sim_test_fitrun <- simulation_fitrun(number_steps = 10, step_size = 1,
                                     ## Use generated data so that it's faster
                                     start_pop = NULL,
                                     number_clans = 2, start_clan_size = 10,
                                     name = "test", sex_ratio = 0.5, mean_age = 72,
                                     save = 'no', return = TRUE,
                                     seed = 10)

sim_test_txt <- simulation$new(step_size = 1,
                               ## Use generated data so that it's faster
                               start_pop = NULL,
                               number_clans = 2, start_clan_size = 10,
                               sex_ratio = 0.5, mean_age = 72,
                               calc_SS = FALSE, seed = 10, save_size = 1)
sim_test_txt$run_sim(number_steps = 10, save_file = here::here("./test.txt"))

#Run an example where one clan will go extinct.
#Use this to check that save .txt matches internal data
#For this to test properly, we need to insert a 'dead' clan in between two other clans
print("Run with a dead clan...")
start_pop_die_example <- dplyr::filter(start_pop_example, current_clan == "A") %>%
  dplyr::bind_rows(start_pop_example[2, ] %>%
                     dplyr::mutate(current_clan = "S",
                                   age = 400)) %>%
  dplyr::bind_rows(dplyr::filter(start_pop_example, current_clan == "E"))
sim_test_dead <- simulation$new(step_size = 1,
                                start_pop = start_pop_die_example,
                                seed = 200)
sim_test_dead$run_sim(number_steps = 3, save_file = here::here("./test_die.txt"))

sim_test_real <- simulation$new(start_pop = start_pop_example,
                                step_size = 1,
                                seed = 400)
sim_test_real$run_sim(number_steps = 10)

print("Run with non-numeric year values...")
## This is useful if we want to run simulation at timesteps <1 year
new_modlist <- list(allF         = glm(surv ~ year,
                                       data = model.frame(model_list$allF) %>%
                                         dplyr::mutate(year = paste(year, sample(c(1, 2), size = dplyr::n(), replace = TRUE),
                                                                    sep = "_")),
                                       family = "binomial"),
                    #Postdisp males don't consider rank
                    postdispM     = glm(surv ~ year,
                                        data = model.frame(model_list$postdispM) %>%
                                          dplyr::mutate(year = paste(year, sample(c(1, 2), size = dplyr::n(), replace = TRUE),
                                                                     sep = "_")),
                                        family = "binomial"),
                    predispM      = glm(surv ~ year,
                                        data = model.frame(model_list$predispM) %>%
                                          dplyr::mutate(year = paste(year, sample(c(1, 2), size = dplyr::n(), replace = TRUE),
                                                                     sep = "_")),
                                        family = "binomial"),
                    twin          = glm(twin ~ year,
                                        data = model.frame(model_list$twin) %>%
                                          dplyr::mutate(year = paste(year, sample(c(1, 2), size = dplyr::n(), replace = TRUE),
                                                                     sep = "_")),
                                        family = "binomial"),
                    #Male dispersal is the same in all cases
                    disp          = model_list$disp,
                    primirepro    = glm(repro ~ year,
                                        data = model.frame(model_list$primirepro) %>%
                                          dplyr::mutate(year = paste(year, sample(c(1, 2), size = dplyr::n(), replace = TRUE),
                                                                     sep = "_")),
                                        family = "binomial"),
                    nonprimirepro = glm(repro ~ year,
                                        data = model.frame(model_list$nonprimirepro) %>%
                                          dplyr::mutate(year = paste(year, sample(c(1, 2), size = dplyr::n(), replace = TRUE),
                                                                     sep = "_")),
                                        family = "binomial"))

sim_test_6mo <- simulation$new(step_size = 1,
                               start_pop = start_pop_example, models = new_modlist,
                               seed = 200,
                               predictors = list(year = \(...) "1997_1",
                                                 age = \(ID) ID$age,
                                                 is_philo = \(ID) ID$birth_date == ID$first_date))
sim_test_6mo$run_sim(number_steps = 5, save_file = here::here("./test_6mo.txt"))

if (test_parallel) {

  withr::defer(remove(sim_iterate), teardown_env())
  withr::defer(system(paste0("rm -r ", here::here("./test_folder"))), teardown_env())
  withr::defer(system(paste0("rm -r ", here::here("./test_folder_multistart"))), teardown_env())

  #Check iteration works in parallel
  print("Run simulation_iterate in parallel...")
  sim_iterate <- simulation_iterate(start_pops = start_pop_example, number_steps = 2, step_size = 1,
                                    sim_years = 1996:1997,
                                    ## Include new predictors to make sure they work in simulation_iterate
                                    predictors = list(foo = \(...) 10),
                                    i = 2,
                                    save_dir = here::here("./test_folder"),
                                    return = TRUE, iterator_seed = 400,
                                    .parallel.min = 1, CPUcores = 2)

  #Check iteration with multiple start pops works in parallel
  #Use different start populations with 10 or 20 individuals
  print("Run sim_iterate with multiple starting populations...")
  sim_iterate_multistart <- simulation_iterate(start_pops = list(start_pop_example[1:20, ],
                                                                 start_pop_example[1:10, ]), number_steps = 2, step_size = 1,
                                               sim_years = 1996:1997,
                                               predictors = list(foo = \(...) 10),
                                               i = 2,
                                               save_dir = here::here("./test_folder_multistart"),
                                               return = TRUE, iterator_seed = 400,
                                               .parallel.min = 1, CPUcores = 2)

}

if (test_elasticity) {

  withr::defer(remove(sim_elasticity), teardown_env())
  withr::defer(system(paste0("rm -r ", here::here("./test_folder_elasticity"))), teardown_env())

  print("Run simulation_elasticity...")
  #Create dummy data
  linkfn <- binomial()$linkinv
  mod_data <- data.frame(age = sample(1:300, size = 2000, replace = TRUE)) %>%
    dplyr::mutate(Fsurv = rbinom(n = dplyr::n(), size = 1, prob = linkfn(3 + age*-0.005 + rnorm(n = dplyr::n()))),
                  Mpresurv = rbinom(n = dplyr::n(), size = 1, prob = linkfn(1 + age*0.01 + rnorm(n = dplyr::n()))),
                  Mpostsurv = rbinom(n = dplyr::n(), size = 1, prob = linkfn(3 + age*-0.01 + rnorm(n = dplyr::n()))),
                  primirepro = rbinom(n = dplyr::n(), size = 1, prob = linkfn(-2 + age*0.06 + rnorm(n = dplyr::n()))),
                  nonprimirepro = rbinom(n = dplyr::n(), size = 1, prob = linkfn(2 + age*-0.01 + rnorm(n = dplyr::n()))),
                  twin = rbinom(n = dplyr::n(), size = 1, prob = linkfn(0 + age*-0.005 + rnorm(n = dplyr::n()))),
                  disp = rbinom(n = dplyr::n(), size = 1, prob = linkfn(-1 + rnorm(n = dplyr::n()))))

  modlist <- list(allF = spaMM::fitme(Fsurv ~ age, data = mod_data, family = "binomial"),
                  predispM = spaMM::fitme(Mpresurv ~ age, data = mod_data, family = "binomial"),
                  postdispM = spaMM::fitme(Mpostsurv ~ age, data = mod_data, family = "binomial"),
                  primirepro = spaMM::fitme(primirepro ~ age, data = mod_data, family = "binomial"),
                  nonprimirepro = spaMM::fitme(nonprimirepro ~ age, data = mod_data, family = "binomial"),
                  twin = spaMM::fitme(twin ~ age, data = mod_data, family = "binomial"),
                  disp = spaMM::fitme(disp ~ 1, data = mod_data, family = "binomial"))

  sim_elasticity <- simulation_elasticity(original_models = modlist,
                                           effect = 5, #Intercept changes by 5x and 1/5x
                                           focal_mods = c("twin", "allF"),
                                           start_pops = list(start_pop_example[1:30, ],
                                                             start_pop_example[1:20, ]),
                                           ## Include new predictors to make sure they work in simulation_iterate
                                           predictors = list(foo = \(...) 10),
                                           number_steps = 2, step_size = 1,
                                           sim_years = 1996:1997,
                                           i = 2,
                                           save_dir = here::here("./test_folder_elasticity"),
                                           return = TRUE, iterator_seed = 10,
                                           parallel = FALSE)

}
