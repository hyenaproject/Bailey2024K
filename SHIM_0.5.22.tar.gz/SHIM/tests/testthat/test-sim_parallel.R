context("Test parallel processing behaviour...")

test_that("Iterator produces expected outcome", {

  skip_if(!test_parallel)

  #Generates expected folders
  folder_names <- list.dirs(here::here("./test_folder"), full.names = FALSE)
  expect_equal(folder_names, c("", "1996", "1997"))

  #Check for txt files
  txt_files_96 <- list.files(here::here("./test_folder/1996"), pattern = ".txt")
  txt_files_97 <- list.files(here::here("./test_folder/1997"), pattern = ".txt")
  expect_equal(c(txt_files_96, txt_files_97), c("simulation_pop1_1996_1.txt", "simulation_pop1_1996_2.txt",
                                                "simulation_pop1_1997_1.txt", "simulation_pop1_1997_2.txt"))

  #Check that txt files match iteration outputs
  sim_96_1 <- read.csv(here::here(paste0("./test_folder/1996/", txt_files_96[1])), sep = ",") %>%
    dplyr::as_tibble() %>%
    dplyr::mutate(date = as.Date(.data$date))
  sim_97_1 <- read.csv(here::here(paste0("./test_folder/1997/", txt_files_97[1])), sep = ",") %>%
    dplyr::as_tibble() %>%
    dplyr::mutate(date = as.Date(.data$date))

  expect_equal(sim_iterate[[1]]$Summarydata_tbl, sim_96_1)
  expect_equal(sim_iterate[[3]]$Summarydata_tbl, sim_97_1)

})

## NOTE: THIS TEST MUST BE CARRIED OUT AFTER THE PREVIOUS ONE
## By extending simulation with parallel processing we remove the mutable behaviour
## of the R6 object, so the original file name 'sim_iterate' will no longer
## match the saved data.
test_that("Multiple iterations can be extended", {

  skip_if(!test_parallel)

  nrow_preextension <- purrr::map_dbl(.x = sim_iterate,
                                      .f = ~{

                                        nrow(..1$Summarydata_tbl)

                                      })

  #Test without parallel
  simulation_reiterate(sim_iterate, number_steps = 2, parallel = FALSE)

  nrow_extension1 <- purrr::map_dbl(.x = sim_iterate,
                                    .f = ~{

                                      nrow(..1$Summarydata_tbl)

                                    })

  expect_equal(nrow_preextension + 2, nrow_extension1)

  #Test with parallel
  #When running in parallel, need to return the output
  #seems making changes in parallel does not maintain mutability of input objects
  #i.e. they change in the parallel env but not in the original env.
  #Possible warning if using Windows. This appears to be a bug in RStudio
  #https://stackoverflow.com/questions/27623901/r-warning-packagestats-may-not-be-available-when-loading
  sim_iterate_new <- simulation_reiterate(sim_iterate, number_steps = 2,
                                          parallel = TRUE,
                                          .parallel.min = 1, CPUcores = 2)

  nrow_extension2 <- purrr::map_dbl(.x = sim_iterate_new,
                                    .f = ~{

                                      nrow(..1$Summarydata_tbl)

                                    })

  expect_equal(nrow_extension1 + 2, nrow_extension2)

  #Trying to extent old output that has already been extended in parallel
  #will return error
  expect_error(simulation_reiterate(sim_iterate, number_steps = 2,
                                    parallel = TRUE,
                                    .parallel.min = 1, CPUcores = 2))

})

