context("Test clan class behaviour...")

test_that("A clan object can be initialised properly", {

  test_crater <- crater$new(number_clans = 8, start_clan_size = 20, start_pop = "sim",
                            sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test)

  test_clan   <- clan$new(clan_name = "test_clan", start_clan_size = 20,
                          crater_ID = test_crater, sex_ratio = 0.5, mean_age = 72)

  #Should have the same name as argument in initialisation
  expect_identical(test_clan$clan_name, "test_clan")

  #Should have number of inhabitants the same as argument in initialisation
  expect_identical(length(test_clan$inhabitants), 20L)

  #Check that an R6 clan object was created
  expect_identical(class(test_clan), c("clan", "R6"))

  #Check that parent and grandparent objects are available
  expect_identical(test_clan$simulation_ID, sim_test)
  expect_identical(test_clan$crater_ID, test_crater)

})
