context("Test genome class behaviour...")

test_that("A genome object can be initialised properly", {

  skip_if(!test_genome)

  test_crater <- crater$new(number_clans = 8, start_clan_size = 20, start_pop = "sim",
                            sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test)

  test_clan   <- clan$new(clan_name = "test_clan", start_clan_size = 20,
                          crater_ID = test_crater, sex_ratio = 0.5, mean_age = 72)

  test_genome <- genome$new(sim_test$loci_number, sim_test$allelic_diversity,
                            test_clan$inhabitants[[1]],
                            test_clan$inhabitants[[length(test_clan$inhabitants)]])

  #Check that an R6 genome object was created
  expect_identical(class(test_genome), c("genome", "R6"))

})
