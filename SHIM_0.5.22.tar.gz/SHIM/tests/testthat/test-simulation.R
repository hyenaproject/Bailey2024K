context("Test simulation class behaviour...")

test_that("Simulation default works...", {

  #Should work with only number_steps (everything else is default)
  expect_identical(class(simulation$new()), c("simulation", "R6"))

  #Should have a starting date on 1996/04/12 (first date we start pop)
  expect_identical(simulation$new()$date, structure(9598, class = "Date"))

})

test_that("Simulation initialisation with different models behaves as expected...", {

  #Fails when not provided with model list (or left blank)
  expect_error(simulation$new(models = "wrong!!"))

  #Should work with model list
  modlist <- list(allF          = lm(1 ~ 1),
                  postdispM     = lm(1 ~ 1),
                  predispM      = lm(1 ~ 1),
                  twin          = lm(1 ~ 1),
                  disp          = lm(1 ~ 1),
                  nonprimirepro = lm(1 ~ 1),
                  primirepro    = lm(1 ~ 1))
  temp_sim <- simulation$new(models = modlist)
  expect_identical(class(temp_sim),
                   c("simulation", "R6"))
  expect_identical(temp_sim$models, modlist)

  #Fails with list without using accepted model class
  expect_error(simulation$new(models = list(allF          = NA,
                                            postdispM     = NA,
                                            predispM      = NA,
                                            twin          = NA,
                                            disp          = NA,
                                            nonprimirepro = NA,
                                            primirepro    = NA)))

})

test_that("Can used fixed predictors in simulation...", {

  #Accepts single integer year
  temp_sim <- simulation$new(predictors = list(year = function(...) 1996))
  expect_identical(class(temp_sim),
                   c("simulation", "R6"))

  ## Test that year is the same for different models
  expect_identical(temp_sim$predictors$allF$year(temp_sim$crater$clans[[1]]$inhabitants[[1]]),
                   temp_sim$predictors$twin$year(temp_sim$crater$clans[[1]]$inhabitants[[1]]))

})

test_that("Simulations saves data as expected when truncating...", {

  #Run full simulation output
  temp_sim_full       <- simulation$new(seed = 123)
  temp_sim_full$run_sim(number_steps = 2)

  #Run truncated output with 1-2 trunc size
  temp_sim_fulltrunc3 <- simulation$new(save_size = 3, seed = 123)
  temp_sim_fulltrunc3$run_sim(number_steps = 2)
  temp_sim_fulltrunc1 <- simulation$new(save_size = 1, seed = 123)
  temp_sim_fulltrunc1$run_sim(number_steps = 2)

  #full output should be the same as truncated output with trunc_size 3
  #(We have 2 timesteps = 1 starting snapshot + 2 timestep snapshots)
  expect_equal(temp_sim_full$crater$snapshot_data, temp_sim_fulltrunc3$crater$snapshot_data)

  #Last snapshot should be the same in ALL sims
  expect_equal(temp_sim_full$crater$snapshot_data[[3]], temp_sim_fulltrunc1$crater$snapshot_data[[1]])

  #Length of snapshot data should equal save_size
  expect_equal(temp_sim_fulltrunc1$save_size, length(temp_sim_fulltrunc1$crater$snapshot_data))
  expect_equal(temp_sim_fulltrunc3$save_size, length(temp_sim_fulltrunc3$crater$snapshot_data))

})

test_that("Simulation can be generated using input data frame", {

  input <- structure(list(ID = c("A-001", "A-018", "A-046", "A-054", "A-015",
                                 "A-008", "A-045", "A-011", "L-001", "L-003"),
                          date = structure(c(9598,
                                             9598, 9598, 9598, 9598, 9598, 9598, 9598, 9598, 9598), class = "Date"),
                          sex = c("female", "female", "male", "male", "female", "female",
                                  "male", "male", "female", "female"),
                          age = c(7.5, 0.5, 0.5,
                                  0, 5.5, 1.5, 7.5, 3.5, 15.5, 16.5),
                          birth_date = structure(c(6715,
                                                   9268, 9268, 9487, 7502, 8906, 6768, 8139, 3756, 3390), class = "Date"),
                          birth_clan = c("A", "A", "A", "A", "A", "A", "X", "X", "L",
                                         "L"),
                          motherID = c(NA, "A-001", "A-001", NA, NA, "A-015",
                                       NA, NA, NA, NA),
                          fatherID = c(NA, "A-045", NA, "A-011", NA,
                                       "A-045", NA, NA, NA, NA),
                          current_clan = c("A", "A", "A",
                                           "A", "A", "A", "A", "A", "L", "L"),
                          lifetime_RS = c(4L, 0L,
                                          0L, 0L, 1L, 0L, 3L, 1L, 2L, 1L),
                          tenure = c(0, NA, NA, NA,
                                     0, NA, 0, 0, 1, 1),
                          selections = list(NULL, NULL, NULL, NULL,
                                            NULL, NULL,
                                            structure(list(origin = "X", destination = "A",
                                                           date = structure(9598, class = "Date")),
                                                      class = c("tbl_df",
                                                                "tbl", "data.frame"), row.names = c(NA, -1L)), structure(list(
                                                                  origin = "X", destination = "A", date = structure(9598, class = "Date")),
                                                                  class = c("tbl_df",
                                                                            "tbl", "data.frame"), row.names = c(NA, -1L)), NULL, NULL),
                          rank = c(1L, 3L, 4L, 8L, 20L, 21L, 36L, 40L, 17L, 20L),
                          rank_std = c(1, 0.902439024390244, 0.853658536585366,
                                       0.658536585365854, 0.073170731707317, 0.024390243902439,
                                       -0.707317073170732, -0.902439024390244, -0.142857142857143,
                                       -0.357142857142857),
                          siblingID = c(NA, "A-046", "A-018",
                                        NA, NA, NA, NA, NA, NA, NA),
                          last_repro = c(0, 0, 0, 0, 0,
                                         0, 0, 0, 0, 0),
                          first_repro = c(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)),
                     row.names = c(NA, -10L), class = c("tbl_df", "tbl", "data.frame"))

  sim_test <- simulation$new(start_pop = input)

  #Extract all individuals to look at attributes
  all_indv <- purrr::map(.x = sim_test$crater$clans,
                         .f = ~{

                           ..1$inhabitants

                         }) %>%
    unlist()

  #Expect 2 clans
  expect_equal(length(sim_test$crater$clans), 2L)

  #Look at individual A-001 with no parents
  expect_null(all_indv[[1]]$motherID)
  expect_null(all_indv[[1]]$fatherID)
  expect_equal(all_indv[[1]]$age, 7.5)

  #Look at individual A-018 with both parents
  expect_equal(all_indv[[2]]$motherID, all_indv[[1]])
  expect_equal(all_indv[[2]]$fatherID, all_indv[[7]])
  expect_equal(all_indv[[2]]$age, 0.5)

  #Look at individual A-011 with selection info
  expect_true(all_indv[[8]]$birth_clan != all_indv[[8]]$clan_name)
  expect_true(!is.null(all_indv[[8]]$first_selection))

  #Look at individual A-046 with a sibling
  expect_equal(all_indv[[3]]$sib_ID, all_indv[[2]])

})

test_that("Simulation with only 1 individual left will still terminate properly...", {

  #Fails when there is only 1 individual left
  #In this data, all but one female are >= 25yo an will die straight away.
  #Test should fail once there is only 1 individual left
  doomed_pop <- structure(list(ID = c("A-000", "E-000", "F-000", "L-000",
                                      "M-000", "N-000", "S-000", "T-000"),
                               date = structure(c(9598, 9598, 9598, 9598, 9598, 9598, 9598, 9598), class = "Date"),
                               birth_date = structure(c(6715, 8340, 6767, 3756, 5642, 8210, 7043, 7354), class = "Date"),
                               sex = c("female", "female", "female", "female", "female", "female", "female", "female"),
                               age = c(300, 300, 300, 300, 300, 300, 300, 180),
                               birth_clan = c("A", "E", "F", "L", "M", "N", "S", "T"),
                               current_clan = c("A", "E", "F", "L", "M", "N", "S", "T"),
                               motherID = c(NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_),
                               fatherID = c(NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_),
                               siblingID = c(NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_),
                               first_repro = c(76, 31, 48, 83, 81, NA, NA, NA),
                               last_repro = c(88, 31, 78, 166, 126, NA, NA, NA),
                               rank_std = c(1, 1, 1, 1, 1, 1, 1, 1),
                               rank = c(1, 1, 1, 1, 1, 1, 1, 1),
                               lifetime_RS = c(4L, 1L, 3L, 2L, 3L, 0L, 0L, 0L),
                               selections = list(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
                               tenure = c(5, 1, 5, 13, 8, 1, 4, 4)),
                          row.names = c(NA, -8L), class = c("tbl_df", "tbl", "data.frame"))

  #Failing sim should throw warning
  extinct_sim <- simulation$new(start_pop = doomed_pop, seed = 123)
  expect_warning({extinct_sim$run_sim(number_steps = 100)})

  #We expect output tables to still exist!
  expect_true("data.frame" %in% class(extinct_sim$Rawdata_tbl))

  #Last time-step only has 1 individuals
  df_rows <- extinct_sim$Rawdata_tbl %>%
    dplyr::filter(.data$current_date == max(.data$current_date)) %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(n = dplyr::n()) %>%
    dplyr::pull(.data$n)

  expect_equal(1L, df_rows)

})

test_that("Simulation with all clans extinct will still terminate properly...", {

  #All are >=25yo and so will die instantly
  #Should fail on second time step
  doomed_pop <- structure(list(ID = c("A-000", "E-000", "F-000", "L-000",
                                      "M-000", "N-000", "S-000", "T-000"),
                               date = structure(c(9598, 9598, 9598, 9598, 9598, 9598, 9598, 9598), class = "Date"),
                               birth_date = structure(c(6715, 8340, 6767, 3756, 5642, 8210, 7043, 7354), class = "Date"),
                               sex = c("female", "female", "female", "female", "female", "female", "female", "female"),
                               age = c(400, 400, 400, 400, 400, 400, 400, 400),
                               birth_clan = c("A", "E", "F", "L", "M", "N", "S", "T"),
                               current_clan = c("A", "E", "F", "L", "M", "N", "S", "T"),
                               motherID = c(NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_),
                               fatherID = c(NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_),
                               siblingID = c(NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_, NA_character_),
                               first_repro = c(76, 31, 48, 83, 81, NA, NA, NA),
                               last_repro = c(88, 31, 78, 166, 126, NA, NA, NA),
                               rank_std = c(1, 1, 1, 1, 1, 1, 1, 1),
                               rank = c(1, 1, 1, 1, 1, 1, 1, 1),
                               lifetime_RS = c(4L, 1L, 3L, 2L, 3L, 0L, 0L, 0L),
                               selections = list(NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
                               tenure = c(5, 1, 5, 13, 8, 1, 4, 4)),
                          row.names = c(NA, -8L), class = c("tbl_df", "tbl", "data.frame"))

  #Failing sim should throw warning
  extinct_sim <- simulation$new(start_pop = doomed_pop, seed = 123)
  expect_warning({extinct_sim$run_sim(number_steps = 100)})

  #We expect output tables to still exist!
  expect_true("data.frame" %in% class(extinct_sim$Rawdata_tbl))

  #Cannot save last time-step because all individuals died
  df_rows <- extinct_sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(n = dplyr::n()) %>%
    dplyr::pull(.data$n)

  expect_equal(c(8L), df_rows)

})

test_that("We can run a simulation object multiple times with different number_steps values...", {

  #Create basic simulation
  temp_sim <- simulation$new(number_clans = 1, start_clan_size = 5)

  #Run for 2 steps
  temp_sim$run_sim(number_steps = 2)

  #Extract min date and max date
  start_date <- min(temp_sim$Rawdata_tbl$current_date)
  mo2_date   <- max(temp_sim$Rawdata_tbl$current_date)

  #Difference should be 2 months
  expect_equal(lubridate::month(mo2_date) - lubridate::month(start_date), 2)

  #Run for another 2 months
  temp_sim$run_sim(number_steps = 2)

  #Extract new max
  mo4_date   <- max(temp_sim$Rawdata_tbl$current_date)

  #Check differences are as expected
  expect_equal(lubridate::month(mo4_date) - lubridate::month(mo2_date), 2)
  expect_equal(lubridate::month(mo4_date) - lubridate::month(start_date), 4)


})

test_that("Simulation fails when predictors are missing...", {

  ## By using keep.defaults = FALSE, we will drop all other predictors (which are needed!)
  broken_sim <- simulation$new(predictors = list(var = \(...) 10), keep.defaults = FALSE)

  ## The R6 object should have been created correctly
  expect_true(inherits(broken_sim, what = "R6"))

  ## However, it should fail when we try and run it!
  expect_error(broken_sim$run_sim(number_steps = 3))

})

test_that("Simulation initialisation with non integer years works...", {

  ## Check our example ran
  expect_true(file.exists(here::here("./test_6mo.txt")))

  ## Check that predictors function in year works as expected
  expect_identical("1997_1", sim_test_6mo$predictors$allF$year())

})

test_that("Simulation will keep defaults unless otherwise specified...", {

  test_sim <- simulation$new(predictors = list(year = \(...) 1998))

  ## Simulation should include a list of predictors for every model
  ## Predictors should include our new year value AND others
  modnames <- c("allF", "postdispM", "predispM", "twin", "disp", "primirepro", "nonprimirepro")

  expect_identical(names(test_sim$predictors), modnames)

  expect_identical(\(...) 1998,
                   test_sim$predictors$allF$year)

  expect_true(length(test_sim$predictors$allF) > 1)

})

test_that("Simulation will drop defaults if we change keep.defaults...", {

  test_sim <- simulation$new(predictors = list(year = \(...) 1998),
                             keep.defaults = FALSE)

  ## Simulation should include a list of predictors for every model
  ## Predictors should include ONLY be year value
  modnames <- c("allF", "postdispM", "predispM", "twin", "disp", "primirepro", "nonprimirepro")

  expect_identical(names(test_sim$predictors), modnames)

  expect_identical(\(...) 1998,
                   test_sim$predictors$allF$year)

  expect_true(length(test_sim$predictors$allF) == 1)

})

test_that("Users can update only a single model...", {

  ## Create an intercept only female model
  new_allF <- update(model_list$allF, .~1, data = model.frame(model_list$allF))

  ## Add this model on initialization
  ## It will work, but throw a warning because the default models are very simplistic
  expect_warning(test_sim <- simulation$new(models = list(allF = new_allF)))

  ## Simulation should include all possible models
  modnames <- c("allF", "postdispM", "predispM", "twin", "disp", "primirepro", "nonprimirepro")

  expect_true(all(names(test_sim$models) %in% modnames))

  expect_identical(new_allF,
                   test_sim$models$allF)

  expect_true(length(test_sim$models) > 1)

})
