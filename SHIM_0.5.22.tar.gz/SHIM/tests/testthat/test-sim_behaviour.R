context("Test simulation behaves as expected in different situations...")

test_that("Adult females are never ranked below disperser males...", {

  for (focal_clan in sim_test_fitrun$crater$clans){

    #Find position of all females in the clan
    fem_position <- which(sapply(focal_clan$inhabitants, \(ID) ID$sex == "female"))

    #Find position of all disperser males in the clan
    disp_position <- which(sapply(focal_clan$inhabitants, \(ID) ID$sex == "male" & ID$birth_clan != ID$clan_name))

    ## Worst ranked female should still be higher than best disperser male
    expect_true(all(max(fem_position) < min(disp_position)))

  }

})

test_that("Changing predictors affects simulation output", {

  #Simulations have different effort attribute
  expect_equal(sim_test$predictors$allF$after1y_effort_all(), 1.0)
  expect_equal(sim_test_loweffort$predictors$allF$after1y_effort_all(), 0.05)

  #Changing effort should lead to different output data (although everything else constant)
  expect_false(identical(sim_test$Rawdata_tbl$ID, sim_test_loweffort$Rawdata_tbl$ID))

})

test_that("Can run a simulation with random mating", {

  sim_test_random <- simulation$new(number_clans = 2, start_clan_size = 10,
                                    sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE, seed = 123, random_mating = TRUE)
  sim_test_random$run_sim(number_steps = 10)

  sim_test_random$Rawdata_tbl %>%
    dplyr::filter(.data$current_date == max(.data$current_date)) %>%
    dplyr::group_by(.data$clan) %>%
    dplyr::summarise(clansize = dplyr::n()) -> clansize

  #Expect clans shouldn't die
  expect_true(all(clansize$clansize > 0))

})

test_that("Can run a simulation with relatedness mating", {

  # testthat::skip(message = "skip this test because of Rcpp issues that cause crashes")

  sim_test_related <- simulation$new(number_clans = 2, start_clan_size = 10,
                                     sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE, seed = 123, relatedness = TRUE)
  sim_test_related$run_sim(number_steps = 10)

  sim_test_related$Rawdata_tbl %>%
    dplyr::filter(.data$current_date == max(.data$current_date)) %>%
    dplyr::group_by(.data$clan) %>%
    dplyr::summarise(clansize = dplyr::n()) -> clansize

  #Expect clans shouldn't die
  expect_true(all(clansize$clansize > 0))

})

test_that("Can run a simulation with random dispersal", {

  sim_test_randomdisp <- simulation$new(number_clans = 2, start_clan_size = 10,
                                        sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE, seed = 123, random_dispersal = TRUE)
  sim_test_randomdisp$run_sim(number_steps = 10)

  sim_test_randomdisp$Rawdata_tbl %>%
    dplyr::filter(.data$current_date == max(.data$current_date)) %>%
    dplyr::group_by(.data$clan) %>%
    dplyr::summarise(clansize = dplyr::n()) -> clansize

  #Expect clans shouldn't die
  expect_true(all(clansize$clansize > 0))

})

test_that("Simulations can be extended", {

  simulation_rerun(sim_test)
  simulation_rerun(sim_test_txt)

  txt_file <- read.csv(here::here("./test.txt"), sep = ",")

  ## POPULATION SIZE
  txt_popsize <- txt_file$pop_size

  summary_popsize <- sim_test_txt$Summarydata_tbl %>%
    dplyr::pull(.data$pop_size)

  full_popsize <- sim_test$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(pop_size = dplyr::n()) %>%
    dplyr::pull(.data$pop_size)

  #Test text and summary are the same
  expect_equal(txt_popsize, summary_popsize)
  #Test summary and full are the same
  expect_equal(summary_popsize, full_popsize)

})

test_that("Multiple start populations can be used", {

  skip_if(!test_parallel)

  #Extract all .txt files
  alltxt <- list.files(here::here("./test_folder_multistart"), pattern = ".txt", recursive = TRUE, full.names = TRUE)

  #There should be 8 files (2 start pops * 2 years * 2 iterations)
  expect_equal(length(alltxt), 8L)

  #Files should include multiple pop names
  expect_true(any(stringr::str_detect(pattern = "pop1", string = alltxt)))
  expect_true(any(stringr::str_detect(pattern = "pop2", string = alltxt)))

  #pop1 and pop2 should have different length
  pop1 <- read.csv(alltxt[stringr::str_detect(pattern = "pop1", string = alltxt)][1])
  pop2 <- read.csv(alltxt[stringr::str_detect(pattern = "pop2", string = alltxt)][1])

  expect_equal(c(pop1$pop_size[1], pop2$pop_size[1]), c(20, 10))

})

test_that("Summary results are stable when clan dies", {

  internal_data <- sim_test_dead$Summarydata_tbl

  external_data <- read.csv(here::here("./test_die.txt")) %>%
    dplyr::mutate(date = as.Date(.data$date)) %>%
    dplyr::as_tibble()

  expect_identical(internal_data, external_data)

})
