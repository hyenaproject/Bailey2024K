context("Test elasticity...")

test_that("Simulating elasticity has worked...", {

  skip_if(!test_elasticity)

  # Check that all the files have been created
  #Should contain one folder per focal mod
  folder_names <- list.dirs(here::here("./test_folder_elasticity"), full.names = FALSE, recursive = FALSE)
  expect_equal(folder_names, c("allF", "twin"))

  #Each focal mod folder should have a high and low
  folder_names <- list.dirs(here::here("./test_folder_elasticity/allF"), full.names = FALSE, recursive = FALSE)
  expect_equal(folder_names, c("high_5_elasticity", "low_5_elasticity"))

  #Each one of these should have 2years
  folder_names <- list.dirs(here::here("./test_folder_elasticity/allF/high_5_elasticity"), full.names = FALSE, recursive = FALSE)
  expect_equal(folder_names, c("1996", "1997"))

  #Expect 4 text files inside
  file_names <- list.files(here::here("./test_folder_elasticity/allF/high_5_elasticity/1996"), pattern = ".txt")
  expect_equal(file_names, c("simulation_pop1_1996_1.txt", "simulation_pop1_1996_2.txt",
                             "simulation_pop2_1996_1.txt", "simulation_pop2_1996_2.txt"))

  #Look at output object.
  #Here we just consider female survival mods (because effect should be most obvious)
  highmod <- sim_elasticity$allF$high$pop1_1996
  lowmod  <- sim_elasticity$allF$low$pop1_1996

  #Outputs should NOT match
  expect_error(expect_true(highmod$Rawdata_tbl, lowmod$Rawdata_tbl))

  #Low model should be declining and high model increasing
  expect_true(highmod$Summarydata_tbl$pop_size[1] < highmod$Summarydata_tbl$pop_size[3])
  expect_true(lowmod$Summarydata_tbl$pop_size[1] > lowmod$Summarydata_tbl$pop_size[3])

})
