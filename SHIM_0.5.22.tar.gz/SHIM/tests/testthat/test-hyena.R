context("Test hyena class behaviour...")

test_crater <- crater$new(number_clans = 8, start_clan_size = 20, start_pop = "sim",
                          sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test)

test_clan   <- clan$new(clan_name = "test_clan", start_clan_size = 20,
                        crater_ID = test_crater, sex_ratio = 0.5, mean_age = 72)

test_that("A hyena object can be initialised properly", {

  test_hyena  <- hyena$new(ID = "Jeff", sex = "female", age = 5, motherID = NULL,
                           fatherID = NULL, birth_clan = test_clan$clan_name, clan_ID = test_clan, sib_ID = NULL, birth_date = as.Date("1964/01/01"),
                           crater_ID = test_crater)

  #Check that an R6 hyena object was created
  expect_identical(class(test_hyena), c("hyena", "R6"))

  #Attributes match arguments
  expect_identical(test_hyena$ID, "Jeff")
  expect_identical(test_hyena$sex, "female")
  expect_identical(test_hyena$age, 5)
  expect_identical(test_hyena$birth_date, structure(-2192, class = "Date"))

  #Check that parent objects are all available
  expect_identical(test_hyena$simulation_ID, sim_test)
  expect_identical(test_hyena$crater_ID, test_crater)
  expect_identical(test_hyena$clan_ID, test_clan)

})
