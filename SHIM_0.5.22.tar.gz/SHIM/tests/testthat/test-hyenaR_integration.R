context("Test that SHIM can integrate with hyenaR...")

test_that("Output hyenaR database uses dates", {

  skip_if_not_installed("hyenaR")
  hyenaR::load_package_database.sim(sim_test)

  #Check in adults
  expect_identical(class(.database$database$data[[1]]$dateadult), "Date")
  expect_identical(class(.database$database$data[[1]]$deathdate), "Date")

  #Check in deaths
  expect_identical(class(.database$database$data[[3]]$deathdate), "Date")

  #Check in hyenas
  expect_identical(class(.database$database$data[[4]]$birthdate), "Date")

  #Check in selections
  expect_identical(class(.database$database$data[[7]]$date), "Date")

  #Check in sightings
  expect_identical(class(.database$database$data[[8]]$date_time), c("POSIXct", "POSIXt"))

})

test_that("Created database is correct", {

  skip_if_not_installed("hyenaR")
  hyenaR::load_package_database.sim(sim_test)

  #Check that the .database environment and database object exist
  expect_true(exists(".database"))
  expect_true(exists("database", envir = .database))

})
