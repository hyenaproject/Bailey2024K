context("Test crater class behaviour...")

test_that("A crater object can be initialised properly", {

  test_crater <- crater$new(number_clans = 8, start_clan_size = 20,
                            sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test)

  #Should contain 8 clans with correct clan lettering
  expect_identical(length(test_crater$clans), 8L)
  expect_true(all(test_crater$all_clan_names %in% c("A", "E", "F", "L", "M", "N", "S", "T")))

  #Check that an R6 crater object was created
  expect_identical(class(test_crater), c("crater", "R6"))

  #Check that has access to parent simulation_ID
  expect_identical(test_crater$simulation_ID, sim_test)

  #Should fail if we provide wrong number_clans value
  #More than 8 clans
  expect_error(crater$new(number_clans = 10))
  #Non numeric
  expect_error(crater$new(number_clans = "wrong"))
  #Missing
  expect_error(crater$new(start_clan_size = 20,
                          sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test))

})
