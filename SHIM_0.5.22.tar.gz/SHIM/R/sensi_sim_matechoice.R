#' Run the simulation for the different mate choice and dispersal routines
#'
#' @param nsim Number of simulations to be run for each mate_choice rule
#' @param number_steps Number of steps that each simulation will run
#' @param number_clans Number of clans created in each simulation
#' @param start_clan_size Initial size of all clans in each simulation
#' @param sex_ratio Sex ratio of all clans in each simulation
#' @param mean_age Mean age of clans at the start of each simulation
#' @param CPUcores Integer. Number of CPU cores to use for parallel processing.
#'
#' @export
#'
#' @examples
#' \dontrun{
#'out_sensi <- sensi_sim(nsim = 1, number_steps = 2,
#'number_clans = 2, start_clan_size = 10)
#'}

sensi_sim <- function(nsim = 1, number_steps = 10, number_clans = 8, start_clan_size = 20, sex_ratio = 0.5, mean_age = 72, CPUcores = parallel::detectCores() - 1){

  input_temp <- cbind(random_mating = rep(c(TRUE, FALSE, FALSE), 2), relatedness = rep(c(TRUE, TRUE, FALSE), 2) , random_dispersal = c(rep(TRUE, 3), rep(FALSE, 3))) # first row: mate choice on relatedness, second row : random choice,
  input <- input_temp[rep(1:nrow(input_temp), each = nsim), ]


    cl <- parallel::makeCluster(CPUcores)
    doSNOW <- doSNOW::registerDoSNOW(cl)

    rules <- rep(c(rep("random", nsim), rep("relatedness", nsim), rep("avoidance rules", nsim)), 2)
    dispersal <- c(rep("random", 3*nsim), rep("norandom", 3*nsim ))

    overall_output <- purrr::map_df(.x = 1:nrow(input),
                                    .f = ~{

                                      sim <-  sim_out(number_steps = number_steps,
                                                      number_clans = number_clans,
                                                      start_clan_size = start_clan_size,
                                                      sex_ratio = sex_ratio,
                                                      mean_age = mean_age,
                                                      random_mating = input[..1, 1],
                                                      relatedness = input[..1, 2],
                                                      random_dispersal = input[..1, 3])
                                      sim$mate_rule <- rules[..1]
                                      sim$dispersal <- dispersal[..1]
                                      sim$iter      <- nsim - (..1 %% nsim)
                                      sim

                                    })

  parallel::stopCluster(cl)
  return(overall_output)

}

#' Run hyena simulation with defined parameter estimates for infusion.
#'
#' @param number_steps Number of steps for simulation to be run (length of time step is specified in step_size)
#' @param step_size Size of each time step (months)
#' @param number_clans Number of clans generated in the simulation
#' @param start_clan_size Starting size of all clans
#' @param sex_ratio Starting sex ratio of all clans
#' @param mean_age Mean age of individuals in all clans
#' @param random_mating boolean is mating random? if false the mating is either based of basic rules for inbreeding avoidance or on genetic relatedness
#' @param relatedness boolean is mating based on genetic relatedness?
#' @param random_dispersal boolean is dispersal random
#'
#' @export
#' @examples
#'sim_out(number_steps = 2, number_clans = 5, start_clan_size = 10,
#'sex_ratio = 0.5, mean_age = 72, random_mating = TRUE, relatedness = FALSE,
#'random_dispersal = TRUE)
sim_out <- function(number_steps, step_size = 6, number_clans, start_clan_size, sex_ratio, mean_age, random_mating, relatedness, random_dispersal) {

  #Create simulation object with parameters provided
  sim <- simulation$new(number_clans = number_clans, start_clan_size = start_clan_size, sex_ratio = sex_ratio, mean_age = mean_age,
                        random_mating = random_mating, relatedness = relatedness, random_dispersal = random_dispersal)


  #Run the simulation with these new variables
  sim$run_sim(number_steps = number_steps)

  year <- sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarize(year = unique(lubridate::year(.data$current_date)))

  #Calculate LRS for females
  sim_LRS_F <- sim$Rawdata_tbl %>%
    dplyr::filter(!is.na(.data$mother)) %>%
    dplyr::group_by(.data$mother) %>%
    dplyr::summarise(LRS = length(unique(.data$ID)))

  #Calculate LRS for males
  sim_LRS_M <- sim$Rawdata_tbl %>%
    dplyr::filter(!is.na(.data$father)) %>%
    dplyr::group_by(.data$father) %>%
    dplyr::summarise(LRS = length(unique(.data$ID)))


  #Sex ratio of adults (>2yo)
  sex_ratio_all <- sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(Number_cubs    = length(which(.data$age < 2)),
                     Number_females = length(which(.data$age >= 2 & .data$sex == "female")),
                     Number_males   = length(which(.data$age >= 2 & .data$sex == "male"))) %>%
    dplyr::mutate(sex_ratio = .data$Number_females/.data$Number_males)


  #Average 6 month clan sizes
  clan_size <- sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date, .data$clan) %>%
    dplyr::summarise(clan_size = dplyr::n()) %>%
    dplyr::summarise(mean_size_time = mean(.data$clan_size),
              max_size_time  = max(.data$clan_size),
              min_size_time  = min(.data$clan_size),
              clan_nb = length(unique(.data$clan)))

  #Population size
  pop_size <- sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(pop_size = dplyr::n())


  # #Male dispersal info
  # no_clans <- sim$Rawdata_tbl %>%
  #   filter(sex == "male") %>%
  #   group_by(ID) %>%
  #   summarise(no_clans = sum(diff(as.numeric(clan)) != 0))

  #Genetic_data contain diversity_coef and mean_genetic_relatedness
  genetic<- base::as.data.frame(sim$crater$genetic_data)


 #Mean relatedness between each females and unchosen males and with the chosen male
 relatedness_pattern <- sim$Rawdata_tbl %>%
     tidyr::unnest_wider(.data$relatedness_unchosen_chosen) %>%
     dplyr::group_by(.data$current_date) %>%
     dplyr::summarise(
       relat_unchosen_mean = base::mean(.data$unchosen, na.rm = TRUE),
       relat_chosen_mean = base::mean(.data$chosen, na.rm = TRUE)
     )
  #Output our important summary stats
  data.frame(
    year            = year$year,
    mean_fem_LRS  = base::mean(sim_LRS_F$LRS),
    sd_fem_LRS      = stats::sd(sim_LRS_F$LRS),
    # skew_fem_LRS    = e1071::skewness(sim_LRS_F$LRS),
    # max_fem_LRS     = max(sim_LRS_F$LRS),
    mean_male_LRS  = base::mean(sim_LRS_M$LRS),
    sd_male_LRS      = stats::sd(sim_LRS_M$LRS),
    # skew_male_LRS    = e1071::skewness(sim_LRS_M$LRS),
    ASR              = sex_ratio_all$sex_ratio,
    # sd_sex_ratio    = stats::sd(sex_ratio_all$sex_ratio),
    # skew_sex_ratio  = e1071::skewness(sex_ratio_all$sex_ratio),
    #mean_no_disp    = mean(no_clans$no_clans),
    #sd_no_disp      = stats::sd(no_clans$no_clans),
    #skew_no_disp    = e1071::skewness(no_clans$no_clans),
    #max_no_disp     = max(no_clans$no_clans),
    clan_nb         = clan_size$clan_nb,
    mean_clan_size  = clan_size$mean_size_time,
    max_clan_size   = clan_size$max_size_time,
    min_clan_size   = clan_size$min_size_time,
    pop_size        = pop_size$pop_size,
    genetic_div     = genetic$diversity_coef,
    average_simi    = genetic$genetic_relatedness,
    relat_unchosen  = relatedness_pattern$relat_unchosen_mean,
    relat_chosen  =  relatedness_pattern$relat_chosen_mean
  )


}

