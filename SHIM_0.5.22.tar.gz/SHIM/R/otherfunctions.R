#' Return predicted outcome from binomial models with different model classes
#'
#' @param object Model object. Can be of class 'gam', 'glm', 'glmerMod', and "HLfit,
#' @param objectname Character string. Name of model. Used to provide more informative error messages.
#' @param newdata New data to generate predicted outcome
#' @param nsim Number of time steps over which to predict
#' @param include_ranef Logical. Should simulations be conditioned on random effects terms? When `FALSE` if the model was fitted with spaMM, marginal predictions are attempted.
#' @param ... Additional arguments passed to simulation/prediction functions
#'
#' @return A vector of binary response (1 = success, 0 = failure), representing success or failure in each sim.
#' Length of vector specified by nsim.
#' @export
#'
#' @examples
#' n <- 5000
#' input_data <- data.frame(size = runif(n, min = 1, max = 100),
#'                          ID = LETTERS[runif(n, min = 1, 6)])
#' input_data$outcome <- rbinom(n, size = 1, prob = input_data$size/100)
#' mixed_mod       <- spaMM::fitme(outcome ~ size + (1|ID), data = input_data, family = "binomial")
#' mixed_mod_gauss <- spaMM::fitme(outcome ~ size + (1|ID), data = input_data)
#' nonmixed_mod    <- spaMM::fitme(outcome ~ size, data = input_data, family = "binomial")
#'
#' #Simulate 10 values for 2 sizes using conditional simulations
#' set.seed(1)
#' simulate_model(mixed_mod, newdata = data.frame(size = c(2, 60), ID = "A"), nsim = 10,
#'                include_ranef = TRUE)
#' simulate_model(mixed_mod_gauss, newdata = data.frame(size = c(2, 60), ID = "A"), nsim = 10,
#'                include_ranef = TRUE)
#' simulate_model(nonmixed_mod, newdata = data.frame(size = c(2, 60), ID = "A"), nsim = 10,
#'                include_ranef = TRUE)
#'
#' #Simulate 10 values for 2 sizes using marginal simulations
#' set.seed(1)
#' simulate_model(mixed_mod, newdata = data.frame(size = c(2, 60)), nsim = 10,
#'                include_ranef = FALSE)
#' simulate_model(mixed_mod_gauss, newdata = data.frame(size = c(2, 60)), nsim = 10,
#'                include_ranef = FALSE)
#' simulate_model(nonmixed_mod, newdata = data.frame(size = c(2, 60), ID = "A"), nsim = 10,
#'                include_ranef = FALSE)
#'
simulate_model <- function(object, objectname = "", newdata, nsim, include_ranef, ...){

  model_class <- class(object)

  if ("gam" %in% model_class) {

    if (requireNamespace("gratia", quietly = TRUE)) {

      # tryCatch. If there is a missing variable give more useful error message
      sims <- tryCatch(stats::simulate(object,
                                       #Bug still exists, need to include >1 row of newdata
                                       data = newdata,
                                       nsim = nsim, ...),
                       error = function(e){

                         if (stringr::str_detect(e$message, pattern = "object '[a-zA-z]*' not found")) {
                           stop(paste("\n", objectname, "model has missing predictors. Use the argument 'predictors' to define how each variable in the model should be extracted.\n\n", e$message))
                         } else {
                           stop(paste("Model prediction failed with message\n", e$message))
                         }
                       })

    } else {

      stop("Package 'gratia' is required to use gam models.")

    }

  } else if (any(c("lmerMod", "glmerMod") %in% model_class)) {

    if (include_ranef) {

      # tryCatch. If there is a missing variable give more useful error message
      sims <- tryCatch(stats::simulate(object,
                                       newdata = newdata,
                                       nsim = nsim,
                                       re.form = NULL,
                                       ...),
                       error = function(e){

                         if (stringr::str_detect(e$message, pattern = "object '[a-zA-z]*' not found")) {
                           stop(paste("\n", objectname, "model has missing predictors. Use the argument 'predictors' to define how each variable in the model should be extracted.\n\n", e$message))
                         } else {
                           stop(paste("Model prediction failed with message\n", e$message))
                         }
                       })
    } else {
      # tryCatch. If there is a missing variable give more useful error message
      sims <- tryCatch(stats::simulate(object,
                                       newdata = newdata,
                                       nsim = nsim,
                                       re.form = NA,
                                       ...),
                       error = function(e){

                         if (stringr::str_detect(e$message, pattern = "object '[a-zA-z]*' not found")) {
                           stop(paste("\n", objectname, "model has missing predictors. Use the argument 'predictors' to define how each variable in the model should be extracted.\n\n", e$message))
                         } else {
                           stop(paste("Model prediction failed with message\n", e$message))
                         }
                       })
    }

  } else if ("HLfit" %in% model_class) {

    spaMM_error <- function(e) {if (stringr::str_detect(e$message, pattern = "undefined columns selected")) {
                                                 stop(paste("\n", objectname, "model has missing predictors. Use the argument 'predictors' to define how each variable in the model should be extracted.\n\n", e$message))
                                               } else {
                                                 stop(paste("Model prediction failed with message\n", e$message))
                                               }
                               }

    ## FIXME: Inside spaMM:::.get_locdata uses try without a catch or silent.
    ## This causes errors to print to global without anyway to hide them
    ## code doesn't fail, so it's just annoying more than anything
    if (include_ranef) {

      # tryCatch. If there is a missing variable give more useful error message
      utils::capture.output(sims <- tryCatch(stats::simulate(object,
                                                             newdata = newdata,
                                                             nsim = nsim,
                                                             re.form = NULL,
                                                             sizes = 1, ## note: cannot handle non-binary binomial
                                                             ...),
                                             error = spaMM_error))
    } else {

      if (length(object$lambda) == 0) {
        ## no random effect, so simple simulations
        # tryCatch. If there is a missing variable give more useful error message
        utils::capture.output(sims <- tryCatch(stats::simulate(object,
                                                               newdata = newdata,
                                                               nsim = nsim,
                                                               sizes = 1, ## note: cannot handle non-binary binomial
                                                               ...),
                                           error = spaMM_error))
      } else {
        ## random effect, so marginal predictions
        # tryCatch. If there is a missing variable give more useful error message
        utils::capture.output(pred_noRanef <- tryCatch(stats::predict(object,
                                                                      newdata = newdata,
                                                                      re.form = NA,
                                                                      sizes = 1, ## note: cannot handle non-binary binomial
                                                                      type = "link",
                                                                      ...),
                                               error = spaMM_error))

        if (length(object$lambda) != 1) stop("Marginal predictions only possible for a single random factor")
        pred <- matrix(nrow = nrow(newdata), ncol = nsim)
        binomial <- stats::family(object)$family == "binomial"


        ## extract the inverse link function
        linkinv <- ifelse(is.null(object$family$zero_truncated) || object$family$zero_truncated == FALSE,
                      function(eta) object$family$linkinv(eta),
                      function(eta) object$family$linkinv(eta, mu_truncated = TRUE)) ## for Tnegbin and Tpoisson

        ## integrate over the distribution of the random factor
        for (i in seq_len(nrow(newdata))) {
         fn <- function(x) linkinv(pred_noRanef[i] + stats::qnorm(x, sd = sqrt(object$lambda[[1]])))
         pred[i, ] <- stats::integrate(fn, lower = 0, upper = 1)$value
        }

        ## turn the predictions into simulations
        if (binomial) {
          sims <- matrix(stats::rbinom(length(pred), size = 1, prob = pred), nrow = nrow(newdata), ncol = nsim) ## note: cannot handle non-binary binomial
        } else {
          if (length(object$phi) > 1) stop("Marginal predictions only possible for a single residual variance term.")
          sims <- matrix(stats::rnorm(length(pred), mean = pred, sd = sqrt(object$phi[[1]])), nrow = nrow(newdata), ncol = nsim)
        }

      }
    }

    #For spaMM, output is a nsim x nrow(newdata) matrix ONLY WHEN nsim > 1
    #When nsim = 1, output is a vector
    if (nsim == 1) {

      sims <- matrix(sims, ncol = nsim, nrow = nrow(newdata))

    }

  } else if (any(c("glm", "lm") %in% model_class)) {

    #lm/glm cannot accept new data when using simulate()
    #Need to use predict and simulate outcomes ourselves
    ## TODO: We are expecting that models will output a probability that we can use to simulate
    ## Do we want a test to make sure this is the case?

    # tryCatch. If there is a missing variable give more useful error message
    pred_prob <- tryCatch(stats::predict(object,
                                         newdata = newdata,
                                         type = "response", ...),
                          error = function(e){

                            if (stringr::str_detect(e$message, pattern = "object '[a-zA-z]*' not found")) {
                              stop(paste("\n", objectname, "model has missing predictors. Use the argument 'predictors' to define how each variable in the model should be extracted.\n\n", e$message))
                            } else {
                              stop(paste("Model prediction failed with message\n", e$message))
                            }
                          })

    ## For glmer we can only generate the predicted probability
    ## We need to run the simulation ourselves by generating outcomes from a uniform distribution (0-1)
    sim_outcomes <- matrix(stats::runif(n = nsim*length(pred_prob)),
                           ## Each row is an individual and each column is a simulated outcome
                           ncol = nsim, nrow = nrow(newdata))

    ## Convert outcomes to logical
    sims <- t(mapply(\(row, prob) as.numeric(sim_outcomes[row, ] <= prob), seq_len(nrow(newdata)), pred_prob))

  }

  sims

}

#' Save a snapshot of the simulation at a given time step
#'
#' @param object R6 object. May be of class simulation or crater (both are used in different circumstances)
#' @param first_step Logical. Is this the first time step. If TRUE, generate the files where data will be saved.
#' @param final_step Logical. Is this the final time step. At this point, generate the .database object
#' that can be used by the `hyenaR` package.
#'@param save_size Numeric. The number of time-steps to save.
#'Default (Inf) will save all time steps, but be warned, this can be
#'very memory intensive for a long simulation! Reduce this value to limit the memory
#'load from the simulation.
#' @param save_file File path. The path for the .txt file that will be created with summary data (i.e. pop/clan size).
#' If NULL, data will still be saved as temp file and can be accessed for trouble-shooting.
#'
#' @return Save simulation information as a data frame in attribute `Rawdata_tbl`. May also generate
#' a separate .txt file.
#' @export
save_timestep <- function(object, first_step, final_step,
                          save_size = Inf, save_file = NULL){

  #Saving time step can happen as part of a crater method (i.e. pass time)
  #It also occurs once as part of a simulation method (i.e. to save final time step after last pass time)
  #Therefore, we need functionality to deal with both
  if (inherits(object, what = "simulation")) {

    simulation <- object
    crater     <- object$crater

  } else {

    stop("Object should be R6 object of class simulation")

  }

  if (!is.numeric(save_size)) {

    stop("Argument `save_size` must be an integer.")

  }

  #After we have run a time step, save all the current information about all individuals in the crater
  #This shows us the state of the population at this point in time
  crater$snapshot_data[[length(crater$snapshot_data) + 1]] <- do.call(rbind, lapply(crater$clans, function(x){
    tibble::tibble(current_date = simulation$date,
                   ID = sapply(x$inhabitants, \(ID) ID$ID),
                   sex = sapply(x$inhabitants, \(ID) ID$sex),
                   age = sapply(x$inhabitants, \(ID) ID$age),
                   birth_date = as.Date(sapply(x$inhabitants, \(ID) as.character(ID$birth_date))),
                   birth_clan = sapply(x$inhabitants, \(ID) as.character(ID$birth_clan)),
                   clan = sapply(x$inhabitants, \(ID) ID$clan_name),
                   mother = sapply(x$inhabitants, \(ID) if (is.null(ID$motherID)) NA_character_ else ID$motherID$ID),
                   father = sapply(x$inhabitants, \(ID) if (is.null(ID$fatherID)) NA_character_ else ID$fatherID$ID),
                   stand_rank = sapply(x$inhabitants, \(ID) if (is.null(ID$stand_rank)) NA_real_ else ID$stand_rank),
                   ord_rank = sapply(x$inhabitants, \(ID) if (is.null(ID$ord_rank)) NA_real_ else ID$ord_rank),
                   RS = sapply(x$inhabitants, \(ID) ID$lifetime_RS),
                   prey = x$prey,
                   dna = lapply(x$inhabitants, \(ID) ID$genome$dna),
                   relatedness_unchosen_chosen = lapply(x$inhabitants, \(ID) ID$relat_unchosen_chosen))
  }))

  #Check to see how many time-steps have been saved. If it is >trunc_size, filter out the earliest time-step
  #This is easy because it's just a list! Make list item 1 = NULL
  if (length(crater$snapshot_data) > save_size) {

    crater$snapshot_data[[1]] <- NULL

  }

  ##BECAUSE 'full' OUTPUT MAY NOW BE TRUNCATED. WE ALSO WANT TO HAVE THE OPTION TO SAVE BASIC SUMMARY IN .TXT FILE
  #If there's already an associated text file, use this as the save file
  if ("txt_file" %in% names(simulation$save_files)) {

    save_file <- simulation$save_files$txt_file

    #If there is no associated txt_file yet, use argument save_file
    #If this is missing, then use a temp file
    #We may still want to access the info for troubleshooting even if it's not permanent
  } else {

    if (is.null(save_file)) {

      save_file <- tempfile(pattern = "summarydata_", fileext = ".txt")

    }

    #Save in output file
    file.create(save_file)
    simulation$save_files <- c(simulation$save_files, txt_file = save_file)

  }

  #Create col names
  variables <- c("cubfem", "adultfem", "cubmale", "philomale", "dispmale",
                 "cubfem_dead", "adultfem_dead", "cubmale_dead", "philomale_dead", "dispmale_dead",
                 "mothers", "fathers")

  variable_by_clan <- expand.grid(clan = crater$all_clan_names,
                                  variable = variables)

  variable_cols <- paste(variable_by_clan$clan,
                         variable_by_clan$variable, sep = "_")

  all_cols <- c("date", "pop_size", variable_cols)

  #If it's the first time step, append the col names of the file
  if (first_step) {

    write(paste(all_cols, collapse = ","), file = save_file, append = TRUE)

    #Also save in Summarydata_tbl
    simulation$Summarydata_tbl <- dplyr::tibble(date = as.Date(NULL), pop_size = as.integer(NULL)) %>%
      dplyr::bind_cols(purrr::map_dfc(.x = variable_cols,
                                      .f = function(colname){

                                        dplyr::tibble("{colname}" := as.integer(NULL))

                                      }))

  }

  #Create template for saving (this is similar to what we save in Rawdata_tbl but use date as character for simplicity)
  template <- dplyr::tibble(date = as.character(NULL), pop_size = as.integer(NULL)) %>%
    dplyr::bind_cols(purrr::map_dfc(.x = variable_cols,
                                    .f = function(colname){

                                      dplyr::tibble("{colname}" := as.integer(NULL))

                                    }))

  #Return sum of all clans at each time step
  pop_size <- purrr::map_int(.x = crater$clans,
                             .f = ~{

                               length(..1$inhabitants)

                             }) %>%
    sum()

  alive_data <- purrr::map_dfc(.x = crater$clans,
                               .f = function(clan_obj){

                                 clanname <- clan_obj$clan_name

                                 dplyr::tibble("{clanname}_cubfem" := clan_obj$fetch_clan_number.R6(sex = "female", lifestage = "cub"),
                                               "{clanname}_adultfem" := clan_obj$fetch_clan_number.R6(sex = "female", lifestage = "adult"),
                                               "{clanname}_cubmale" := clan_obj$fetch_clan_number.R6(sex = "male", lifestage = "cub"),
                                               "{clanname}_philomale" := clan_obj$fetch_clan_number.R6(sex = "male", lifestage = "philopatric"),
                                               "{clanname}_dispmale" := clan_obj$fetch_clan_number.R6(sex = "male", lifestage = "disperser"),
                                               "{clanname}_mothers" := clan_obj$fetch_clan_number.parent.R6(sex = "female"),
                                               "{clanname}_fathers" := clan_obj$fetch_clan_number.parent.R6(sex = "male"))

                               })

  dead_data <- purrr::map_dfc(crater$clans,
                              .f = function(clan_obj){

                                clanname <- clan_obj$clan_name

                                clan_obj$deaths %>%
                                  dplyr::rename_with(.fn = ~paste(clanname, .x, sep = "_"))


                              })

  #Use date as character to start (so we can easily collapse for save)
  all_data <- dplyr::tibble(date = as.character(simulation$date),
                            pop_size = pop_size) %>%
    dplyr::bind_cols(alive_data) %>%
    dplyr::bind_cols(dead_data)

  ordered_data <- template %>%
    dplyr::bind_rows(all_data)

  new_line <- paste(ordered_data, collapse = ",")
  write(new_line, file = save_file, append = TRUE)

  #Convert date to Date class for binding
  ordered_data <- ordered_data %>%
    dplyr::mutate(date = as.Date(.data$date))

  #Also save as object in simulation so we can recreate if needed
  simulation$Summarydata_tbl <- simulation$Summarydata_tbl %>%
    dplyr::bind_rows(ordered_data)

  if (final_step) {

    #save all informations in tables: Rawdata_tbl, Adult_tb, Death_tb etc..
    write_output(simulation)

  }

}
