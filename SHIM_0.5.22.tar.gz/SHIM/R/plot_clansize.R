#' Create a ggplot of clan size over time
#'
#' @param sim Object of class \code{\link{simulation}}. Must be following the method run_sim().
#' @param type Should population size be plotted as a line graph ("line") or area graph ("area").
#'
#' @return Produces a ggplot showing changes in clan sizes over time.
#' @export
#' @examples
#'
#' #Plot full output
#' sim_test <- simulation$new(step_size = 6, number_clans = 4,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72, seed = 123)
#'
#' sim_test$run_sim(number_steps = 2)
#'
#' plot_clansize(sim_test, type = "line")

plot_clansize <- function(sim, type = "line"){

  clan_names <- sim$crater$all_clan_names

  if ("pop_size" %in% colnames(sim$Rawdata_tbl)) {

    sim_data <- sim$Rawdata_tbl %>%
      tidyr::pivot_longer(cols = c(-"date", -"pop_size")) %>%
      dplyr::filter(!stringr::str_detect(.data$name, "dead|mother|father")) %>%
      tidyr::separate(.data$name, into = c("clan", "group")) %>%
      dplyr::group_by(.data$date, .data$clan) %>%
      dplyr::summarise(total = sum(.data$value), .groups = "drop")

  } else {

    sim_data <- sim$Rawdata_tbl %>%
      dplyr::mutate(date = .data$current_date) %>%
      dplyr::group_by(.data$clan, .data$date) %>%
      dplyr::summarise(total = dplyr::n()) %>%
      dplyr::mutate(year = lubridate::year(.data$date))

  }

  foundation <- ggplot2::ggplot(sim_data) +
    ggplot2::theme_classic()

  if (type == "line") {

    foundation +
      ggplot2::geom_line(ggplot2::aes(x = .data$date, y = .data$total, colour = .data$clan), size = 1, lty = 2) +
      ggplot2::geom_point(ggplot2::aes(x = .data$date, y = .data$total, fill = .data$clan), size = 3, shape = 21)


  } else {

    foundation +
      ggplot2::geom_area(ggplot2::aes(x = .data$date, y = .data$total, fill = .data$clan), size = 1, colour = "black")

  }
}


#' Plot clan size of multiple simulations.
#'
#' Create a single plot for each clan from multiple simulations.
#' Takes saved simulation objects as an input.
#'
#' @param sim_files Character vector. File path of all save simulations.
#'
#' @return ggplot showing changes in clan sizes over time.
#' @export
#'
#' @examples
#' \dontrun{
#'
#' simulation_iterate(i = 25, number_steps = 5, number_clans = 8, CPUcores = 4,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72, save_dir = ".")
#'
#' sim_files <- list.files(path = ".", pattern = ".txt")
#'
#' plot_clansize.all(sim_files = sim_files)
#'
#' }
plot_clansize.all <- function(sim_files) {

  if (!inherits(sim_files, what = "character")) {

    stop("Requires a vector of files paths.")

  }

  if (!all(stringr::str_detect(sim_files, pattern = ".txt") | all(stringr::str_detect(sim_files, pattern = ".RDS")))) {

    stop("Plotting function expects txt or RDS files.")

  }

  plot_data <- purrr::imap_dfr(.x = sim_files,
                               .f = function(path, index){

                                 if (stringr::str_detect(path, pattern = ".txt")) {

                                   output <- utils::read.csv(path, sep = ",") %>%
                                     tidyr::pivot_longer(cols = c(-"date", -"pop_size")) %>%
                                     dplyr::filter(!stringr::str_detect(.data$name, "dead|mother|father")) %>%
                                     tidyr::separate(.data$name, into = c("clan", "group")) %>%
                                     dplyr::group_by(.data$date, .data$clan) %>%
                                     dplyr::summarise(total = sum(.data$value), .groups = "drop") %>%
                                     dplyr::mutate(date = as.Date(.data$date),
                                                   sim_number = as.character(index))

                                 } else if (stringr::str_detect(sim_files, pattern = ".RDS")) {

                                   sim <- readRDS(path)

                                   output <- sim$Rawdata_tbl %>%
                                     tidyr::pivot_longer(cols = c(-"date", -"pop_size")) %>%
                                     dplyr::filter(!stringr::str_detect(.data$name, "dead|mother|father")) %>%
                                     tidyr::separate(.data$name, into = c("clan", "group")) %>%
                                     dplyr::group_by(.data$date, .data$clan) %>%
                                     dplyr::summarise(total = sum(.data$value), .groups = "drop") %>%
                                     dplyr::mutate(date = as.Date(.data$date),
                                                   sim_number = as.character(index))

                                 }

                               })

  ggplot2::ggplot(plot_data) +
    ggplot2::geom_line(ggplot2::aes(x = .data$date, y = .data$total,
                                    colour = .data$sim_number),
                       size = 1, lty = 2) +
    ggplot2::theme_classic() +
    ggplot2::scale_y_continuous(limits = c(0, NA)) +
    ggplot2::facet_wrap(facets = ~.data$clan) +
    ggplot2::theme(legend.position = "none")

}
