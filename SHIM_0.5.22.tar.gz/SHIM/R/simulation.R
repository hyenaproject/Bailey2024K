#' R6 class to simulate spotted hyena population in Ngorongoro Crater, Tanzania.
#'
#' `simulation` is an [`R6 class`][`R6::R6Class`] which we used to simulate the spotted hyena
#' in Ngorongoro Crater, Tanzania. The class contains methods (i.e. functions)
#' to run the simulation and to be applied to the R6 object after it has been created.
#'
#' We recommend you to look at the raw R code and comments of this class definition on GitHub (file
#' '/R/simulation.R') to understand how the simulation works.
#' While you could directly look at the code of this class definition while using the package, mind
#' that the comments will have been stripped away during the installation process.
#'
#' What is R6? R6 is an R package that provides a system to define objects in R. Perhaps you have
#' already heard of some of the native systems for creating objects in R. Those are
#' [`S3`][`UseMethod`] (which is by far the dominant way of handling objects in R),
#' [`S4`][`Classes_Details`] (which is heavily used by some specific packages like Matrix and all
#' packages from Bioconductor) and [`ReferenceClasses`] (which is little used).
#'
#' R6 is a system tailored to define classes and methods following a traditional Object Oriented
#' Programming (OOP; as found in C++ & Java), while keeping with a very simple R syntax.
#'
#' @name simulation
#' @author Liam D. Bailey
#' @export
#' @examples
#'
#' #Fast simulation for example
#'
#' sim_test_fast <- simulation$new(number_clans = 5,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE)
#'
#' sim_test_fast$run_sim(number_steps = 2)
#'
#' \dontrun{
#'
#' #Larger realistic example.
#' #290 seconds on i7-7567U 3.5GHz
#' sim_test <- simulation$new(number_clans = 8,
#' start_clan_size = 20, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE)
#'
#' sim_test$run_sim(number_steps = 50)
#'
#' }

simulation <- R6::R6Class(classname = "simulation",
                          public = list(

                            # Slots for the class attributes #######################################################

                            #'@field step_size Integer. The size of individual time steps (in months).
                            step_size = NULL,

                            #'@field seed Integer. Seed of the current simulation.
                            seed = NULL,

                            #'@field version package_version object. The version of SHIM used to generate the simulation.
                            version = NULL,

                            #'@field start_pop Data frame. Individuals used to initialise the simulation (optional).
                            #'If not provided, individuals will be procedurally generated from
                            #'known demographic characteristics of the Ngorongoro Crater population (e.g. sex ratio, mean age).
                            start_pop = NULL,

                            #'@field date Date (YYYY-MM-DD). The current date within the simulation.
                            date = NULL,

                            #'@field include_ranef Logical. Should simulations condition on model random effects?
                            include_ranef = TRUE,

                            #'@field save_size Numeric. The number of time-steps to save.
                            #'Default (Inf) will save all time steps, but be warned, this can be
                            #'very memory intensive for a long simulation! Reduce this value to limit the memory
                            #'load from the simulation.
                            save_size = Inf,

                            #'@field models Named list of statistical models. If NULL, a set of simple demographic models
                            #'fitted on a subset of real data are used.
                            #'**These default models are not intended for analysis only for demonstration.**
                            #'
                            #'If providing a named list, should be a list of model objects.
                            #'Currently, these can be of model class `gam`, `HLfit`, `glm/lm/glm.nb`, or `glmer/lmer`.
                            #'List should contain named items:
                            #'\itemize{
                            #'    \item {'allF', model for all female survival.}
                            #'    \item {'predispM', model for pre-dispersal male survival.}
                            #'    \item {'postdispM', model for post-dispersal male survival.}
                            #'    \item {'twin', model for twin litter probability.}
                            #'    \item {'disp', model for male secondary clan selection.}
                            #'    \item {'primirepro', model for primiparous female reproduction event.}
                            #'    \item {'nonprimirepro', model for non-primiparous female reproduction event.}
                            #'}
                            #'
                            #'See ?models for more details on fitting models.
                            models = NULL,

                            #'@field predictors Named list of commands to extract model predictors from [`hyena`] objects.
                            #'Names of list should be the same as those used for models above.
                            #'
                            #'By default, will consider only those predictors available in default models.
                            #'
                            #'See ?predictors for more details and examples of defining predictors.
                            predictors = NULL,

                            #'@field calc_SS Logical. Should rank be estimated using social support measure from Vullioud et al. 2018
                            #'(https://doi.org/10.1038/s41559-018-0718-9). Default FALSE.
                            #'*Note* This will be substantially slower.
                            calc_SS = FALSE,

                            #'@field hyena_max_age Integer. The maximum age (months) that an individual can be
                            #'expected to live. Default 300 months (i.e. 25yo)
                            hyena_max_age = 300L,

                            #'@field female_first_repro Integer. The minimum age (months) at which a female can possibly reproduce.
                            #'When age is >= this value, reproduction will occur with a probability determined by
                            #'female primiparous reproduction model. Default 24 months (i.e. 2 years)
                            female_first_repro = 24L,

                            #'@field sex_ratio Probability (0-1). Probability for a new cub to be female.
                            #'Default 0.5 (equal sex ratio in cubs).
                            sex_ratio = 0.5,

                            #'@field loci_number Integer. Number of loci in the simulated genome.
                            #'Default 10.
                            loci_number = 10L,

                            #'@field allelic_diversity Proportion (0-1). Initial frequency of allele 1.
                            #'Default 0.5 (equal diversity).
                            allelic_diversity = 0.5,

                            #'@field mutation_rate Probability (0-1).
                            #'Probability of allele to mutate (0 would become 1 and 1 would become 0).
                            #'Default 10e-6
                            mutation_rate = 10e-6,

                            #'@field random_mating Logical. Should female mate choice be random?
                            #'If TRUE, female mate choice is random (all males have equal chance to be selected).
                            #'If FALSE (default), females apply a mate choice rule to avoid inbreeding (see `relatedness` below).
                            random_mating = FALSE,

                            #'@field relatedness Logical. If random_mating is FALSE, is mate choice dependent on relatedness coefficient?
                            #'If FALSE (default), females use the reported female mate choice rule to avoid inbreeding
                            #'(Hoener et al. 2007; https://doi.org/10.1038/nature06040)
                            #'If TRUE, only those males below the average relatedness of the clan are chosen.
                            relatedness = FALSE,

                            #'@field random_dispersal Logical. Do males choose new clans randomly?
                            #'If FALSE (default), males prefer clans with a higher proportion of young females
                            #'(Hoener et al. 2007; https://doi.org/10.1038/nature06040)
                            #'If TRUE, all clans (including natal) have an equal chance to be chosen.
                            random_dispersal = FALSE,

                            #'@field Rawdata_tbl Data frame. Information on every simulated individual at every time step.
                            #'This is the full simulation data and will be available even if the simulation crashes.
                            Rawdata_tbl = NULL,

                            #'@field Summarydata_tbl Data frame. Pop and clan summaries (e.g. nr males, nr females)
                            Summarydata_tbl = NULL,

                            #'@field Adults_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "adults"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Adults_tbl = NULL,

                            #'@field Deaths_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "deaths"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Deaths_tbl = NULL,

                            #'@field Hyenas_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "hyenas"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Hyenas_tbl = NULL,

                            #'@field Clans_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "clans"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Clans_tbl = NULL,

                            #'@field Selections_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "selections"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Selections_tbl = NULL,

                            #'@field Sightings_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "sightings"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Sightings_tbl = NULL,

                            #'@field Snapshots_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "snapshots"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Snapshots_tbl = NULL,

                            #'@field Rankchanges_tbl Data frame. Data generated from `Rawdata_tbl`
                            #'and stored in the same format as the table "rankchanges"
                            #'in the Ngorongoro Crater database. Generated by [write_output()] at the end of a successful simulation.
                            Rankchanges_tbl = NULL,

                            #'@field crater R6 object. The crater R6 object used for simulation. See [crater()] for more details.
                            crater = NULL,

                            #'@field save_files List. List of local save files associated with simulation
                            #'Can include more than one file when a .txt and .RDS file are saved
                            save_files = list(),

                            # Slots for the methods stored in the class ####################################################

                            #' @description
                            #' Create a new simulation object to simulate the spotted hyena population in Ngorongoro Crater
                            #'
                            #' This functions is used to create the object and all child objects (crater, clan, hyena).
                            #'
                            #' @param step_size Integer. The size of individual time steps (in months).
                            #' @param start_pop Data frame. Individuals used to initialise the simulation.
                            #' By default, uses snapshot of Ngorongoro Crater at 1996-04-12.
                            #' Can generate new snapshots from Ngorongoro Crater a different date using [get_data.start()].
                            #' If NULL, individuals used to initialise the simulation will be procedurally generated from
                            #' known demographic characteristics of the Ngorongoro Crater population (e.g. sex ratio, mean age).
                            #' @param start_date Date (YYYY-MM-DD). The date at which the simulation will begin.
                            #' @param include_ranef Logical. Should simulations condition on model random effects?
                            #' If TRUE, level of random effect year will be determined by `year` argument.
                            #' If FALSE, simulations will condition on *no* random effects.
                            #' @param number_clans Integer. If `start_pop` is NULL, the number of clans to be generated.
                            #' Default 8.
                            #' @param start_clan_size Integer. Number of individuals in each generated clan.
                            #' Default 22 (mean clan size at start of dataset).
                            #' @param sex_ratio Numeric. Probability (0-1); default 0.5. Probability for a new cub to be female.
                            #' @param mean_age Numeric. Mean age of individuals, used as \eqn{\lambda} to generate age of individuals
                            #' from a Poisson distribution.
                            #' Default 50 (mean age at start of dataset).
                            #' @param hyena_max_age Integer. The maximum age (months) that an individual can be
                            #'expected to live. Default 300 months (i.e. 25yo).
                            #' @param female_first_repro Integer. The minimum age (months) at which a female can possibly reproduce.
                            #'When age is >= this value, reproduction will occur with a probability determined by
                            #'female primiparous reproduction model. Default 24 months (i.e. 2 years).
                            #' @param calc_SS Logical. Should rank be estimated using social support measure from Vullioud et al. 2018
                            #'(https://doi.org/10.1038/s41559-018-0718-9). *Note* This will be substantially slower.
                            #' Default FALSE.
                            #' @param loci_number Integer. Number of loci in the simulated genome. Default 10.
                            #' @param allelic_diversity Proportion (0-1). Initial frequency of allele 1. Default 0.5 (equal frequency).
                            #' @param mutation_rate Probability (0-1).
                            #' Probability each allele has to mutate (0 would become 1 and 1 would become 0).
                            #' Default 10e-6.
                            #' @param random_mating Logical. Should female mate choice be random?
                            #'If TRUE, female mate choice is random (all males have equal chance to be selected).
                            #'If FALSE (default), females apply mate choice rules to avoid inbreeding (see `relatedness` below).
                            #' @param relatedness Logical. If random_mating is FALSE, is mate choice dependent on relatedness coefficient?
                            #'If FALSE (default), females use the reported female mate choice rule to avoid inbreeding (REF & DOI)
                            #'If TRUE, only those males below a threshold of relatedness are considered.
                            #' @param random_dispersal Logical. Do males choose dispersal clans randomly?
                            #'If FALSE (default), males prefer clans with a higher proportion of young females (REF & DOI)
                            #'If TRUE, all clans (including natal???) have an equal chance to be chosen for dispersal.
                            #' @param models Named list of statistical models. If NULL, a set of simple demographic models
                            #'fitted on a subset of real data are used.
                            #'**These default models are not intended for analysis only for demonstration.**
                            #'
                            #'If providing a named list, should be a list of model objects.
                            #'Currently, these can be of model class `gam`, `HLfit`, `glm/lm/glm.nb`, or `glmer/lmer`.
                            #'List should contain named items:
                            #'\itemize{
                            #'    \item {'allF', model for all female survival.}
                            #'    \item {'predispM', model for pre-dispersal male survival.}
                            #'    \item {'postdispM', model for post-dispersal male survival.}
                            #'    \item {'twin', model for twin litter probability.}
                            #'    \item {'disp', model for male secondary clan selection.}
                            #'    \item {'primirepro', model for primiparous female reproduction event.}
                            #'    \item {'nonprimirepro', model for non-primiparous female reproduction event.}
                            #'}
                            #'
                            #'See ?models for more details on fitting models.
                            #'@param predictors Named list of commands to extract model predictors from [`hyena`] objects.
                            #'Names of list should be the same as those used for models above.
                            #'
                            #'By default, will consider only those predictors available in default models.
                            #'
                            #'See ?predictors for more details and examples of defining predictors.
                            #'@param seed Integer. Seed of the current simulation.
                            #'@param save_size Numeric. The number of time-steps to save.
                            #'Default (Inf) will save all time steps, but be warned, this can be
                            #'very memory intensive for a long simulation! Reduce this value to limit the memory
                            #'load from the simulation.
                            #'@param keep.defaults Logical. When 'predictors' is provided by the user,
                            #'should default predictors still be used as well? If TRUE (default), any default predictors
                            #'that are *not* named in the 'predictors' list provided by users will also be
                            #'used inside the simulation. This can be convenient if the user wishes to change
                            #'one or two of the defaults (e.g. year or effort) and keep all others.
                            #'If FALSE, only predictors provided explicitly by the user are included.
                            #'This may be more computational efficient because it will ensure that unused
                            #'predictors are not extracted during the simulation.
                            #'
                            #'@return an object of class `simulation`

                            initialize = function(step_size = 1L, start_pop = SHIM::start_pop_example,
                                                  start_date = "1996/04/12",
                                                  include_ranef = TRUE,
                                                  number_clans = 8L, start_clan_size = 22L,
                                                  sex_ratio = 0.5, mean_age = 50,
                                                  hyena_max_age = 300L,
                                                  female_first_repro = 24L,
                                                  calc_SS = FALSE,
                                                  loci_number = 10L, allelic_diversity = 0.5, mutation_rate = 10e-6,
                                                  random_mating = FALSE, relatedness = FALSE, random_dispersal = FALSE,
                                                  models = NULL,
                                                  predictors = NULL,
                                                  seed = NULL, save_size = Inf,
                                                  keep.defaults = TRUE){

                              ## Fill attributes of simulation object ####
                              self$include_ranef      <- include_ranef
                              self$sex_ratio          <- sex_ratio
                              self$hyena_max_age      <- hyena_max_age
                              self$female_first_repro <- female_first_repro
                              self$loci_number        <- loci_number
                              self$allelic_diversity  <- allelic_diversity
                              self$mutation_rate      <- mutation_rate
                              self$random_mating      <- random_mating
                              self$random_dispersal   <- random_dispersal
                              self$relatedness        <- relatedness
                              self$start_pop          <- start_pop
                              self$step_size          <- step_size
                              self$calc_SS            <- calc_SS
                              self$seed               <- seed
                              self$save_size          <- save_size
                              self$version            <- utils::packageVersion("SHIM")

                              ## The correct names for named list items models and predictors
                              modnames <- c("allF", "postdispM", "predispM", "twin", "disp", "primirepro", "nonprimirepro")

                              #### ADD PREDICTORS
                              ## If they've provided a list of lists, assume this includes all possible predictors
                              ## FIXME: I guess we also want to allow them to adjust only *one* of the predictors in *one* model
                              ## without needing to re-iterate everything
                              if (all(sapply(predictors, inherits, what = "list")) & !is.null(predictors)) {

                                if (!all(modnames %in% names(predictors))) {
                                  stop(paste0("Predictors should be a named list with items: ", paste(modnames, collapse = ", ")))
                                }

                                ## If it's a correctly named list, assign it as the predictors trait
                                self$predictors <- predictors

                              } else {

                                ## If users want to keep defaults then edit/append accordingly
                                if (keep.defaults) {
                                  default_predictors <- list(age = function(ID) ID$age,
                                                             rank_category = \(ID) fetch_id_rank.category(ID, age = 24, number.top = 5),
                                                             rank_category_mother = \(ID) fetch_id_rank.category(ID, age = 24, number.top = 5, target = "motherID"),
                                                             clan_size = function(ID) ID$clan_ID[["size"]],
                                                             year = function(ID) lubridate::year(ID$simulation_ID[["date"]]),
                                                             months = function(ID) ID$age - ID$last_repro - 4,
                                                             after1y_effort_all = function(...) 1,
                                                             is_philo = function(ID) ID$birth_date == ID$first_date)

                                  ## If it's a list of functions...
                                  ## check if any of them are names already in the default variables
                                  if (any(names(predictors) %in% names(default_predictors))) {

                                    duplicates <- names(predictors)[names(predictors) %in% names(default_predictors)]
                                    for (duplicate_name in duplicates) {
                                      default_predictors[[duplicate_name]] <- predictors[[duplicate_name]]
                                    }

                                  }

                                  ## If there are any that are NOT duplicates, append them to the defaults
                                  if (any(!names(predictors) %in% names(default_predictors))) {
                                    non_duplicates <- predictors[!names(predictors) %in% names(default_predictors)]
                                    default_predictors <- append(default_predictors, non_duplicates)
                                  }

                                } else {

                                  default_predictors <- predictors

                                }

                                ## Now expand them out to all individuals
                                self$predictors <- lapply(modnames, \(...){
                                  default_predictors
                                })
                                names(self$predictors) <- modnames

                              }

                              #Use user provided seed
                              set.seed(self$seed)

                              ## Do this so it will work even if SHIM is not attached in search path
                              default_models <- SHIM::model_list

                              ## Build model list ####
                              #If models is a list...
                              if (inherits(models, what = "list") & !is.null(models)) {

                                ## Check that models that have been provided are valid...
                                purrr::walk(.x = models,
                                            function(model){

                                              check_function_arg.model(model)

                                            })

                                #If there are any models we can't use, throw a warning
                                if (any(!names(models) %in% modnames)) {

                                  excess_models <- names(models)[!names(models) %in% modnames]
                                  warning(paste0("Models ", paste(excess_models, collapse = TRUE, sep = ", "), " are ignored.\nPossible models are: ", paste(modnames, collapse = TRUE, sep = ",")))
                                }

                                #If not all models are provided, use default models and update those provided...
                                if (!all(modnames %in% names(models))) {

                                  ## Add a warning because the default models are often not ideal
                                  ## because they are fitted on a subset of years
                                  warning("Not all required models were provided. Using default models to fill gaps.\nBe aware that these default models are not designed for analysis.")

                                  duplicates <- names(models)[names(models) %in% modnames]
                                  for (duplicate_name in duplicates) {
                                    default_models[[duplicate_name]] <- models[[duplicate_name]]
                                  }

                                ## If all the model names are available, replace the model list with that provided by user
                                } else {

                                  default_models <- models

                                }

                                ## If models is not a named list AND not NULL, throw an error
                              } else if (!is.null(models)) {

                                stop("Argument `models` should either be a named list of models or left empty.")

                              }

                              ## Add the models as the trait after updating
                              self$models <- default_models

                              ## Set date of simulation ####
                              #If we have start_pop we use the first date
                              #otherwise, we use the start_date argument
                              if (is.data.frame(start_pop)) {

                                #Use earliest date in start_pop to start simulation
                                self$date <- start_pop$date[1]

                              } else {

                                self$date <- as.Date(start_date)

                              }

                              ## Create crater object ####
                              self$crater <- crater$new(start_pop = start_pop,
                                                        number_clans = number_clans,
                                                        start_clan_size = start_clan_size,
                                                        sex_ratio = sex_ratio, mean_age = mean_age,
                                                        simulation_ID = self)

                            },

                            #' @description
                            #' Run simulation objects for number of time steps.
                            #'
                            #' Run simulation and save output in `Rawdata_tbl` attribute.
                            #'
                            #' @param number_steps Integer. Number of time steps over which the simulation will run.
                            #' @param save_file File path. The path for the .txt file that will be created with summary data (i.e. pop/clan size).
                            #' If NULL, data will still be saved as temp file and can be accessed for trouble-shooting.
                            #'
                            #' @return Update attributes of `simulation` object.

                            run_sim = function(number_steps, save_file = NULL){

                              #Set seed again at start of run_sim()
                              #Seed may have been changed since initialization
                              set.seed(self$seed)

                              #Time simulation
                              time <- system.time({

                                #Set a progress bar that expects to run number_steps
                                pb <- utils::txtProgressBar(min = 1, max = number_steps,
                                                            char = "|", style = 3)

                                #Loop through all time steps...
                                for (time_step in seq(1, number_steps, 1)) {

                                  #Save population information at time t
                                  # - For the very first time-step, we need to create the save files (e.g. summary text file)
                                  #   and record initial conditions.
                                  # - Skip saving at the first time step if simulation is being extended.
                                  #   In this case, save files already exist and 'initial conditions' for the extension
                                  #   are already recorded as the last step of the previous run.
                                  if (is.null(self$Rawdata_tbl) | (!is.null(self$Rawdata_tbl) & time_step > 1)) {

                                    save_timestep(object = self,
                                                  first_step = time_step == 1, final_step = FALSE,
                                                  save_file = save_file, save_size = self$save_size)

                                  }

                                  #Advance to time t+1
                                  self$date <- self$date + months(self$step_size)

                                  #Pass time in the crater
                                  #Involves:
                                  # - Ageing
                                  # - Survival
                                  # - Male dispersal
                                  # - Reproduction
                                  self$crater$pass_time()

                                  #Advance progress bar
                                  utils::setTxtProgressBar(pb, time_step)

                                  #Determine size of all clans
                                  #Terminate the loop if all clans have died.
                                  #Also terminate if there is only 1 clans with 1 individual
                                  #This seems to cause R to crash (may be issue with Rcpp?)
                                  all_clans <- sapply(self$crater$clans, function(x){

                                    length(x$inhabitants)

                                  })

                                  if (length(all_clans) == 0 | (length(all_clans) == 1 && all_clans == 1L)) {

                                    warning("All clans died before end of simulation")
                                    break()

                                  }

                                }

                                ## Record population genetic data : record the mean genetic relatedness and average similarity of the loci
                                self$crater$genetic_data <- rbind(self$crater$genetic_data, c(genetic_relatedness = mean(self$crater$mean_genetic_relatedness),
                                                                                              diversity_coef = mean(self$crater$diversity_coef),
                                                                                              date = self$crater$date))

                                #Save population information at the end of the simulation
                                save_timestep(self, first_step = FALSE, final_step = TRUE,
                                              save_file = save_file, save_size = self$save_size)

                              })

                              #Print run time
                              cat("\n \n")
                              print(paste("Simulation took", round(time[[3]]), "seconds", sep = " "))

                            }

                          ))
