#' R6 class a genome of a [`hyena`] individual
#'
#' @author Louise Chevalier
#' @export
#' @examples
#' test_genome <- genome$new(loci_number = 10, allelic_diversity = 0.5, mother = NULL, father = NULL)

genome <- R6::R6Class(classname = "genome",
                      public = list(

                        ## Slots for the class attributes #######################################################

                        #'@field dna Matrix. Matrix with number of rows equal to the number of loci
                        #' and number of columns equal to the number of alleles (2).
                        dna = array(),

                        ## Slots for the methods stored in the class ####################################################

                        #' @description
                        #' Create a new R6 object of class `genome`.
                        #'
                        #' This functions is used to create the object within the parent [`hyena`] object.
                        #'
                        #' @param loci_number Integer. Number of loci to simulate.
                        #' @param allelic_diversity Numeric (0-1). Allelic diveristy of loci. All genomes simulate 2 alleles.
                        #' @param mother R6 object. Object of class [`hyena`] representing individuals (genetic) mother.
                        #' @param father R6 object. Object of class [`hyena`] representing individuals father.
                        #'
                        #' @return an object of class `genome`

                        initialize = function(loci_number, allelic_diversity, mother, father) {

                          self$dna = array(0L, dim = c(loci_number, 2))
                          #for the first individuals in the clan we randomly create their genomes

                          if (is.null(mother$ID) || is.null(father$ID)) {

                            self$dna <-  array(c(sample(0:1, size = 1, prob = c((1 - allelic_diversity),allelic_diversity)), sample(0:1, size = 1, prob = c((1 - allelic_diversity),allelic_diversity))), dim = c(loci_number, 2))

                            # for newborns : their genomes are created by randomly picking alleles from parents genome
                          } else {
                            self$dna[, 1] <- mother$genome$dna[cbind(1:loci_number, sample(1:2, size = loci_number, replace = TRUE))]
                            self$dna[, 2] <- father$genome$dna[cbind(1:loci_number, sample(1:2, size = loci_number, replace = TRUE))]
                          }
                          NULL
                        },

                        #' @description
                        #' Mutate `genome`.
                        #'
                        #' Mutation rate is
                        #'
                        #' @param mutation_rate Probability (0-1). Probability that each allele will change state (0 -> 1 or 1 -> 0).
                        #'
                        #' @return Update dna attribute of `genome` object
                        mutation = function(mutation_rate) {
                          do_loci_mutate <- runif(1:nrow(self$dna)) < mutation_rate
                          self$dna[do_loci_mutate] <- abs(self$dna[do_loci_mutate] - 1)
                          NULL
                        }


                      ))
