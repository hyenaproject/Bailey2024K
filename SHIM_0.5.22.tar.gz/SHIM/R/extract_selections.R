#' Extract all selection information by dispersing males
#'
#' Create a table identical to 'selections' in the database.
#' This will include all records where a male moved clans.
#'
#' @param sim Object of class \code{\link{simulation}}. Must be following the method run_sim().
#'
#' @return Returns a data frame with all selection decisions.
#' @export

extract_selections <- function(sim){

  #Create the Selections_tbl
  temp_data <- sim$Rawdata_tbl %>%
    dplyr::filter(.data$sex == "male") %>%
    dplyr::group_by(.data$ID, .data$clan) %>%
    dplyr::summarise(date = .data$current_date[1]) %>%
    dplyr::filter(dplyr::n() > 1)

  pb <- utils::txtProgressBar(min = 1, max = length(unique(temp_data$ID)), char = "|", style = 3)

  pb_counter <- 1

  utils::setTxtProgressBar(pb, pb_counter)

  Selections_tbl <- purrr::map_df(.x = unique(temp_data$ID),
                                 .f = ~{

                                   subset <- filter(temp_data, ID == ..1)

                                   output <- data.frame(ID = ..1,
                                                        origin = subset$clan[1:nrow(subset) - 1],
                                                        destination = subset$clan[2:nrow(subset)],
                                                        date = subset$date[2:nrow(subset)])

                                   output$date <- ifelse((output$date %% 1) == 0.5, paste(floor(output$date), "-7-1", sep = ""), paste(output$date, "-1-1", sep = ""))

                                   pb_counter <- pb_counter + 1
                                   utils::setTxtProgressBar(pb, pb_counter)

                                   output

                                 })

  return(Selections_tbl)

}
