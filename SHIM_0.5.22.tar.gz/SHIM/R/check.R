#' Check for usable model types within simulation
#'
#' This function should not be directly used by the user.
#'
#' @param model Model object used to determine simulation
#' outcomes inside simulation.
#'
#' @export
#' @examples
#' #e.g. Simulations can work with lm/glm models
#' check_function_arg.model(lm(1~1))
check_function_arg.model <- function(model){

  possible_mods <- c("gam", "glm", "lm", "lmerMod", "glmerMod", "HLfit")

  mod_class <- class(model)[1]

  if (!mod_class %in% possible_mods) {

    stop(paste0("Model class ", mod_class, " is not accepted. Please use one of: ", paste0(possible_mods, collapse = ", ")))

  } else {

    model

  }

}

#' Check for a finished simulation object
#'
#' This function should not be directly used by the user.
#'
#' @param data.R6 R6 simulation object following `run_sim()`.
#'
#' @export
#' @examples
#' sim_test <- simulation$new(number_clans = 1,
#' start_clan_size = 2, sex_ratio = 0.5, mean_age = 6,
#' seed = 123)
#'
#' sim_test$run_sim(number_steps = 5)
#'
#' check_function_arg.data.R6(sim_test)
check_function_arg.data.R6 <- function(data.R6) {

  #Check that it's a simulation R6 object
  if (!identical(class(data.R6), c("simulation", "R6"))) {

    stop("Please provide a simulation R6 object to the data.R6 argument. This can be generated using the package SHIM")

  }

  if (is.null(data.R6$Rawdata_tbl)) {

    stop("Simulation object does not have output data.
         Make sure to run the simulation with `run_sim` before loading.
         If the simulation has failed before completion use function `write_output` to generate the output data.")

  }

  data.R6

}

#' Check value of 'save' argument
#'
#' This function should not be directly used by the user.
#'
#' @param save Character. Possible value of 'save' argument.
#'
#' @export
#' @examples
#' #Passes
#' check_function_arg.save('no')
#'
#' #Fails
#' #check_function_arg.save('fail')
check_function_arg.save <- function(save) {

  possible_save <- c("no", "summary", "snapshot", "full")

  if (!save %in% possible_save) {

    stop(paste0(save, " is not an accepted value to argument 'save'. Please use one of: ", paste0(possible_save, collapse = ", ")))

  } else {

    save

  }

}
