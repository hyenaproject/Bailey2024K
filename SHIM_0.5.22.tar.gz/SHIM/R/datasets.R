#' Non documented dataset from Louise
#' @name out_sensi
NULL

#' Non documented dataset from Louise
#' @name Hyena_ped_stats
NULL

#' Non documented dataset from Louise
#' @name sim_ped_stats
NULL

#' Simple models used to run simulation examples.
#'
#' All models are generated from data on Ngorongoro Crater hyenas
#' between 1997 and 1999. List includes 7 models:
#' \describe{
#'   \item{allF}{Female survival model.}
#'   \item{predispM}{Male pre-dispersal survival model (<24mo).}
#'   \item{postdispM}{Male post-dispersal survival model (>=24mo).}
#'   \item{primirepro}{Primiparous reproduction model.}
#'   \item{nonprimirepro}{Multiparous reproduction model.}
#'   \item{twin}{Litter size model (is a litter size 1 or 2).}
#'   \item{disp}{Male secondary dispersal model.}
#'   }
#'
#' @format Named list of tibbles
#' @name model_list
#' @examples
#' \dontrun{
#'   ## Extract data for models
#'   ## You will need access to the Hyena Project database
#'   model_data <- generate_model_data()
#'
#'   ## Default models only use early years
#'   year_range <- 1997:1999
#'
#'   ## Fit simple female survival model
#'   female_mod <- spaMM::fitme(surv ~ poly(age, 2) + rank_category
#'                              + clan_size + (1|year),
#'                              data = model_data$F_surv_data |>
#'                                  dplyr::filter(year %in% year_range),
#'                              family = binomial(link = "logit"),
#'                              method = "PQL/L")
#'
#'   ## Fit simple male pre-dispersal survival model
#'   predisp_male_mod <- spaMM::fitme(surv ~ poly(age, 2) + rank_category
#'                                    + clan_size + (1|year),
#'                                    data = model_data$PreM_surv_data |>
#'                                        dplyr::filter(year %in% year_range),
#'                                    family = binomial(link = "logit"),
#'                                    method = "PQL/L")
#'
#'   ## Fit simple male post-dispersal survival model
#'   postdisp_male_mod <- spaMM::fitme(surv ~ age + clan_size + (1|year),
#'                                     data = model_data$PostM_surv_data |>
#'                                         dplyr::filter(year %in% year_range),
#'                                     family = binomial(link = "logit"),
#'                                     method = "PQL/L")
#'
#'   ## Fit simple primiparous reproduction model
#'   primi_repro_mod <- spaMM::fitme(repro ~ months + rank_category
#'                                   + clan_size + after1y_effort_all + (1|year),
#'                                   data = model_data$F_repro_primi |>
#'                                       dplyr::filter(year %in% year_range),
#'                                   family = binomial(link = "logit"),
#'                                   method = "PQL/L")
#'
#'   ## Fit simple multiparous reproduction model
#'   multi_repro_mod <- spaMM::fitme(repro ~ months*age + rank_category
#'                                   + clan_size + after1y_effort_all + (1|year),
#'                                   data = model_data$F_repro_nonprimi |>
#'                                       dplyr::filter(year %in% year_range),
#'                                   family = binomial(link = "logit"),
#'                                   method = "PQL/L")
#'
#'   ## Fit simple twinning model
#'   twin_mod <- spaMM::fitme(twin ~ poly(age, 2) + rank_category
#'                            + clan_size + (1|year),
#'                            data = model_data$F_twin_data |>
#'                                dplyr::filter(year %in% year_range),
#'                            family = binomial(link = "logit"),
#'                            method = "PQL/L")
#'
#'   ## Fit secondary dispersal model
#'   disp_mod <- spaMM::fitme(second_disp ~ is_philo,
#'                            ## Use a slightly larger sample size.
#'                            ## First cases of secondary dispersal don't occur until 2001
#'                            ## So early data suffers from issues of separation.
#'                            data = model_data$M_second_disp_data |>
#'                            dplyr::filter(year %in% 1997:2002),
#'                            family = binomial(link = "logit"), method = "PQL/L")
#'
#'   model_list <- list(allF = female_mod,
#'                      predispM = predisp_male_mod,
#'                      postdispM = postdisp_male_mod,
#'                      primirepro = primi_repro_mod,
#'                      nonprimirepro = multi_repro_mod,
#'                      twin = twin_mod,
#'                      disp = disp_mod)
#'
#' }
NULL

#' Example data to start simulation
#'
#' Tibble containing data that can be provided to the `start_pop` argument in a simulation.
#' Example is a snapshot of data from Ngorongoro Crater at the start of the study period
#' (1996-04-12). Data is generated using `get_data.start()`.
#'
#' \describe{
#'   \item{ID}{ID of individual.}
#'   \item{date}{Date of observation {YYYY-MM-DD}.}
#'   \item{sex}{Sex of individual (female or male).}
#'   \item{age}{Age of individual (months).}
#'   \item{birth_date}{Birth date of individual (YYYY-MM-DD).}
#'   \item{birth_clan}{Birth clan of individual.}
#'   \item{motherID}{ID of mother. NA when mother is unknown.}
#'   \item{mothersocialID}{ID of social mother. NA when mother is unknown.
#'   In cases of adoption, motherID and mothersocialID will differ.}
#'   \item{fatherID}{ID of father. NA when father is unknown.}
#'   \item{current_clan}{Current clan of individual.
#'   Will differ from birth_clan if an individual has dispersed.}
#'   \item{lifetime_RS}{Reproductive success of individual at time of observation.}
#'   \item{tenure}{Tenure of individual in current clan (months).}
#'   \item{litterID}{Litter in which an individual was born. Allows us to identify siblings.}
#'   \item{selections}{List column containing all previous selection events of an individual.
#'   This is needed to identify whether males are philopatric or disperser.}
#'   \item{adnat_rank}{Ordinal rank of natal adult individuals in the current clan.}
#'   \item{adnat_rank_std}{Standardised rank of natal adult individuals in the current clan.}
#'   \item{gender_rank}{Ordinal rank of individuals of the same gender in the current clan.}
#'   \item{gender_rank_std}{Standardised rank of individuals of the same gender in the current clan.}
#'   \item{nat_rank}{Ordinal rank of all natal individuals in the current clan.}
#'   \item{nat_rank_std}{Standardised rank of all natal individuals in the current clan.}
#'   \item{rank}{Ordinal rank of all individuals in the current clan.}
#'   \item{rank_std}{Standardised rank of individual in the current clan.}
#'   \item{sel_rank}{Ordinal rank of all selector (non-natal) individuals in the current clan.}
#'   \item{sel_rank_std}{Standardised rank of all selector (non-natal) individual in the current clan.}
#'   \item{mother_rank}{Ordinal rank of social mothers within all natal adult individuals in the current clan.}
#'   \item{last_repro}{Age (months) at which the individual last reproduced.
#'   NA when individual has not previously reproduced.}
#'   \item{first_repro}{Age (months) at which the individual first reproduced.
#'   NA when individual has not previously reproduced.}
#'   \item{offspring}{List column contaning IDs of all known offspring.}
#'   \item{siblingID}{ID of known sibling.}
#'   }
#'
#' @format Tibble
#' @name start_pop_example
#' @examples
#' \dontrun{
#'  ## Use get_data.start() to generate start population from Crater
#'  ## at beginning of study.
#'  get_data.start(db.path = file.choose(), at = "1996-04-12")
#' }
NULL
