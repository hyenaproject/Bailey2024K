#' R6 class recreating the Ngorongoro Crater environment
#'
#' `crater` is an [`R6 class`][`R6::R6Class`] that includes child objects
#' [`clan`] and [`hyena`].
#'
#' @author Liam D. Bailey
#' @export
#' @examples
#' #Create simulation object
#' sim_test <- simulation$new()
#'
#' test_crater <- crater$new(number_clans = 8, start_clan_size = 20,
#' sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test)

crater <- R6::R6Class(classname = "crater",
                      public = list(

                        ## Slots for the class attributes #######################################################

                        #'@field  clans List. List of R6 objects of class [`clan`].
                        clans = list(),

                        #'@field all_clan_names Character vector. A vector with the names of all clans
                        #'(easier to associate clan names with an individual than indexing clan name every time).
                        all_clan_names = NULL,

                        #'@field indv_avg_support Numeric. The average support of individuals across all clans in a given year.
                        indv_avg_support = NULL,

                        #'@field snapshot_data Data frame. A snapshot of all individuals in all clans at each time point
                        snapshot_data = list(),

                        #'@field mean_genetic_relatedness Numeric vector. A vector with the average similarity per loci in the population,
                        #'used to calculate genetic relatedness
                        mean_genetic_relatedness = 0,

                        #'@field diversity_coef Numeric vector. A vector with the coef of diversity per loci in the population.
                        diversity_coef = 0,

                        #'@field genetic_data Data frame. Data frame to store mean genetic relatedness and diversity coef.
                        genetic_data = NULL,

                        #'@field simulation_ID R6 object. Parent R6 objects of class [`simulation`].
                        simulation_ID = NULL,

                        ## Slots for the methods stored in the class ####################################################

                        #' @description
                        #' Create a new R6 object of class `crater`.
                        #'
                        #' This functions is used to create the object and all child objects (`clan`, `hyenas`).
                        #'
                        #' @param start_pop Data frame. Individuals used to initialise the simulation (optional).
                        #' Can be generated from the Ngorongoro Crater database on a given date using [get_data.start()].
                        #' If missing, individuals used to initialise the simulation will be procedurally generated from
                        #' known demographic characteristics of the Ngorongoro Crater population (e.g. sex ratio, mean age).
                        #' @param number_clans Integer. If `start_pop` is NULL, the number of clans to be procedurally generated.
                        #' @param start_clan_size Integer. Number of individuals in each generated clan.
                        #' @param sex_ratio Probability (0-1). Probability for a new cub to be female.
                        #' @param mean_age Numeric. Mean age of individuals, used as \eqn{\lambda} to generate age of individuals
                        #' from a Poisson distribution.
                        #' @param simulation_ID R6 object. Parent R6 object of class [`simulation`].
                        #'
                        #' @return an object of class `crater`

                        initialize = function(start_pop = NULL, simulation_ID = NULL,
                                              number_clans, start_clan_size, sex_ratio, mean_age){

                          #Add parent simulation object ID
                          self$simulation_ID <- simulation_ID

                          ## Set number of clans ####
                          if (is.data.frame(start_pop)) {

                            number_clans <- length(unique(start_pop$current_clan))

                          } else if (missing(number_clans)) {

                            stop("Please specify the number of clans to simulate using the `number_clans` argument or provide a `start_pop` data frame.")

                          } else if (!is.numeric(number_clans)) {

                            stop("`number_clans` should be an integer.")

                          } else if (number_clans > 8) {

                            stop("Simulation can only have maximum 8 clans (the number of clans in the Ngorongoro Crater)")

                          }

                          ## Create clans using start_pop data ####
                          if (is.data.frame(start_pop)) {

                            #Save clan names for later indexing
                            self$all_clan_names <- unique(start_pop$current_clan)

                            #Arrange clans alphabetically
                            start_pop <- start_pop %>%
                              dplyr::arrange(.data$current_clan, .data$rank)

                            #Determine the max number of individuals in each clan
                            start_pop <- start_pop %>%
                              dplyr::mutate(current_clan = regmatches(x = .data$ID, m = regexpr(pattern = "^[A-Z]", text = .data$ID)),
                                            indvnr = as.numeric(regmatches(x = .data$ID, m = regexpr(pattern = "[0-9]+$", text = .data$ID)))) %>%
                              dplyr::group_by(.data$current_clan) %>%
                              dplyr::summarise(maxnr = max(.data$indvnr), .groups = "drop") %>%
                              dplyr::right_join(start_pop, by = "current_clan", multiple = "all")

                            #Split start_pop data into list for looping
                            #For every set of clan data, create a new clan object
                            clan_list <- split(x = start_pop, f = start_pop$current_clan)
                            purrr::pwalk(.l = list(clan_list, 1:length(clan_list), names(clan_list)),
                                         function(clan_info, i, clan_name){

                                           self$clans[[i]] <- clan$new(start_individuals = clan_info,
                                                                       clan_name = clan_name,
                                                                       crater_ID = self)

                                           self$clans[[i]]$total_births <- clan_info$maxnr[1]

                                         })

                            #Once we've initialised all hyenas, we need to go back through and link each individual to their parents

                            #Unlist all individuals. We don't want to search within each clan because parents may have moved from their birthclan
                            all_indv <- purrr::map(.x = self$clans,
                                                   function(clan){

                                                     clan$inhabitants

                                                   }) %>%
                              unlist()

                            #For those individuals that have a mother or father in the start data, find the corresponding hyena object in the individual list
                            #Remember, because these are mutable objects the reference in all_indv will be the same as in inhabitants
                            start_pop %>%
                              dplyr::filter(!is.na(motherID) | !is.na(fatherID)) %>%
                              purrr::pwalk(.l = list(.$ID, .$motherID, .$fatherID, .$siblingID),
                                           .f = ~{

                                             child <- all_indv[sapply(all_indv, function(x){

                                               x$ID == ..1

                                             })][[1]]

                                             if (!is.na(..2)) {

                                               mother <- all_indv[sapply(all_indv, function(x){

                                                 x$ID == ..2

                                               })]

                                               if(length(mother) == 1){

                                                 child$motherID <- mother[[1]]

                                               }

                                             }

                                             if (!is.na(..3)) {

                                               father <- all_indv[sapply(all_indv, function(x){

                                                 x$ID == ..3

                                               })]

                                               if (length(father) == 1) {

                                                 child$fatherID <- father[[1]]

                                               }

                                             }

                                             if (!is.na(..4)) {

                                               sibling <- all_indv[sapply(all_indv, function(x){

                                                 x$ID == ..4

                                               })]

                                               if (length(sibling) == 1) {

                                                 child$sib_ID <- sibling[[1]]

                                               }

                                             }

                                             #refit genome now that we have parental info
                                             child$genome <- genome$new(self$simulation_ID$loci_number,
                                                                        self$simulation_ID$allelic_diversity,
                                                                        child$motherID, child$fatherID)

                                           })

                            ## Procedurally generate clans if no start_pop ####
                          } else {

                            #Generate clan names that we will draw from below.
                            self$all_clan_names <- c("A", "F", "L", "M", "S", "T", "N", "E")[1:number_clans]

                            #Create as many clan objects as specified in simulation with `number_clans`
                            for (clan_number in 1:number_clans) {

                              #Generate a clan (which will include generating individuals)
                              self$clans[[clan_number]] <- clan$new(clan_name = self$all_clan_names[[clan_number]],
                                                                    start_clan_size = start_clan_size,
                                                                    crater_ID = self, sex_ratio = sex_ratio, mean_age = mean_age)

                            }

                          }

                          # calculate genetic relatedness initially in the population (using C++ functions)
                          # dnaL <- purrr::flatten(lapply(self$clans, function(x){
                          #   lapply(x$inhabitants, function(y){ ## list of dna of individuals in the clan
                          #     y$genome$dna
                          #   })
                          # }))

                          ##  return a vector with average similarity per loci
                          # self$mean_genetic_relatedness <- mean_genetic_relatedness(dnaL)
                          ## return the coefficient of diversity in the population
                          # self$diversity_coef <- diversity_coef(dnaL)

                        },

                        #' @description
                        #' Advance by one time step in all clans.
                        #'
                        #' Passing time will involve:
                        #' \itemize{
                        #'     \item {Save information on all individuals at time t.}
                        #'     \item {Record population genetic information and calculate relatedness.}
                        #'     \item {Simulation survival, ageing and genetic mutation for all individuals.}
                        #'     \item {Simulate male dispersal.}
                        #'     \item {Simulate reproduction of all females.}
                        #' }
                        #'
                        #' @return Update attributes of child [`clan`] and [`hyena`] objects
                        #' @export

                        pass_time = function(){

                          ## Genetic data (UNUSED) ####
                          ## Record population genetic data: mean genetic relatedness and average similarity of the loci
                          # self$genetic_data <- rbind(self$genetic_data,
                          #                            c(genetic_relatedness = mean(self$mean_genetic_relatedness),
                          #                              diversity_coef = mean(self$diversity_coef),
                          #                              date = self$simulation$date))

                          ### calculate population genetic relatedness
                          ## list of the dna of individuals in the population
                          # dnaL <- purrr::flatten(lapply(self$clans, function(x){
                          #   lapply(x$inhabitants, function(y){
                          #     y$genome$dna
                          #   })
                          # }))

                          ## calculate the average genetic relatedness in the population for the current time step (a vector containing the coefficient of mean genetic relatedness per loci)
                          # self$mean_genetic_relatedness <-  mean_genetic_relatedness(dnaL)
                          ## calculate the coefficient of diversity in the population per loci for the current time step
                          # self$diversity_coef <- diversity_coef(dnaL)

                          ### STEP 1: AGEING ####
                          #Age all individuals in all clans at the same time
                          lapply(self$clans, \(clan){

                            clan$age_clan()

                          })

                          ### STEP 2: SURVIVAL ####
                          #Age all individuals in all clans at the same time
                          lapply(self$clans, \(clan){

                            clan$survive_clan()

                          })

                          ### STEP 3: REMOVE DEAD ####
                          #Remove any individuals that died in this process
                          lapply(self$clans, \(clan){

                            clan$update_clan(record_deaths = TRUE)

                          })

                          ### STEP 4: MUTATION ####
                          # All alive individuals have their genome mutate
                          ## FIXME: Can this be batched? Does it take much time?
                          ## Can we include an argument to exclude genome if not needed?
                          for (clan_no in sample(1:length(self$clans))) {

                            #If the clan is empty then just move to the next one.
                            if (length(self$clans[[clan_no]]$size) == 0) {

                              next()

                            }

                            #If we are using social support calculate this here
                            if (self$simulation_ID$calc_SS == TRUE) {

                              social_support(self)

                            }

                            lapply(self$clans[[clan_no]]$inhabitants, \(ID){
                              ID$genome$mutation(ID$simulation_ID$mutation_rate)
                            })

                            #For all inhabitants in a clan...
                            # for (indv in 1:length(self$clans[[clan_no]]$inhabitants)) {
                            #
                            #   #Allow for genetic mutation
                            #   self$clans[[clan_no]]$inhabitants[[indv]]$genome$mutation(self$simulation_ID$mutation_rate)
                            #
                            # }

                          }

                          ### STEP 5: DISPERSAL ####
                          #All surviving males will prospect and disperse
                          #Do this in random order for all clans
                          lapply(self$clans[sample(seq_len(length(self$clans)))], \(clan){

                            clan$disperse_clan()

                          })

                          ### STEP 6: UPDATE CLANS ####
                          #For each clan, we then need to go through and do a two tasks:
                          # - Update clan size considering dispersing males (and deal with dead clans)
                          # - Re-calculate rank with newest individuals at the bottom
                          ## This will remove dead clans that have no more individuals because males dispersed
                          lapply(self$clans, \(clan){

                            clan$update_clan()

                          })

                          ### STEP 7: REPRODUCTION ####
                          ## Not needed to be random. Females aren't affected by reproduction in other clans.
                          lapply(self$clans, \(clan){

                            clan$reproduce_clan()

                          })

                          ### STEP 8: CLEAN UP ####
                          #Need to run through and update all clans one final time to account for new immigrants to the population
                          #i.e. even though we updated at the end of each list, a male might have moved to clan A and it needs to be done again
                          for (clan_no in 1:length(self$clans)) {

                            self$clans[[clan_no]]$update_clan()

                            #This is currently unused, but will be in the future
                            # self$clans[[clan_no]]$update_prey()

                          }

                          #If a clan died during pass_time (i.e. its size is 0), then we delete it from the list of clans.
                          dead_clans <- sapply(self$clans, function(x) x[["size"]]) == 0

                          if ( any(dead_clans)) {

                            self$clans[dead_clans] <- NULL

                          }

                        }))
