#' Return individuals in a clan on a given date
#'
#' Returns a matrix of character strings with the names all individuals older than 1yo that are in a clan on a given date.
#'
#' @param date The date at which clan occupants are determined
#' @param clan The focal clan
#' @param selection Dataframe with information on male dispersal decisions
#' @param hyena Dataframe containing information on all recorded hyena.
#'
#' @return A 3 column matrix with the name, birth clan and current clan of all individuals present in a clan at given date.
#' @export
#'
#' @examples
#' \dontrun{
#' ## FIXME: Old examples. This data no longer available.
#' ## This code and examples need to be updated!!
#' data("hyenas")
#' data("dispersal_records")
#' data("interactions")
#'
#' clan_list <- get_clan_members(date = interactions$date[1],
#' clan = interactions$clan_f[1],
#' selection = dispersal_records, hyena = hyenas)
#'
#' clan_list
#' }

get_clan_members <- function(date, clan, selection, hyena) {

  #Create a subset of all hyenas that were:
  # - Individual was born at least a year before the interaction occured
  # - Individual died after the interaction occured (or has not died)
  #Extract their ID, birthclan and birthdate.
  alive_indv <- hyena[hyena$birthdate < (date  - lubridate::years(1)) & (hyena$death > date | is.na(hyena$death)), c("ID", "birthclan")]

  #Determine the current clan of every individual in the above subset
  alive_indv$currentclan <- purrr::map_chr(alive_indv$ID, function(x) {
    #For a given individual
    #If the individual is not found in the list of hyena names that have changed clan
    if (!(x %in% selection$ID)) {
      #Save its birthclan (i.e. it didn't move clans from birth)
      return(alive_indv$birthclan[alive_indv$ID == x])
      #If the individual is found in the list of names (i.e. it dispersed)
    } else {
      #Extract the dispersal decisions this individual made BEFORE the interaction occured
      dispersal_records <- selection[selection$ID == x & selection$date <= date, "destination"]
      #If there was no dispersal before the interaction...
      if (length(dispersal_records) == 0) {
        #Then save the birth clan
        #i.e. did dispersed at some point, but that was after the interaction occured
        return(alive_indv$birthclan[alive_indv$ID == x])
      } else {
        #If it occured afterwards, then take the value of the LAST clan that the individual dispersed to.
        return(dispersal_records[length(dispersal_records)])
      }
    }
  })

  #Reduce the list of individuals that were alive during the interaction to only include those that were ALSO in the clan at the time.
  #Return this object
  alive_indv <- alive_indv[alive_indv$currentclan == clan, ]

  ##Now go through and determine the maternal ancestry of each individual that we have determined is alive.
  #For all individuals, if the name is an NA (will this ever happen?!) then just return NA. Otherwise, save the social mother of this individual
  alive_indv$M <- purrr::map_chr(alive_indv$ID,  ~ if (is.na(.x)) NA else hyena$mothersocial[hyena$ID == .x])
  #For all social mothers of all individuals, if social mother is unknown return NA, otherwise return HER mother (i.e. the Grandma of the original individual)
  alive_indv$GM <- purrr::map_chr(alive_indv$M,  ~ if (is.na(.x)) NA else hyena$mothersocial[hyena$ID == .x])
  #Do the same for great grandma
  alive_indv$GGM <- purrr::map_chr(alive_indv$GM,  ~ if (is.na(.x)) NA else hyena$mothersocial[hyena$ID == .x])
  #Great-great-grandma
  alive_indv$GGGM <- purrr::map_chr(alive_indv$GGM,  ~ if (is.na(.x)) NA else hyena$mothersocial[hyena$ID == .x])
  #3Great-Grandma
  alive_indv$GGGGM <- purrr::map_chr(alive_indv$GGGM,  ~ if (is.na(.x)) NA else hyena$mothersocial[hyena$ID == .x])
  #4Great-Grandma
  alive_indv$GGGGGM <- purrr::map_chr(alive_indv$GGGGM,  ~ if (is.na(.x)) NA else hyena$mothersocial[hyena$ID == .x])

  #Return data frame with individuals and their maternal ancestry
  alive_indv

}
