#' Create a boxplot of sensitivity analysis
#'
#' @param output Output of function \code{\link{sensitivity_func}}
#' @param violin Also include violin plots with boxplots.
#'
#' @export

sensitivity_boxplot <- function(output, violin = FALSE){

  plot_data <- output %>%
    tidyr::pivot_longer(cols = -"focal_var", names_to = "variable") %>%

  if(violin == TRUE){

    output_plot <- ggplot2::ggplot(plot_data)+
      ggplot2::geom_violin(ggplot2::aes(x = as.factor(.data$focal_var), y = .data$value), fill = NA, colour = "black", size = 1)+
      ggplot2::geom_boxplot(ggplot2::aes(x = as.factor(.data$focal_var), y = .data$value), fill = "dark grey", colour = "black", width = 0.1)+
      ggplot2::facet_wrap(~.data$variable, scales = "free") +
      ggplot2::theme_classic()

  } else {

    output_plot <- ggplot2::ggplot(plot_data)+
      ggplot2::geom_boxplot(ggplot2::aes(x = as.factor(.data$focal_var), y = .data$value), fill = "dark grey", colour = "black", width = 0.1)+
      ggplot2::facet_wrap(~.data$variable, scales = "free")+
      ggplot2::theme_classic()

  }

  return(output_plot)

}
