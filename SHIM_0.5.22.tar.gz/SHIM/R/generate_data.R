#' Generate the full dataset to run models.
#'
#' This is an internal function and should not need to be called directly by the user.
#' This function is called inside `generate_model_data()` and returned as list
#' item 'raw_data'.
#'
#' @param monthlag How many months before/after the focal period should we
#' calculate observation effort? Default to 12.
#' @param db File path or R6 simulation object. Hyena database to use. Can either be a file path to an .sqlite database
#' or and R6 simulation object.
#' @param dd Logical. Should clan and population size be returned for estimating
#' density dependence? If data is only needed to estimate vital rates at equilibrium
#' removing clan/pop size estimates can greatly speed up data extraction.
#' @param CPUcores Integer. Number of CPU cores to use for parallel processing.
#' @return A dplyr::tibble.
#' @export
generate_monthly_data <- function(db, monthlag = 12, dd = TRUE, CPUcores = NULL){

  if (!requireNamespace("hyenaR", quietly = TRUE)) {
    stop("Package 'hyenaR' is required to generate starting data")
  }

  if (inherits(db, what = "character")) {

    db <- hyenaR::check_function_arg.path(db)

    print(paste0("Database file path: \n", db))

    #Load database
    hyenaR::load_package_database.full(db.path = db)

  } else if(inherits(db, what = "simulation")) {

    db <- check_function_arg.data.R6(db)

    #Load R6
    hyenaR::load_package_database.sim(db)

  } else {

    stop("db should be either a file path or R6 simulation object.")

  }

  # STEP 1: Create monthly observation record for each individual during their lifetime. ####
  message("Create starting table for all individuals...")

  #Table with all individuals
  hyenaR::create_id_starting.table() %>%
    ## Add fixed information for each individual
    dplyr::mutate(sex = hyenaR::fetch_id_sex(.data$ID), #Sex
                  birthclan = hyenaR::fetch_id_clan.birth(.data$ID), #Birthclan
                  birthdate = hyenaR::fetch_id_date.birth(.data$ID), #Date of birth
                  mother_genetic = hyenaR::fetch_id_id.mother.genetic(.data$ID), #Genetic mother
                  mother_social  = hyenaR::fetch_id_id.mother.social(.data$ID), #Social mother
                  father = hyenaR::fetch_id_id.father(.data$ID), #Genetic father
                  first.sighting = hyenaR::fetch_id_date.observation.first(.data$ID), #Date of first observation for an individual
                  last.sighting = hyenaR::fetch_id_date.observation.last(.data$ID), #Date of last observation for an individual
                  death_date = hyenaR::fetch_id_date.death(.data$ID), #Date of death
                  #Determine first and last month of observation.
                  #If death date not know use last sighting for last month
                  #We group observations by month, with each period starting on the first of that month.
                  last_month = lubridate::floor_date(dplyr::if_else(!is.na(.data$death_date), .data$death_date, .data$last.sighting), unit = "month"),
                  first_month = lubridate::floor_date(.data$first.sighting, unit = "month")) %>%
    #Add rows for each individual in each month between their first and last observation
    hyenaR::reshape_row_date.seq(.data$ID, .data$sex, .data$birthclan, .data$birthdate, .data$mother_genetic, .data$mother_social,
                                 .data$father, .data$first.sighting,
                                 from = .data$first_month,
                                 to = .data$last_month,
                                 by = "month") %>%
    #Create from/to columns that represent first and last date of the focal month
    dplyr::rename(from = "date") %>%
    dplyr::mutate(to = .data$from + (months(1) - lubridate::days(1))) %>%
    #We're only interested in months within the observation period
    #Remove records where from/to are not within the observation period
    dplyr::filter(.data$from >= hyenaR::find_pop_date.observation.first(), .data$to <= hyenaR::find_pop_date.observation.last()) %>%
    #Determine clan of every individual at the start of the month (we use values at beginning of month to fit models)
    #If an individual was born during a month clan will be NA at month start. Use birthclan instead.
    dplyr::mutate(start_clan = ifelse(.data$from < .data$birthdate, hyenaR::fetch_id_clan.birth(.data$ID), hyenaR::fetch_id_clan.current(.data$ID, .data$from)),
                  #Extract the year of each month (used to create test data)
                  year = lubridate::year(.data$from)) %>%
    #Also define time as number of months since start of population
    dplyr::mutate(yr_diff = lubridate::year(.data$from) - lubridate::year(min(.data$from)),
                  month_diff = lubridate::month(.data$from) - lubridate::month(min(.data$from))) %>%
    dplyr::mutate(time = .data$month_diff + (.data$yr_diff * 12)) %>%
    #filter out only observations in the main clans
    #i.e. males that disperse outside the crater will not be observed
    dplyr::filter(.data$start_clan %in% hyenaR::find_clan_name.all(main.clans = TRUE)) -> id.seq

  # STEP 2: Determine observation effort in year before and after the observation period. ####
  message("Calculate observation effort for every clan in each month...")

  #For an R6 simulation object observation effort is perfect and should be 1
  if (attr(.database, which = "datatype") == "sim") {

    id.seq.effort <- id.seq %>%
      dplyr::mutate(before1y_effort_all = 1,
                    after1y_effort_all = 1)

  } else if (attr(.database, which = "datatype") == "full"){

    #Create data frame with monthly record in every (main) clan in same format as individual data frame above
    dplyr::tibble(start_clan = hyenaR::find_clan_name.all(main.clans = TRUE)) %>%
      hyenaR::reshape_row_date.seq(.data$start_clan,
                                   from = min(id.seq$from),
                                   to = max(id.seq$from),
                                   by = "month") %>%
      dplyr::mutate(from = .data$date,
                    to = .data$from + (months(1) - lubridate::days(1))) %>%
      dplyr::select("start_clan", "from", "to") %>%
      #Determine observation effort in each month for each clan
      dplyr::mutate(hyenaR::multifetch_clan_obsv.effort(clan = .data$start_clan, from = .data$from, to = .data$to,
                                                        CPUcores = CPUcores)) %>%
      #For every clan, return lag and lead columns for every month of lag required
      dplyr::group_by(.data$start_clan) %>%
      dplyr::mutate(purrr::map_dfc(.x = 0:monthlag,
                                   .f = function(month, effort){

                                     dplyr::tibble("lag_{month}" := dplyr::lag(x = effort, n = month))

                                   }, effort = .data$effort_all),
                    purrr::map_dfc(.x = 0:monthlag,
                                   .f = function(month, effort){

                                     dplyr::tibble("lead_{month}" := dplyr::lead(x = effort, n = month))

                                   }, effort = .data$effort_all)) %>%
      dplyr::ungroup() %>%
      dplyr::mutate(before1y_effort_all = rowMeans(dplyr::select(., dplyr::starts_with("lag"))),
                    after1y_effort_all = rowMeans(dplyr::select(., dplyr::starts_with("lead")))) %>%
      dplyr::select("start_clan", "from", "to", "before1y_effort_all", "after1y_effort_all") -> clan.effort

    # STEP 3: Join clan effort and individual observations ####
    id.seq %>%
      dplyr::left_join(multiple = "all", clan.effort, by = c("start_clan", "from", "to")) -> id.seq.effort

  }

  # STEP 4: Extract dispersal information ####
  message("Determine dispersal information...")

  id.seq.effort %>%
    dplyr::mutate(
      surv = hyenaR::fetch_id_is.alive(.data$ID, .data$to), #Was the individual dead by the end of the month
      #Round down the age to represent the *full months* during which an individual has been alive
      #We use age at from - 1 in case individual died exactly on from date (and therefore has no age)
      age = floor(hyenaR::fetch_id_age(.data$ID, at = .data$from - 1, unit = "month")),
      #If individual was born during the month, adjust age to 0.
      age = ifelse(.data$age < 0, 0, .data$age),
      #As with age, we consider status and tenure in day before from date incase individual died on that day
      status_start = hyenaR::fetch_id_lifestage(.data$ID, at = .data$from - 1),
      status_end = hyenaR::fetch_id_lifestage(.data$ID, at = .data$to),
      #Round down tenure to represent the *full months* of tenure experienced
      tenure = floor(hyenaR::fetch_id_duration.tenure(.data$ID, at = .data$from - 1, unit = "month"))) -> monthly.table

  #Determine clan selection behaviour of individuals
  #This includes any type of clan selection (e.g. both philopatric and dispersal)
  #Exclude births (i.e. transition from the womb "W")
  #This is needed to define a male as pre- or post-dispersal
  hyenaR::create_id_life.transition.table(hyenaR::find_pop_id.male.all()) %>%
    dplyr::filter(.data$origin != "W") %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::summarise(date_first_dispersion = min(.data$date),
                     .groups = "drop") -> first.dispersion.table

  #Define individuals as female, pre-disp male or post-disp male
  monthly.table %>%
    dplyr::left_join(multiple = "all", first.dispersion.table, by = "ID") %>%
    #Males are considered post-dispersal if they have dispersed before or during the current month
    dplyr::mutate(dispersal_status = dplyr::case_when(.data$sex == "female" ~ "female",
                                                      .data$sex == "male" & (is.na(.data$date_first_dispersion) | .data$to < .data$date_first_dispersion) ~ "pre_dispersal",
                                                      TRUE ~ "post_dispersal")) %>%
    #For post-disp males, determine if they are currently philopatric or disperser
    #Philopatric is only when individual chooses their natal clan on their first selection
    dplyr::mutate(post_dispersal_status = dplyr::case_when(.data$dispersal_status == "post_dispersal" & ((.data$status_end != "dead" & .data$status_end == "philopatric") | (.data$status_end == "dead" & .data$status_start == "philopatric")) ~ "philo",
                                                           .data$dispersal_status == "post_dispersal" & ((.data$status_end != "dead" & stringr::str_detect(.data$status_end, pattern = "disper|immigrant|selector")) | (.data$status_end == "dead" & stringr::str_detect(.data$status_start, pattern = "disper|immigrant|selector")))  ~ "disp",
                                                           TRUE ~ NA_character_)) -> monthly.table.disp

  # STEP 5: Determine rank category ####
  message("Determine rank of individuals and social mothers...")

  #For an R6 simulation object we cannot calculate rank
  #Because the py script expects a sqlite db
  #Therefore, just give them all values of 0 (so they don't get excluded later)
  if (attr(.database, which = "datatype") == "sim") {

    monthly.rank.table <- monthly.table.disp %>%
      dplyr::mutate(deathdate = hyenaR::fetch_id_date.death(.data$ID),
                    rank = 0,
                    mother.adnat.rank = 0,
                    mother_social = 0,
                    motherdeath = 0,
                    mother.adnat.rankdeath = 0,
                    rank_category = 0,
                    ID.adnat.rank = 0)

  } else if (attr(.database, which = "datatype") == "full"){

  #Determine death date of mothers that have died.
  #Ideally, if an individual is <24mo we use mother rank
  #However, if mother is dead and individual survives we will use mother rank before death
  death_ranks <- hyenaR::create_id_starting.table(sex = "female") %>%
    dplyr::mutate(deathdate = hyenaR::fetch_id_date.death(.data$ID)) %>%
    dplyr::filter(!is.na(.data$deathdate)) %>%
    #As always, we use day *before* death as this was the last time the individual was definitely alive and will have a rank
    dplyr::mutate(mother.adnat.rankdeath = hyenaR::fetch_id_rank.native.adult(.data$ID, at = .data$deathdate - 1)) %>%
    dplyr::select(mother_social = "ID", motherdeath = "deathdate", "mother.adnat.rankdeath")

  #Join mother death information to the existing data and determine the rank of the SOCIAL mother and offspring
  monthly.table.disp %>%
    dplyr::left_join(multiple = "all", death_ranks, by = "mother_social") %>%
    #We extract both mother rank and own rank for every individual
    #As always, we use day *before* death as this was the last time the individual was definitely alive and will have a rank
    dplyr::mutate(mother.adnat.rank = hyenaR::fetch_id_rank.native.adult(.data$mother_social, at = .data$from - 1),
                  ID.adnat.rank = hyenaR::fetch_id_rank.native.adult(.data$ID, at = .data$from - 1),
                  #Determine which rank should be used.
                  #For pre-dispersal males with living mothers, use mother rank
                  rank = dplyr::case_when(.data$sex == "male" & .data$dispersal_status == "pre_dispersal" & (is.na(.data$motherdeath) | .data$from < .data$motherdeath) ~ mother.adnat.rank,
                                          #For pre-dispersal males with dead mothers use rank of mother just before she died
                                          .data$sex == "male" & .data$dispersal_status == "pre_dispersal" & .data$from >= .data$motherdeath ~ mother.adnat.rankdeath,
                                          #Post-dispersal males are given a large dummy value that will always make them 'lower.ranking'
                                          .data$sex == "male" & .data$dispersal_status == "post_dispersal" ~ 100L,
                                          #Young females with alive mothers use mother rank
                                          .data$sex == "female" & .data$age < 24 & (is.na(.data$motherdeath) | .data$from < .data$motherdeath) ~ mother.adnat.rank,
                                          #Young females with dead mothers use mother rank just before death
                                          .data$sex == "female" & .data$age < 24 & .data$from >= .data$motherdeath ~ mother.adnat.rankdeath,
                                          #Adult females (>= 24mo) use their own rank
                                          .data$sex == "female" & .data$age >= 24 ~ ID.adnat.rank),
                  #We then classify every individual as being top5 or lower.ranking
                  #NOTE: There could be more than 5 individuals classified as top 5 (e.g. alpha female and her immature cubs will all have same top rank)
                  rank_category = ifelse(.data$rank <= 5, "top5", "lower.ranking"),
                  ## Add in all other rank categories (may be useful in other cases and doesn't take long to extract)
                  hyenaR::create_id_rank.table(.data$ID, at = .data$from)) -> monthly.rank.table

  }

  # STEP 6: Extract reproduction information for each individual in each month ####
  message("Determine reproductive success and twinning occurrence of all females...")

  #For every individual, determine their RS during the month
  #We only consider cubs that survived to 6mo
  #If RS >0, they reproduced
  #If RS >=2, they had twin litter
  monthly.rank.table %>%
    dplyr::mutate(RS = hyenaR::fetch_id_number.offspring(.data$ID, from = .data$from, to = .data$to,
                                                         age.min = 6, unit = "month"),
                  repro = ifelse(.data$RS > 0, TRUE, FALSE),
                  twin = ifelse(.data$sex == "female" & .data$RS >= 2, TRUE, FALSE)) -> table.disp.repro

  # STEP 7: Extract first birth date to determine primiparity ####
  message("Identify primiparous females...")

  table.disp.repro %>%
    dplyr::mutate(firstbirth = hyenaR::fetch_id_date.birth.first(ID = .data$ID),
                  primiparous = is.na(.data$firstbirth) | .data$firstbirth >= .data$from) -> full.primiparity.prim.table

  if (dd) {

    # STEP 8: Extract population and clan size each month ####
    message("Extract clan and population size in each month...")

    #Fetch clan and pop size at start of each month
    full.primiparity.prim.table %>%
      #Remove non-main clans
      dplyr::filter(.data$start_clan %in% hyenaR::find_clan_name.all(main.clans = TRUE)) %>%
      #For consistency, we use from date - 1 day to match date at which age, rank, tenure and status and determined
      dplyr::mutate(clan_size = hyenaR::fetch_clan_number(clan = .data$start_clan, at = .data$from - 1, lifestage = "!dead"),
                    pop_size = hyenaR::fetch_pop_number(at = .data$from - 1, lifestage = "!dead")) -> monthly_data

  } else {

    full.primiparity.prim.table %>%
      #Remove non-main clans
      dplyr::filter(.data$start_clan %in% hyenaR::find_clan_name.all(main.clans = TRUE)) %>%
      #When dd estimates are not required, clan and pop size are just returned as NA
      #We keep the cols so that we don't have errors later when selecting columns
      dplyr::mutate(clan_size = NA,
                    pop_size = NA) -> monthly_data

  }

  # STEP 9: Remove unneeded columns ####

  monthly_data %>%
    dplyr::select(-"yr_diff", -"month_diff", -"surv.x", -"surv.y")

}

#' Generate data for fitting models.
#'
#' @param year_margin Numeric. Number of years, starting from the last observation date,
#' that should not be reserved as a test dataset.
#' @param db File path or R6 simulation object. Hyena database to use. Can either be a file path to an .sqlite database
#' or and R6 simulation object.
#' @param dd Logical. Should clan and population size be returned for estimating
#' density dependence? If data is only needed to estimate vital rates at equilibrium
#' removing clan/pop size estimates can greatly speed up data extraction.
#'
#' @return A list with data for different models.
#' @export
generate_model_data <- function(db = file.choose(), year_margin = 0, dd = TRUE){

  if (!requireNamespace("hyenaR", quietly = TRUE)) {
    stop("Package 'hyenaR' is required to generate starting data")
  }

  print("Extracting month level vital rate data")

  monthly_data <- generate_monthly_data(db = db, dd = dd)

  #Subset the data by year
  yr_filter <- monthly_data %>%
    dplyr::filter(!is.na(.data$sex) & .data$year <= (max(.data$year) - year_margin)) %>%
    dplyr::mutate(rank_category = as.factor(.data$rank_category),
                  start_clan = as.factor(.data$start_clan))

  # Extract separated datasets for each model

  # All females ####
  F_surv_data <- yr_filter %>%
    #Filter only females where rank, effort, and age are known
    dplyr::filter(!is.na(.data$rank_category) & .data$sex == "female" & !is.na(.data$age)) %>%
    #Filter out the (very few) cases where a female has changed status during a month
    dplyr::filter(!(.data$status_start != .data$status_end & stringr::str_detect(.data$status_end,
                                                                                 "selector|disperser|immigrant|transient"))) %>%
    #Filter out the last year of data because survival would not be properly estimated
    dplyr::filter(.data$to <= max(.data$to) - lubridate::years(1))

  # Pre-dispersal male survival ####
  PreM_surv_data <- yr_filter %>%
    #Return predispersal males with known age, rank, effort
    #We don't need to exclude the month of selection (where they change status)
    #because this month is included as 'dispersal_status' post-dispersal
    dplyr::filter(!is.na(.data$rank_category) & .data$sex == "male" & !is.na(.data$age) &
                    .data$dispersal_status == "pre_dispersal") %>%
    #Filter out the last year of data because survival would not be properly estimated
    dplyr::filter(.data$to <= max(.data$to) - lubridate::years(1))

  # Post-dispersal male survival ####
  PostM_surv_data <- yr_filter %>%
    #Return post-dispersal males with known age and effort
    dplyr::filter(.data$sex == "male" & !is.na(.data$age) &
                    .data$dispersal_status == "post_dispersal") %>%
    dplyr::mutate(post_dispersal_status = as.factor(.data$post_dispersal_status)) %>%
    #In this case, we need to exclude the month of dispersal (not clear how long they were pre-disperser or post-disperser here)
    #Also exclude the month changing from natal to philo.
    #We don't do this for females because they are still within the same model and status is not included as a model term
    dplyr::filter(!(.data$status_start != .data$status_end & stringr::str_detect(.data$status_end,
                                                                                 "selector|disperser|immigrant|transient|philopatric"))) %>%
    #Filter out the last year of data because survival would not be properly estimated
    dplyr::filter(.data$to <= max(.data$to) - lubridate::years(1))

  # Female reproduction ####
  # Although we are hard-coding start of repro cap at 24mo we include all data
  # So that probabilities are realistically low at 24mo. If we just use 24mo data the probabilities are too high for early ages
  F_repro_data <- yr_filter %>%
    #Return females with known rank, age and effort
    #Exclude females <24mo. This is the earliest we've observed a female produce a >=6mo cub
    #Therefore, we are applying a hard cap to prevent females reproducing earlier.
    dplyr::filter(!is.na(.data$rank_category) & (!is.na(.data$age)) &
                    .data$sex == "female" & !is.na(.data$after1y_effort_all)) %>%
    #Filter out the (very few) cases where a female has changed status during a month
    dplyr::filter(!(.data$status_start != .data$status_end & stringr::str_detect(.data$status_end, "selector|disperser|immigrant|transient"))) %>%
    #Find first (observed) birth date for every individual
    dplyr::group_by(.data$ID) %>%
    dplyr::mutate(first_birth = dplyr::first(.data$from[.data$repro])) %>%
    #Remove all left-censored records that occurred before first observed birth
    #In these cases, we don't know the time since last birth
    dplyr::filter(!(.data$birthdate < lubridate::ymd("1996-05-01") & .data$from <= .data$first_birth)) %>%
    #Group data into IBI groups
    dplyr::mutate(nr_repro = dplyr::lag(cumsum(.data$repro)),
                  nr_repro = tidyr::replace_na(.data$nr_repro, 0L)) %>%
    #Determine when an individual is primiparous
    dplyr::mutate(nonprimi = dplyr::case_when(.data$from <= .data$first_birth | is.na(.data$first_birth) ~ 0L,
                                              TRUE ~ 1L)) %>%
    #For each IBI group determine how many months it has been since last birth
    #For primiparous individuals, month 0 is the month of birth
    #For nonprimiparous individuals, month 0 is the month of last reproduction
    dplyr::group_by(.data$ID, .data$nr_repro) %>%
    dplyr::mutate(months = dplyr::case_when(dplyr::first(.data$nonprimi) == 1 ~ 1:dplyr::n(),
                                            dplyr::first(.data$nonprimi) == 0 ~ as.integer(0:(dplyr::n() - 1) + min(.data$age)))) %>%
    dplyr::ungroup() %>%
    #Females can't reproduce until 4 months (~110 days) after last repro/birth
    #due to the need for a 110 day gestation
    dplyr::filter(.data$months >= 4) %>%
    #Scale data so month 0 is now the first month when reproduction could occur
    dplyr::mutate(months = .data$months - 4L)

  F_repro_primi <- F_repro_data %>%
    dplyr::filter(.data$nonprimi == 0)

  F_repro_nonprimi <- F_repro_data %>%
    dplyr::filter(.data$nonprimi == 1)

  # Female twinning ####
  F_twin_data <- yr_filter %>%
    #Return females that have reproduced with known rank, effort and age
    dplyr::filter(!is.na(.data$rank_category) & .data$sex == "female" & .data$repro &
                    !is.na(.data$after1y_effort_all) & !is.na(.data$age))

  # Male dispersal data ####
  M_second_disp_data <- yr_filter %>%
    dplyr::filter(.data$sex == "male" & .data$birthdate >= hyenaR::find_pop_date.observation.first() & .data$birthclan %in% hyenaR::find_clan_name.all(main.clans = TRUE) & !.data$status_start %in% c("natal", "dead", "cub", "subadult") & !is.na(.data$status_start) & .data$status_end != "dead") %>%
    dplyr::select("ID", "from", "to", "age", "year",
                  "status_start", "status_end", "tenure", "clan_size", "pop_size") %>%
    dplyr::mutate(second_disp = .data$status_start != .data$status_end,
                  is_philo = .data$status_start == "philopatric")

  #Return a list of data
  return(list(raw_data = monthly_data,
              F_surv_data = F_surv_data,
              PreM_surv_data = PreM_surv_data,
              PostM_surv_data = PostM_surv_data,
              F_repro_primi = F_repro_primi,
              F_repro_nonprimi = F_repro_nonprimi,
              F_twin_data = F_twin_data,
              M_second_disp_data = M_second_disp_data))

}
