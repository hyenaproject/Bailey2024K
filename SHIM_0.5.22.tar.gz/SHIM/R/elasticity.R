#' Run elasticity analysis on simulation
#'
#' This function is used for elasticity analysis of the spotted hyena
#' individual-based model (SHIM). For each vital rate model targetted with argument
#' 'focal_mods' two new dummy models will be created. These new models have
#' static fixed and random effect variables, but the intercept will
#' either increase or decrease by a proportion specified with argument 'effect'.
#'
#' Internally, elasticity analysis calls [`simulation_iterate`] so users
#' are able to achieve all the same functionality (e.g. multiple starting populations,
#' multiple iterations). All
#'
#' We can compare the output of these simulations with adjusted models to determine
#' the elasticity of carrying capacity (K) in response to changes in different vital rates.
#' Elasticity is delta log(K)/delta log(vital rate).
#'
#' **NOTE:** Elasticity analysis is only possible using models fitted with
#' [`spaMM::fitme`], where we can use arguments 'etaFix' and 'fixed' to keep
#' all non-intercept model terms constant. Additionally, models with AR1 or
#' Matern terms to deal with temporal and spatial auto-correlation respectively
#' are not yet supported.
#'
#' @param effect Numeric. Change in vital rate intercept in new models. If test_type
#' is 'elasticity', this represents the *proportional* change in model intercepts.
#' If test_type is 'sensitivity', this represents the *absolute* change in model
#' intercepts on the link scale.
#' @param test_type Characters. Either 'elasticity' (default) or 'sensitivity'.
#' Determines how the value of effect is interpreted. An elasticity analysis considers
#' changes on the log scale, such that each model has similar *proportional* change.
#' A sensitivity analysis considers *absolute* changes on the original scale (in this case, model
#' intercepts are in units of the link scale of the model).
#' @param original_models Named list. List of original models that will be changed
#' for elasticity analysis.
#' @param focal_mods Character. Vector of model names for which new models will be made.
#' *NOTE:* Because elasticity is only possible with spaMM models, this argument could be
#' used to skip any models not fitted with spaMM.
#' @param save_dir Folder path. Folder where simulation outputs will be stored.
#' Nested folders will be created for each focal model and for increasing and decreasing
#' vital rates.
#' @param return Logical. Should simulations be returned as a names list (default = FALSE).
#' @param ... All other additional arguments passed to [`simulation_iterate`].
#'
#' @return For each value of 'focal_mods', .txt and .RDS files for each simulation will be save
#' in a folder 'focal_mods/increase' and 'focal_mods/decrease'.
#' If argument 'return' is TRUE. Return a named list of simulation objects
#' for each focal model.
#' @export

simulation_elasticity <- function(effect, test_type = "elasticity",
                                  original_models, focal_mods, save_dir,
                                  return = FALSE, ...) {

  if (!inherits(original_models, "list")) {
    stop("Elasticity analysis requires models to be explicitly defined in a list object.")
  }

  #Identify focal models
  only_focal_mods <- original_models[focal_mods]

  #If any focal models are not spaMM, then exit.
  #By focussing only on focal mods we could have non-spaMM mods if needed
  if (any(!sapply(only_focal_mods, FUN = function(x) inherits(x, "HLfit")))) {
    stop("Elasticity analysis is only possible with focal models fitted with spaMM.")
  }

  #Check that test_type is one of elasticity or sensitivity
  if (!test_type %in% c("elasticity", "sensitivity")) {
    stop("Argument 'test_type' should be either 'elasticity' or 'sensitivity'")
  }

  #Convert effect size to units on log scale...
  effect_size <- if (test_type == "elasticity") log(effect) else effect

  #Now go through each of the focal models and run elasticity analysis!
  sims <- purrr::map(focal_mods,
                     .f = function(mod_name){

                       mod <- original_models[[mod_name]]
                       og_fixef       <- spaMM::fixef(mod)
                       og_intercept   <- og_fixef["(Intercept)"]

                       #Determine new intercept vals from the model
                       #If elasticity, changes are on the log scale
                       if (test_type == "elasticity") {
                         #Determine the sign of the intercept
                         #Needed because we'll have to convert intercept to positive so we can use log scale
                         sign           <- og_intercept/abs(og_intercept)
                         #Intercept changes by units on the log scale equivalent to log(effect)
                         intercept1     <- sign*exp(log(abs(og_intercept)) + effect_size)
                         intercept2     <- sign*exp(log(abs(og_intercept)) - effect_size)
                         #Which one will be an increase or decrease in the focal VR will depend on the original
                         #sign of the model
                         new_intercepts <- c("high" = as.numeric(max(c(intercept1, intercept2))),
                                             "low"  = as.numeric(min(c(intercept1, intercept2))))
                       } else {
                         new_intercepts <- c("high" = og_intercept + effect_size,
                                             "low" = og_intercept - effect_size)
                       }

                       #Do everything twice. Once increase and once decrease
                       output <- purrr::map(.x = c("high", "low"),
                                            .f = function(intercept_type){

                                              new_intercept <- new_intercepts[intercept_type]

                                              new_fixef <- og_fixef
                                              new_fixef["(Intercept)"] <- new_intercept

                                              #If there are random effects add these to the model
                                              if ("lambda" %in% names(mod)) {
                                                ## Do a try catch. If can't find data in env on first try
                                                ## then explicitly use model.frame data.
                                                ## THIS WILL OFTEN STILL FAIL IF e.g. WE HAVE poly() TERM
                                                ## BUT WILL ALLOW US TO PASS TESTS
                                                new_mod <- tryCatch(stats::update(mod,
                                                                                  etaFix = list(beta = new_fixef),
                                                                                  fixed = list(lambda = mod$lambda)),
                                                                    error = function(e){
                                                                      stats::update(mod,
                                                                                    etaFix = list(beta = new_fixef),
                                                                                    fixed = list(lambda = mod$lambda),
                                                                                    data = stats::model.frame(mod))
                                                                    })
                                              } else {
                                                ## Do a try catch. If can't find data in env on first try
                                                ## then explicitly use model.frame data.
                                                ## THIS WILL OFTEN STILL FAIL IF e.g. WE HAVE poly() TERM
                                                ## BUT WILL ALLOW US TO PASS TESTS
                                                new_mod <- tryCatch(stats::update(mod,
                                                                                  etaFix = list(beta = new_fixef)),
                                                                    error = function(e){
                                                                      stats::update(mod,
                                                                                    etaFix = list(beta = new_fixef),
                                                                                    data = stats::model.frame(mod))
                                                                    })
                                              }

                                              #Create a new model list with the new model included
                                              new_modlist <- original_models
                                              new_modlist[[mod_name]] <- new_mod

                                              new_savedir <- paste(save_dir, mod_name, paste(intercept_type, effect, test_type, sep = "_"), sep = "/")

                                              simulation_iterate(models = new_modlist,
                                                                            save_dir = new_savedir,
                                                                            return = return,
                                                                            ...)

                                            })

                       names(output) <- c("high", "low")

                       return(output)

                     })

  names(sims) <- focal_mods

  if (return) {
    return(sims)
  } else {
    return(invisible())
  }

}

#' Run elasticity analysis on simulation rank effects
#'
#' This is an expansion of the original model [`simulation_elasticity`].
#' Rather than adjusting the model *intercept* this function will instead
#' adjust the effect of rank.
#'
#' **NOTE:** Elasticity analysis is only possible using models fitted with
#' [`spaMM::fitme`], where we can use arguments 'etaFix' and 'fixed' to keep
#' all non-intercept model terms constant. Additionally, models with AR1 or
#' Matern terms to deal with temporal and spatial auto-correlation respectively
#' are not yet supported.'
#'
#' **NOTE:** Elasticity analysis on rank expects a model without a reference level
#' for rank (i.e. effect of each rank level is compared to 0, not to each other).
#' This can be achieved by setting intercept to 0 with rank as the earliest category.
#' e.g. y ~ 0 + rank_category
#'
#' @param effect Numeric. Change in vital rate intercept in new models. If test_type
#' is 'elasticity', this represents the *proportional* change in model intercepts.
#' If test_type is 'sensitivity', this represents the *absolute* change in model
#' intercepts on the link scale.
#' @param test_type Characters. Either 'elasticity' (default) or 'sensitivity'.
#' Determines how the value of effect is interpreted. An elasticity analysis considers
#' changes on the log scale, such that each model has similar *proportional* change.
#' A sensitivity analysis considers *absolute* changes on the original scale (in this case, model
#' intercepts are in units of the link scale of the model).
#' @param original_models Named list. List of original models that will be changed
#' for elasticity analysis.
#' @param focal_mods Character. Vector of model names for which new models will be made.
#' *NOTE:* Because elasticity is only possible with spaMM models, this argument could be
#' used to skip any models not fitted with spaMM.
#' @param save_dir Folder path. Folder where simulation outputs will be stored.
#' Nested folders will be created for each focal model and for increasing and decreasing
#' vital rates.
#' @param return Logical. Should simulations be returned as a names list (default = FALSE).
#' @param ... All other additional arguments passed to [`simulation_iterate`].
#'
#' @return For each value of 'focal_mods', .txt and .RDS files for each simulation will be save
#' in a folder 'focal_mods/increase' and 'focal_mods/decrease'.
#' If argument 'return' is TRUE. Return a named list of simulation objects
#' for each focal model.
#' @export

simulation_elasticity.rank <- function(effect, test_type = "elasticity",
                                       original_models, focal_mods, save_dir,
                                       return = FALSE, ...) {

  if (!inherits(original_models, "list")) {
    stop("Elasticity analysis requires models to be explicitly defined in a list object.")
  }

  #Identify focal models
  only_focal_mods <- original_models[focal_mods]

  #If any focal models are not spaMM, then exit.
  #By focussing only on focal mods we could have non-spaMM mods if needed
  if (any(!sapply(only_focal_mods, FUN = function(x) inherits(x, "HLfit")))) {
    stop("Elasticity analysis is only possible with focal models fitted with spaMM.")
  }

  #Check that test_type is one of elasticity or sensitivity
  if (!test_type %in% c("elasticity", "sensitivity")) {
    stop("Argument 'test_type' should be either 'elasticity' or 'sensitivity'")
  }

  #Convert effect size to units on log scale...
  effect_size <- if (test_type == "elasticity") log(effect) else effect

  #Now go through each of the focal models and run elasticity analysis!
  sims <- purrr::map(focal_mods,
                     .f = function(mod_name){

                       mod <- original_models[[mod_name]]
                       og_fixef       <- spaMM::fixef(mod)

                       if (!all(c("rank_categorytop5", "rank_categorylower.ranking") %in% names(og_fixef))) {
                         stop("To test elasticity for rank function expects a model with individual terms for both rank categories...")
                       }

                       og_top5   <- og_fixef["rank_categorytop5"]
                       og_low    <- og_fixef["rank_categorylower.ranking"]

                       #Determine new intercept vals from the model
                       #If elasticity, changes are on the log scale
                       if (test_type == "elasticity") {
                         #Determine the sign of the intercept
                         #Needed because we'll have to convert intercept to positive so we can use log scale
                         sign           <- og_top5/abs(og_top5)
                         #Intercept changes by units on the log scale equivalent to log(effect)
                         top5_1     <- sign*exp(log(abs(og_top5)) + effect_size)
                         top5_2     <- sign*exp(log(abs(og_top5)) - effect_size)
                         #Which one will be an increase or decrease in the focal VR will depend on the original
                         #sign of the model
                         new_top5 <- c("high" = as.numeric(max(c(top5_1, top5_2))),
                                       "low"  = as.numeric(min(c(top5_1, top5_2))))

                         sign           <- og_low/abs(og_low)
                         low_1     <- sign*exp(log(abs(og_low)) + effect_size)
                         low_2     <- sign*exp(log(abs(og_low)) - effect_size)
                         new_low <- c("high" = as.numeric(max(c(low_1, low_2))),
                                      "low"  = as.numeric(min(c(low_1, low_2))))
                       } else {
                         new_top5 <- c("high" = og_top5 + effect_size,
                                       "low" = og_top5 - effect_size)

                         new_low <- c("high" = og_low + effect_size,
                                      "low" = og_low - effect_size)
                       }

                       # For top ranking and low ranking do everything twice
                       output <- purrr::map(.x = c("top5", "lower.ranking"),
                                            .f = function(rank_category){

                                              internal_output <- purrr::map(.x = c("high", "low"),
                                                         .f = function(intercept_type){

                                                           new_fixef <- og_fixef

                                                           if (rank_category == "top5") {
                                                             new_fixef["rank_categorytop5"] <- new_top5[intercept_type]
                                                           } else {
                                                             new_fixef["rank_categorylower.ranking"] <- new_top5[intercept_type]
                                                           }

                                                           #If there are random effects add these to the model
                                                           if ("lambda" %in% names(mod)) {
                                                             ## Do a try catch. If can't find data in env on first try
                                                             ## then explicitly use model.frame data.
                                                             ## THIS WILL OFTEN STILL FAIL IF e.g. WE HAVE poly() TERM
                                                             ## BUT WILL ALLOW US TO PASS TESTS
                                                             new_mod <- tryCatch(stats::update(mod,
                                                                                               etaFix = list(beta = new_fixef),
                                                                                               fixed = list(lambda = mod$lambda)),
                                                                                 error = function(e){
                                                                                   stats::update(mod,
                                                                                                 etaFix = list(beta = new_fixef),
                                                                                                 fixed = list(lambda = mod$lambda),
                                                                                                 data = stats::model.frame(mod))
                                                                                 })
                                                           } else {
                                                             ## Do a try catch. If can't find data in env on first try
                                                             ## then explicitly use model.frame data.
                                                             ## THIS WILL OFTEN STILL FAIL IF e.g. WE HAVE poly() TERM
                                                             ## BUT WILL ALLOW US TO PASS TESTS
                                                             new_mod <- tryCatch(stats::update(mod,
                                                                                               etaFix = list(beta = new_fixef)),
                                                                                 error = function(e){
                                                                                   stats::update(mod,
                                                                                                 etaFix = list(beta = new_fixef),
                                                                                                 data = stats::model.frame(mod))
                                                                                 })
                                                           }

                                                           #Create a new model list with the new model included
                                                           new_modlist <- original_models
                                                           new_modlist[[mod_name]] <- new_mod

                                                           new_savedir <- paste(save_dir, mod_name, "rank", paste(intercept_type, effect, test_type, rank_category, sep = "_"), sep = "/")

                                                           simulation_iterate(models = new_modlist,
                                                                                         save_dir = new_savedir,
                                                                                         return = return,
                                                                                         ...)

                                                         })

                                              names(internal_output) <- c("high", "low")

                                            })

                       return(output)

                     })

  names(sims) <- focal_mods

  if (return) {
    return(sims)
  } else {
    return(invisible())
  }

}
