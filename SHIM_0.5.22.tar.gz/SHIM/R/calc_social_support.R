#' Calculate support in an interaction between two individuals
#'
#' @param focal Character string. Name of focal individual.
#' @param rival Character string. Name of rival individual.
#' @param date The date at which clan occupants are determined
#' @param clan The focal clan
#' @param status_focal Status of focal individual (i.e. Natal = "N" or immigrant  = "M")
#' @param status_rival Status of rival individual (i.e. Natal = "N" or immigrant  = "M")
#' @param hyena Dataframe containing information on all recorded hyena.
#' @param selection Dataframe with information on male dispersal decisions
#'
#' @return A data frame containing the total number of supporters for each individual
#' @export
#'
#' @examples
#' \dontrun{
#' ## FIXME: Old examples. This data no longer available.
#' ## This code and examples need to be updated!!
#' data("hyenas")
#' data("dispersal_records")
#' data("interactions")
#'
#' calc_social_support(focal = interactions$focal[1],
#' rival = interactions$other[1],
#' date = interactions$date[1], clan = interactions$clan_f[1],
#' status_focal = interactions$resid_f[1],
#' status_rival = interactions$resid_o[1],
#' selection = dispersal_records, hyena = hyenas)
#' }

calc_social_support <- function(focal, rival, date, clan, status_focal, status_rival, selection, hyena){

  clan_members <- get_clan_members(date = date, clan = clan, selection = selection, hyena = hyena)

  get_support(focal = focal, rival = rival,
              clan_members = clan_members,
              status_focal = status_focal, status_rival = status_rival,
              hyena = hyena)

}
