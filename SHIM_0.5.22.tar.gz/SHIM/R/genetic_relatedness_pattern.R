
#'Distribution of genetic relatedness in the population

#' @param sim_test the simulation considered
#' @param date the date on which we look at relatedness distribution in the population
#' @param mean_genetic_relatedness mean genetic relatedness in the population
#'
#' @return genetic relatedness between all individuals in the population
#' @export
#'
#'
#library(profvis)


    ## fun
    genetic_relatedness_pattern <- function(sim_test, date, mean_genetic_relatedness) {
       ##get data
      present_data <-
        dplyr::filter(sim_test$Rawdata_tbl, .data$current_date == date)
      nb_ind <- nrow(present_data[ , 1])
      ### calculate genetic relatedness between all individuals
      r_genetic <- vector(mode = "numeric", length = nb_ind * (nb_ind - 1)/2)
      k <- 1
      dnaL <- present_data$dna

      for (i in 1:(nb_ind - 1)) {

          r_genetic[k:(k + nb_ind - i - 1)] <- compute_genetic_relatedness(dnaL[[i]], dnaL[rep((i + 1):nb_ind)], mean_genetic_relatedness)

          k <- k + nb_ind - i + 1
      }
      gen_plot <- ggplot2::ggplot(data = as.data.frame(r_genetic), ggplot2::aes(r_genetic)) +
        ggplot2::geom_histogram()

      return(gen_plot)
    }



#
#
# # measures the excess in the observed number of homozygous genotypes within an individual relative
# # to the mean number of homozygous genotypes expected under random mating: see Kardos et al.2015
# #    Wash and Lynch book 2018
#  relatedness_Fh_index <- function(sim_test, year) {
#    number_homozygote_loci_per_ind <- c()
#    ##get data
#    present_data <-
#      filter(sim_test$Rawdata_tbl, current_year == year)
#    ## we get a matrix containing the sum of the 2 alleles per loci per individuals (row loci , column individuals)
#    ## this sum is latter used to calculate frequency of allele 1 per loci
#      sum_per_loci <- do.call(cbind, lapply(present_data$dna, function(x){
#        rowSums(x)
#      }
#      ))
#  ## we calculate the frequence per loci of allele one in the population
#     frequence_allele_one <-  rowSums(sum_per_loci)/(2*ncol(sum_per_loci))
#  ## expected homozygosie level for all people (formula in Keller et al. 2011)
#     expected_homozygotie <- sum(0 1 - 2*frequence_allele_one*(1 - frequence_allele_one))
#  ## we calculate the number of homozygote loci per individuals
#  ## the column index of homozygote loci indicates individual index
#     homozygote_loci_index <- which(sum_per_loci == 2 | sum_per_loci == 0, arr.ind = TRUE) [,2]
#
#     for (i in 1:nrow(present_data)) {
#       number_homozygote_loci_per_ind[i] <- sum(homozygote_loci_index == i)
#
#     }
#  ## the Fh_index is calculated per individuals
#     Fh_index <- (number_homozygote_loci_per_ind - expected_homozygotie) / (sim_test$loci_number - expected_homozygotie)
#
#     return(Fh_index)
#
#  }
