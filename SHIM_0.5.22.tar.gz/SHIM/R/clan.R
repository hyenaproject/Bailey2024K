#' R6 class recreating a spotted hyena clan
#'
#' `clan` is an [`R6 class`][`R6::R6Class`] within a parent [`simulation`] and
#' [`crater`] object with children [`hyena`] objects.
#'
#' @author Liam D. Bailey
#' @export
#' @examples
#'sim_test <- simulation$new(number_clans = 8,
#'start_clan_size = 20, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE)
#'
#'test_crater <- crater$new(number_clans = 8, start_clan_size = 20,
#'sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test)
#'
#'test_clan <- clan$new(clan_name = "Clan_A", start_clan_size = 20,
#'crater_ID = test_crater, sex_ratio = 0.5, mean_age = 72)
#'
#'test_clan$update_clan()

clan <- R6::R6Class(classname = "clan",
                    public = list(

                      ## Slots for the class attributes #######################################################

                      #'@field clan_name Character. Name of the clan.
                      clan_name = NULL,

                      #'@field size Integer. Size of clan (all alive individuals, including cubs).
                      size = NULL,

                      #'@field total_births Integer. Total number of births that have occurred in the clan.
                      #'Used to assign a value to an individual with the X-001 format
                      #'Each new individual will be given the name 'clan_name-total_births+1'
                      total_births = NULL,

                      #'@field no_young_females Integer. Number of young females in the clan (age > 1yo & age <= 5yo).
                      #'Used to determine probability of male dispersal.
                      no_young_females = NULL,

                      #'@field top_ranking Character. Vector of the top 5 ranked adult individuals in the clan.
                      #'Used in models to identify 'top5' and 'lower.ranking' categories.
                      top_ranking = NA_character_,

                      #'@field deaths Data frame. Number of individuals that have died during the
                      #'current time step (i.e. before being removed in `update_clan`).
                      deaths = dplyr::tibble(cubfem_dead = 0L,
                                             adultfem_dead = 0L,
                                             cubmale_dead = 0L,
                                             philomale_dead = 0L,
                                             dispmale_dead = 0L),

                      #'@field prey Integer. Prey abundance (from 0 - 3 = low - high). Currently ignored.
                      prey = NULL,

                      #'@field inhabitants List. List of child [`hyena`] R6 objects alive in the clan.
                      inhabitants = list(),

                      #'@field inhabitants_tbl Data frame. All individuals in the clan in rank order.
                      #'This is easier to query if we want to e.g. find female position to add new cubs
                      #'or find top ranking individuals.
                      inhabitants_tbl = NULL,

                      #'@field crater_ID R6 object. Parent crater object.
                      crater_ID = NULL,

                      #'@field simulation_ID R6 object. Grandparent simulation object (i.e. crater_ID is
                      #'nested inside simulation_ID).
                      simulation_ID = NULL,

                      ## Slots for the methods stored in the class ####################################################

                      #' @description
                      #' Create a new R6 object of class `clan`.
                      #'
                      #' This functions is used to create the object and all child objects (`hyena`).
                      #'
                      #' @param start_individuals Data frame (optional).
                      #' If NULL (default), [`hyena`] objects are procedurally generated from given demographic parameters.
                      #' If a data frame taken from `start_pop` attribute in the parent [`simulation`], [`hyena`] objects are
                      #' generated with given characteristics.
                      #' @param clan_name Character. Name of clan.
                      #' @param start_clan_size Integer. If `start_individuals` not provided, number of individuals that should be
                      #' generated.
                      #' @param sex_ratio Probability (0-1). If `start_individuals` not provided, probability for each generated individual to be female.
                      #' @param mean_age Numeric (>=0). If `start_individuals` not provided, \eqn{\lambda} value of the Poisson distribution used
                      #' to generate age of individuals.
                      #' @param crater_ID R6 object. Parent [`crater`] object.
                      #'
                      #' @return an object of class `clan`

                      initialize = function(start_individuals = NULL, clan_name, start_clan_size, sex_ratio, mean_age, crater_ID){

                        #Clan_name, size and crater_ID will be provided when generating
                        self$clan_name     <- clan_name
                        self$crater_ID     <- crater_ID
                        self$simulation_ID <- crater_ID$simulation_ID
                        #Prey size is fixed for now
                        self$prey          <- 1

                        #When initialising, start with individual 1
                        self$total_births <- 0

                        #If we are provided with a dataframe of individuals, use this to generate inhabitants
                        if (is.data.frame(start_individuals)) {

                          self$size <- nrow(start_individuals)

                          purrr::walk(.x = 1:nrow(start_individuals),
                                      .f = ~{

                                        focal_indv <- start_individuals[..1, ]

                                        if(!is.null(focal_indv$selections[[1]])) {

                                          self$inhabitants[[..1]] <- hyena$new(ID = focal_indv$ID,
                                                                               birth_date = focal_indv$birth_date,
                                                                               sex = focal_indv$sex,
                                                                               age = focal_indv$age,
                                                                               birth_clan = focal_indv$birth_clan,
                                                                               clan_ID = self,
                                                                               crater_ID = crater_ID,
                                                                               motherID = NULL,
                                                                               fatherID = NULL,
                                                                               first_repro = focal_indv$first_repro,
                                                                               last_repro = focal_indv$last_repro,
                                                                               sib_ID = NULL,
                                                                               stand_rank = focal_indv$rank_std,
                                                                               ord_rank = focal_indv$rank,
                                                                               lifetime_RS = focal_indv$lifetime_RS,
                                                                               first_selection = min(focal_indv$selections[[1]]$date),
                                                                               tenure = focal_indv$tenure)

                                        } else {

                                          self$inhabitants[[..1]] <- hyena$new(ID = focal_indv$ID,
                                                                               birth_date = focal_indv$birth_date,
                                                                               sex = focal_indv$sex,
                                                                               age = focal_indv$age,
                                                                               birth_clan = focal_indv$birth_clan,
                                                                               clan_ID = self,
                                                                               crater_ID = crater_ID,
                                                                               motherID = NULL, fatherID = NULL,
                                                                               last_repro = focal_indv$last_repro,
                                                                               sib_ID = NULL,
                                                                               stand_rank = focal_indv$rank_std,
                                                                               ord_rank = focal_indv$rank,
                                                                               lifetime_RS = focal_indv$lifetime_RS,
                                                                               first_selection = NULL,
                                                                               tenure = focal_indv$tenure)

                                        }

                                      })

                        } else {

                          #When generating data, we use provided clan size
                          self$size <- start_clan_size

                          #Create a number of individuals equal to the specified start size of clans
                          for (j in 1:start_clan_size) {

                            self$total_births <- self$total_births + 1

                            self$inhabitants[[(length(self$inhabitants) + 1)]] <- hyena$new(ID = paste(self$clan_name,
                                                                                                       sprintf("%03d", self$total_births),
                                                                                                       sep = "-"),
                                                                                            #For first individuals, birth date will depend on age (chosen from Poisson dist below)
                                                                                            birth_date = NA,
                                                                                            #Sex is chosen based on specified sex ratio
                                                                                            sex = ifelse(runif(1) <= sex_ratio, "male", "female"),
                                                                                            #Age is selected from Poisson distribution of lambda 6
                                                                                            age = rpois(1, lambda = mean_age),
                                                                                            #Our first individuals don't have known parents
                                                                                            motherID = NULL, fatherID = NULL,
                                                                                            #Assume IBI follows a normal distribution with mean 19.11 and sd 6.64
                                                                                            #This is drawn from distribution of observed IBI where cubs are still alive
                                                                                            #FIXME: last_repro is not IBI it's age at last repro which will increase with actual age...
                                                                                            last_repro = floor(rnorm(1, mean = 19.11, sd = 6.64)),
                                                                                            #Specify clan and crater ID
                                                                                            birth_clan = self$clan_name,
                                                                                            clan_ID = self,
                                                                                            crater_ID = crater_ID,
                                                                                            #No twins are created in the original clan creation
                                                                                            sib_ID = NULL)

                          }

                          #Firstly, rearrange the hyenas by their sex and age
                          #This means that oldest female will be the top ranked.
                          #All females will be higher than males.
                          #Within males, the oldest male will be the highest ranked.
                          #This is probably the closest we can get to a real rank with random data.
                          self$inhabitants <- self$inhabitants[order(sapply(self$inhabitants, '[[', "sex"), -sapply(self$inhabitants, '[[', "age"))]

                          #When we initialise our data we just give a rank that is the order of individuals in the inhabitants object
                          stand_rank <- seq(1, -1, length.out = length(self$inhabitants))
                          ord_rank   <- seq(1, length(self$inhabitants), by = 1)

                          #Assign the rank to each individual in the inhabitants in order
                          purrr::pwalk(.l = list(indv = self$inhabitants, stand_rank = stand_rank, ord_rank = ord_rank),
                                       .f = function(indv, stand_rank, ord_rank){

                                         indv$stand_rank <- stand_rank
                                         indv$ord_rank   <- ord_rank

                                       })

                        }

                        #Determine number of young females in first clan creation (i.e. females where age > 1yo/12mo and <= 5yo/60mo)
                        self$no_young_females <- sum(sapply(self$inhabitants, function(x){

                          x$sex == "female" & x$age > 12 & x$age <= 60


                        }))

                        ## Create inhabitants data frame that is used for easy querying
                        self$inhabitants_tbl <- data.frame(ID = sapply(self$inhabitants, \(ID) ID$ID),
                                                           sex = sapply(self$inhabitants, \(ID) ID$sex),
                                                           age = sapply(self$inhabitants, \(ID) ID$age),
                                                           rank = sapply(self$inhabitants, \(ID) ID$ord_rank),
                                                           std_rank = sapply(self$inhabitants, \(ID) ID$stand_rank),
                                                           natal = sapply(self$inhabitants, \(ID) ID$birth_clan == ID$clan_name))

                      },

                      #' @description
                      #' Update `clan` object after passing time.
                      #'
                      #' This function will:
                      #' \itemize{
                      #'     \item {Dependent cubs who's mother is not alive are also classified as alive = FALSE.}
                      #'     \item {Remove all individuals where alive = FALSE from the `clan` object.}
                      #'     \item {Recalculate clan size and number of young females after individuals.}
                      #' }
                      #' @param record_deaths Logical. Save number of deaths in the `deaths` attribute.
                      #'
                      #' @return Update attributes of `clan` object

                      update_clan = function(record_deaths = FALSE){

                        #STEP 1: Deal with dead individuals ####

                        ## FIXME: This is all a bit of a mess
                        #a) We use 'update_clan' multiple times to e.g. clear dispersers. So we overwrite the deaths table
                        #b) Using 'alive' as a measure of death fails after dispersal because dispersing males are 'killed' in their original clan
                        if (record_deaths){

                          ## STEP 1b: Save 'deaths' table, with all deaths from the current time step ####
                          self$deaths <- dplyr::tibble(cubfem_dead = self$fetch_clan_number.R6(sex = "female",
                                                                                               lifestage = "cub",
                                                                                               .alive = FALSE),
                                                       adultfem_dead = self$fetch_clan_number.R6(sex = "female",
                                                                                                 lifestage = "adult",
                                                                                                 .alive = FALSE),
                                                       cubmale_dead = self$fetch_clan_number.R6(sex = "male",
                                                                                                lifestage = "cub",
                                                                                                .alive = FALSE),
                                                       philomale_dead = self$fetch_clan_number.R6(sex = "male",
                                                                                                  lifestage = "philopatric",
                                                                                                  .alive = FALSE),
                                                       dispmale_dead = self$fetch_clan_number.R6(sex = "male",
                                                                                                 lifestage = "disperser",
                                                                                                 .alive = FALSE))

                        }

                        ## STEP 1c: Remove dead individuals from the clan. ####
                        #Create a vector showing whether or not each individual in the inhabitants list is alive
                        alive <- sapply(self$inhabitants, function(clan_id) {

                          clan_id[["alive"]]

                        })

                        #If there are some dead individuals
                        if (!all(alive)) {

                          #Make these individuals NULL (i.e. they will disappear)
                          self$inhabitants[!alive] <- NULL

                        }

                        #If this means that all individuals are dead...
                        if (length(self$inhabitants) == 0) {

                          #Set the clan size and number of young females to 0 and stop the process (these clans will be removed later) in pass_time
                          self$size <- 0
                          self$no_young_females <- 0

                          return()

                        }

                        #Assuming that some individuals remain...
                        #Recalculate number of young females
                        self$no_young_females <- sum(sapply(self$inhabitants, function(x){

                          x$sex == "female" & x$age > 12 & x$age <= 60


                        }))

                        #Recalculate clan size
                        self$size <- length(self$inhabitants)

                        #If a twin has lost its sibling, make it a singleton
                        for (i in 1:length(self$inhabitants)) {

                          if (!is.null(self$inhabitants$sib_ID) && self$inhabitants$sib_ID$alive == FALSE) {

                            self$sib_ID <- NA
                            self$twin   <- "singleton"

                          }


                        }

                        ## STEP 2: UPDATE RANKS ####
                        # Individuals should be in the right order, but their ord_rank & std_rank traits are wrong.
                        # We should update these now so that they're correct.
                        # At this point, we can also update the top_ranking trait of the clan
                        stand_rank <- seq(1, -1, length.out = length(self$inhabitants))
                        ord_rank   <- seq(1, length(self$inhabitants), by = 1)

                        #Assign the rank to each individual in the inhabitants in order
                        purrr::pwalk(.l = list(ID = self$inhabitants,
                                               stand_rank = stand_rank,
                                               ord_rank = ord_rank),
                                     function(ID, stand_rank, ord_rank){

                                       ID$stand_rank <- stand_rank
                                       ID$ord_rank   <- ord_rank

                                     })

                        ## Determine the top5 individuals
                        sapply(
                          ## Find top 5 adults
                          self$inhabitants[sapply(self$inhabitants, function(x) {
                            x$age >= 24
                          })][1:5],
                          ## Extract a vector of their IDs
                          \(ID) ID[["ID"]]) -> top5_list

                        ## Save this as the top_ranking trait of the clan
                        self$top_ranking <- top5_list

                        ### Update df with all inhabitants that is used for easy querying
                        self$inhabitants_tbl <- data.frame(ID = sapply(self$inhabitants, \(ID) ID$ID),
                                                           sex = sapply(self$inhabitants, \(ID) ID$sex),
                                                           age = sapply(self$inhabitants, \(ID) ID$age),
                                                           rank = sapply(self$inhabitants, \(ID) ID$ord_rank),
                                                           std_rank = sapply(self$inhabitants, \(ID) ID$stand_rank),
                                                           natal = sapply(self$inhabitants, \(ID) ID$birth_clan == ID$clan_name))

                      },

                      #' @description
                      #' Increase age of all individuals in the clan.
                      #'
                      #' Age of all individuals in the clan increases by number of months defined by
                      #' the value of 'step_size' in [`simulation`].
                      #'
                      #' @return Update 'age' attributes of all individuals in the `clan` object.
                      age_clan = function(){

                        ## If clan is empty for any reason, skip all these checks...
                        if (self$size == 0) return(invisible())

                        step_size <- self$simulation_ID$step_size

                        lapply(self$inhabitants, \(ID, step_size){

                          #Individuals age by number of months determined by step_size
                          ID$age <- ID$age + step_size

                          #For males with tenure, increase tenure by number of months determined by step_size
                          if (ID$sex == "male" & !is.null(ID$tenure)) {

                            ID$tenure <- ID$tenure + step_size

                          }

                        }, step_size = step_size)

                        return(invisible)

                      },

                      #' @description
                      #' Simulate survival outcome of all individuals in the clan.
                      #'
                      #' Survival outcome of all individuals is simulated using underlying demographic models.
                      #' The process includes a number of steps:
                      #' \itemize{
                      #'     \item {All individuals >= hyena_max_age in [`simulation`] are killed.}
                      #'     \item {All individuals <6mo will survive (early life survival is integrated into reproduction outcomes).}
                      #'     \item {Survival of all females determined by model 'allF' in the model list.}
                      #'     \item {Survival of all males <24 determined by model 'predispM' in the model list.}
                      #'     \item {Survival of all males >=24 determined by model 'postdispM' in the model list.}
                      #' }
                      #'
                      #' @return Update 'alive' attributes of all individuals in the `clan` object.
                      #' **NOTE:** Individuals that do not survive are not yet removed. This occurs inside `update_clan`.
                      survive_clan = function(){

                        ## If clan is empty for any reason, skip all these checks...
                        if (self$size == 0) return(invisible())

                        ## OLD INDIVIDUALS ####
                        # Old individuals will die regardless (no model needed)
                        old <- self$inhabitants[sapply(self$inhabitants, \(x) x$age >= x$simulation_ID$hyena_max_age)]
                        lapply(old, \(ID){
                          ID$alive <- FALSE
                        })

                        ## FEMALES ####
                        # All females >6mo and below max age are simulated together
                        fem <- self$inhabitants[sapply(self$inhabitants, \(x) x$sex == "female" & x$age >= 6 & x$age < x$simulation_ID$hyena_max_age)]

                        if (length(fem) > 0) {
                          ## Apply every function to the list of females and coerce to a data frame
                          newdata <- lapply(self$simulation_ID$predictors$allF, \(fn){
                            sapply(fem, FUN = fn)
                          }) |>
                            as.data.frame()

                          ## Determine whether indviduals survived...
                          alive_permonth <- simulate_model(object = self$simulation_ID$models$allF,
                                                           objectname = "Female survival",
                                                           newdata = newdata,
                                                           nsim = self$simulation_ID$step_size,
                                                           include_ranef = self$simulation_ID$include_ranef)

                          alive_total <- apply(alive_permonth, 1, \(x) all(x == 1))

                          ## Assign alive value to all individuals
                          mapply(\(ID, alive){ID$alive <- alive}, fem, alive_total)
                        }

                        ## YOUNG MALES ####
                        # All males <24mo are still in their natal clan
                        predispM <- self$inhabitants[sapply(self$inhabitants, \(x) x$sex == "male" & x$age >= 6 & x$age < 24)]

                        if (length(predispM) > 0) {

                          newdata <- lapply(self$simulation_ID$predictors$predispM, \(fn){
                            sapply(predispM, FUN = fn)
                          }) |>
                            as.data.frame()

                          ## Determine whether indviduals survived...
                          alive_permonth <- simulate_model(object = self$simulation_ID$models$predispM,
                                                           objectname = "Male pre-dispersal survival",
                                                           newdata = newdata,
                                                           nsim = self$simulation_ID$step_size,
                                                           include_ranef = self$simulation_ID$include_ranef)

                          alive_total <- apply(alive_permonth, 1, \(x) all(x == 1))

                          ## Assign alive value to all individuals
                          mapply(\(ID, alive){ID$alive <- alive}, predispM, alive_total)

                        }

                        ## OLD MALES ####
                        ## FIXME: RULE OF THREE. THIS SHOULD BE ITS OWN FUNCTION!!
                        # All males >=24mo have made a clan selection
                        postdispM <- self$inhabitants[sapply(self$inhabitants, \(x) x$sex == "male" & x$age >= 24 & x$age < x$simulation_ID$hyena_max_age)]

                        if (length(postdispM) > 0) {

                          newdata <- lapply(self$simulation_ID$predictors$postdispM, \(fn){
                            sapply(postdispM, FUN = fn)
                          }) |>
                            as.data.frame()

                          ## Determine whether indviduals survived...
                          alive_permonth <- simulate_model(object = self$simulation_ID$models$postdispM,
                                                           objectname = "Male post-dispersal survival",
                                                           newdata = newdata,
                                                           nsim = self$simulation_ID$step_size,
                                                           include_ranef = self$simulation_ID$include_ranef)

                          alive_total <- apply(alive_permonth, 1, \(x) all(x == 1))

                          ## Assign alive value to all individuals
                          mapply(\(ID, alive){ID$alive <- alive}, postdispM, alive_total)

                        }

                        return(invisible())

                      },

                      #' @description
                      #' Simulate dispersal outcome of all males in the clan.
                      #'
                      #' Dispersal outcome of all individuals is simulated using underlying demographic models.
                      #' The process includes two steps:
                      #' \itemize{
                      #'     \item {Determine whether males will prospect for new clans.
                      #'     All adult males (>=24mo) that have not previously made a clan selection will prospect.
                      #'     All males that have previously made a clan selection will prospect again with a probability determined by the 'disp' model.}
                      #'     \item {If 'random_dispersal' is TRUE in [`simulation`] then all prospecting males randomly select a clan (including current clan).}
                      #'     \item {If 'random_dispersal' is FALSE in [`simulation`] then clan selection is proportional to number of young females in the clan.}
                      #'     \item {**NOTE:** In both cases, the current clan can be selected meaning that individuals do not leave.}
                      #'     \item {Males that select a new clan are cloned into the inhabitants list of their chosen clan. The original individual has alive = FALSE, to be cleaned up with `update_clan()`.}
                      #' }
                      #'
                      #' @return Create clone of males in new clans. Original individual are set alive = FALSE but not removed until update_clan() is called.
                      disperse_clan = function(){

                        ## If clan is empty for any reason, skip all these checks...
                        if (self$size == 0) return(invisible())

                        ## Calculate number of young females in each clan
                        #N.B. The number of your females are those between 1 - 5yo (Honer et al. 2007).
                        no_young_females_allclans <- sapply(self$crater_ID$clans, \(clan) clan[["no_young_females"]])

                        #We want every clan to have some chance of dispersal.
                        #Therefore, when a clan has 0 young females we will add 1 to it.
                        no_young_females_allclans[no_young_females_allclans == 0] <- 1

                        ## Identify all males that *COULD* prospect (>=24mo, male and alive)
                        ## Do this all together so that we can clone clans just once
                        possible_males <- self$inhabitants[sapply(self$inhabitants, \(ID) ID$alive & ID$sex == "male" & ID$age >= 24 & ID$first_date != self$simulation_ID$date)]

                        young_males_choice <- NULL
                        old_males_choice   <- NULL

                        if (length(possible_males) > 0) {

                          ## Find index for young males
                          young_males_index <- which(sapply(possible_males, \(ID) is.null(ID$first_selection)))

                          ## If there's only 1 clan just ignore the old males (they cannot do anything)
                          if (length(self$crater_ID$clans) == 1) {
                            old_males_index <- NULL
                          } else {
                            ## Find index for old males
                            old_males_index   <- which(sapply(possible_males, \(ID) !is.null(ID$first_selection)))
                          }

                          ## We know the outcome for young males, so we will update their tenure and first selection date
                          if (length(young_males_index) > 0) {

                            lapply(possible_males[young_males_index], \(ID){

                              ID$tenure <- 0
                              ID$first_selection <- self$simulation_ID$date

                            })

                            #Percentage young females is the same for all males!
                            no_young_females_allclans <- no_young_females_allclans/sum(no_young_females_allclans)

                            ## If dispersal is random, just use sample to pick clans
                            if (self$simulation_ID$random_dispersal) {

                              young_males_choice <- sample(seq_len(length(self$crater_ID$clans)), length(young_males_index), replace = TRUE)

                            } else {

                              young_males_choice <- apply(stats::rmultinom(n = length(young_males_index), size = 1, prob = no_young_females_allclans), 2, \(clans) which(clans == 1))

                            }

                          }

                          ## Whether old males will disperse is a stochastic outcome from our model
                          if (length(old_males_index) > 0) {

                            ## For every older male, use predictor information to extract variables
                            newdata <- lapply(self$simulation_ID$predictors$disp, \(fn){
                              sapply(possible_males[old_males_index], FUN = fn)
                            }) |>
                              as.data.frame()

                            ## Determine whether indviduals survived...
                            dispersal_permonth <- simulate_model(object = self$simulation_ID$models$disp,
                                                                 objectname = "Dispersal",
                                                                 newdata = newdata,
                                                                 nsim = self$simulation_ID$step_size,
                                                                 include_ranef = self$simulation_ID$include_ranef)

                            dispersal_total <- apply(dispersal_permonth, 1, \(x) sum(x) >= 1)

                            ## Only include the males that will actually disperse
                            old_males_index <- old_males_index[dispersal_total]

                            ## If at least one male disperses...
                            if (length(old_males_index) > 0) {

                              ## Determine index of current clan to be excluded
                              current_clan <- which(self$crater_ID$all_clan_names == self$clan_name)

                              #Young females excludes the current clan (fix it to be 0)
                              no_young_females_allclans_subset <- no_young_females_allclans
                              no_young_females_allclans_subset[current_clan] <- 0
                              no_young_females_allclans_subset <- no_young_females_allclans_subset/sum(no_young_females_allclans_subset)

                              ## If dispersal is random, just use sample to pick clans
                              if (self$simulation_ID$random_dispersal) {

                                old_males_choice <- sample(seq_len(length(self$crater_ID$clans))[-current_clan], length(old_males_index), replace = TRUE)

                              } else {

                                old_males_choice <- apply(stats::rmultinom(n = length(old_males_index), size = 1, prob = no_young_females_allclans_subset), 2, \(clans) which(clans == 1))

                              }

                            }

                          }

                          ## Move all males into their new clans.
                          ## We can do this all at the same time now by combining young and old males
                          dispersing_males <- possible_males[c(young_males_index, old_males_index)]
                          choice           <- c(young_males_choice, old_males_choice)

                          ## Now that every prospecting male has made a choice, assign them to their new clans
                          #If a male chooses to disperse to a new clan, give it a new first_date and tenure value
                          #If it ends up staying, do not change the value
                          #In this way, philopatric males will still have first_date == birth_date
                          mapply(\(ID, choice){

                            ## Check if the chosen clan matches current clan
                            if (!identical(ID$crater_ID$clans[[choice]], ID$clan_ID)) {

                              ID$first_date <- self$simulation_ID$date
                              ID$tenure     <- 0

                              #If the hyena has moved clans we
                              #also need to change the clan_ID it is associated with
                              ID$clan_ID   <- ID$crater_ID$clans[[choice]]
                              ID$clan_name <- ID$clan_ID$clan_name

                              #We need to create a clone of this individual in the new clan
                              ID$clan_ID$inhabitants[[length(ID$clan_ID$inhabitants) + 1]] <- ID$clone()

                              #The individual left over is "killed" (i.e. alive = FALSE) for later clean-up
                              ID$alive <- FALSE

                            }

                          }, dispersing_males, choice)

                        }

                      },

#' @description
#' Simulate reproduction outcome of all females in the clan.
#'
#' Reproduction outcome of all individuals is simulated using underlying demographic models.
#' The process includes two steps:
#' \itemize{
#'     \item {If no sexually mature males are present in the clan (>=24mo), all females forgo reproduction.}
#'     \item {All females that are >= 'female_first_repro' in [`simulation`] and have been at least 4 months since earliest possible conception (i.e. 110 gestation) may reproduce.}
#'     \item {Reproduction of young females that have not previous reproduced is determined by 'primirepro' model.}
#'     \item {Reproduction of older females that have previously reproduced is determined by 'nonprimirepro' model.}
#'     \item {Mate choice may be random (any males >=24mo), based on relatedness, or the female decision rule.
#'     If no males meet relatedness cut-offs or decision rule, female will forgo reproduction.}
#'     \item {Litter size (1 or 2) is determined by 'twin' model. **NOTE:** We assume the chosen male sires both cubs in a twin litter.}
#'     \item {Cubs are placed in the hierarchy directly below their mother.}
#' }
#'
#' @return Create clone of males in new clans. Original individual are set alive = FALSE but not removed until update_clan() is called.
reproduce_clan = function(){

  ## If clan is empty for any reason, skip all these checks...
  if (self$size == 0) return(invisible())

  ## Find if there are any viable males
  # If there are no viable males there is no point proceeding
  mature_males  <- self$inhabitants[sapply(self$inhabitants, \(ID) ID$sex == "male" & ID$age >= 24)]

  if (length(mature_males) == 0) {
    return(invisible())
  }

  ## First identify all viable females
  # These must be:
  # - Female
  # - Alive
  # - Older than age at first repro
  # - Have at least 4 months since their last repro event (which for primiparous females is their birth)
  sexually_active_fem <- self$inhabitants[sapply(self$inhabitants, \(ID) ID$sex == "female" & ID$alive & ID$age >= ID$simulation_ID$female_first_repro & (ID$age - ID$last_repro) >= 4)]

  ## If there are no viable females then skip...
  if (length(sexually_active_fem) == 0) {
    return(invisible())
  }

  ## Separate primiparous and multiparous females
  primi_index <- which(sapply(sexually_active_fem, \(ID) ID$last_repro == 0))
  multi_index <- which(sapply(sexually_active_fem, \(ID) ID$last_repro > 0))

  ## First, if there are primiparous females determine if they reproduce
  if (length(primi_index) > 0) {

    ## For every primiparous female, use predictor information to extract variables
    newdata <- lapply(self$simulation_ID$predictors$primirepro, \(fn){
      sapply(sexually_active_fem[primi_index], FUN = fn)
    }) |>
      as.data.frame()

    ## Determine whether indviduals survived...
    repro_permonth <- simulate_model(object = self$simulation_ID$models$primirepro,
                                     objectname = "Primiparous reproduction",
                                     newdata = newdata,
                                     nsim = self$simulation_ID$step_size,
                                     include_ranef = self$simulation_ID$include_ranef)

    ## Female has reproduced if ANY months are 1
    repro_total <- apply(repro_permonth, 1, \(x) sum(x) >= 1)

    ## Filter to only include the primi females that actually reproduce
    primi_index <- primi_index[repro_total]

  }

  ## Do the same for multiparous females
  if (length(multi_index) > 0) {

    ## For every multi-parous female, use predictor information to extract variables
    newdata <- lapply(self$simulation_ID$predictors$nonprimirepro, \(fn){
      sapply(sexually_active_fem[multi_index], FUN = fn)
    }) |>
      as.data.frame()

    ## Determine whether indviduals survived...
    repro_permonth <- simulate_model(object = self$simulation_ID$models$nonprimirepro,
                                     objectname = "Multiparous reproduction",
                                     newdata = newdata,
                                     nsim = self$simulation_ID$step_size,
                                     include_ranef = self$simulation_ID$include_ranef)

    ## Female has reproduced if ANY months are 1
    repro_total <- apply(repro_permonth, 1, \(x) sum(x) >= 1)

    ## Filter to only include the primi females that actually reproduce
    multi_index <- multi_index[repro_total]

  }

  ## Take a subset of those that will reproduce (if a male is available)
  reproducing_fem <- sexually_active_fem[c(primi_index, multi_index)]

  ## If nobody will reproduce this timestep then skip
  if (length(reproducing_fem) == 0) return(invisible())

  ## For every reproducing female, use predictor information to extract variables
  newdata <- lapply(self$simulation_ID$predictors$twin, \(fn){
    sapply(reproducing_fem, FUN = fn)
  }) |>
    as.data.frame()

  ## Determine whether indviduals that reproduced have twin litters
  ## NOTE: We only use nsim = 1 here (regardless of step size)
  ## Because we only allow an individual to reproduce once per time step
  twin_permonth <- simulate_model(object = self$simulation_ID$models$twin,
                                  objectname = "Twinning",
                                  newdata = newdata,
                                  nsim = 1L,
                                  include_ranef = self$simulation_ID$include_ranef)

  ## Convert this to number of cubs (so that we can use this as an iterator)
  twin_total <- twin_permonth + 1

  #### SELECT MALES ####
  # At this point, we need to work sequentially so that higher ranking females get first pick
  # The females are already in rank order (because the inhabitants list is in rank order)
  # So we can just run an apply across the list of reproducing individuals.
  mapply(\(ID, littersize){

    #If mating is random, all mature males are suitable!
    if (ID$simulation_ID$random_mating) {
      suitable_males <- mature_males
    } else if (ID$simulation_ID$relatedness == FALSE){
      #Otherwise, if we are not considering relatedness use female mate choice rule
      #(i.e. immigrated or born after female)
      ## 'first_date' is the first date an individual became a clan member
      ## For females and philo males this is their birth datae
      ## for dispersing males, this is their date of arrival
      suitable_males <- mature_males[sapply(mature_males, \(maleID) maleID$first_date > ID$first_date)]
    } else if (ID$simulation_ID$relatedness == TRUE){
      clan_relatedness <- compute_genetic_relatedness(dna_f = ID$genome$dna,
                                                      dna_males = lapply(mature_males, \(maleID){maleID$genome$dna}),
                                                      s_average = ID$crater_ID$mean_genetic_relatedness)
      suitable_males <- mature_males[which(clan_relatedness <= 0)] ## if their relatedness with males are less than the average in the population
    }
    ### FIXME: What about when relatedness = TRUE & random = FALSE
    ## Do we want something where preference is based on relatedness?

    ## If there is at least 1 suitable male...
    if (length(suitable_males) > 0){

      ## Reproduction is now guaranteed, so we can update 'first_repro' value for primi females
      if (ID$last_repro == 0) ID$first_repro <- ID$age
      ## We also update last_repro and RS values
      #last_repro is now current age
      ID$last_repro <- ID$age
      #Add 1 to lifetime reproductive success
      ID$lifetime_RS <- ID$lifetime_RS + littersize

      ## For all suitable males, determine their order of preference...
      # If mating is non-random, females prefer longer tenured males
      if (ID$simulation_ID$random_mating == FALSE) {
        suitable_males <- suitable_males[order(sapply(suitable_males, '[[', i = "tenure"), decreasing = TRUE)]
      } else {
        #If mating is random, preference is totally random
        suitable_males <- sample(suitable_males)
      }

      ## Pick the most preferred male from the set of suitable males
      chosen_male <- suitable_males[[1]]

      #Also updated males reproductive information
      if (is.na(chosen_male$first_repro)) chosen_male$first_repro <- chosen_male$age
      #Add 1 to lifetime reproductive success
      ## FIXME: We assume all twin litters have the same father
      ## do we want to allow for different paternity of siblings?
      chosen_male$lifetime_RS <- chosen_male$lifetime_RS + littersize

      ## Now loop through litter size and create that many cubs
      ## NOTE: I guess this could allow for bigger litter sizes in future if needed
      for (i in seq_len(littersize)) {

        inhabitants_ID <- sapply(self$inhabitants, \(x) x$ID)

        #Update number of births
        #NOTE: Need to do this for each cub individually because it's used to determine the name
        self$total_births <- self$total_births + 1
        new_cub <- hyena$new(ID = paste(self$clan_name,
                                        sprintf("%03d", self$total_births),
                                        sep = "-"),
                             birth_date = self$simulation_ID$date,
                             sex = if (stats::runif(1) <= self$simulation_ID$sex_ratio) "female" else "male",
                             age = 0, last_repro = 0,
                             motherID = ID,
                             fatherID = chosen_male,
                             birth_clan = self$clan_name,
                             clan_ID = self, crater_ID = self$crater_ID,
                             ## FIXME: Current process doesn't allow us to assign sibling ID. Is this needed?
                             ## Is it enough to just know second sib is always subordinate?
                             sib_ID = NULL)

        new_cub$twin <- if (i == 1) "dominant" else "subordinate"

        #Add this new offspring to the list of clan inhabitants
        self$inhabitants <- append(self$inhabitants, values = new_cub,
                                   ## If it's the first cub, append after mother
                                   ## If it's the second cub, append 1 after mother (below it's sibling)
                                   ## This also fits with our dominance ranking
                                   after = which(ID$ID == inhabitants_ID) + i - 1)
      }
    }

    return(invisible())

  }, reproducing_fem, twin_total)

  return(invisible())

},

#' @description
#' Update prey attribute of `clan` object.
#'
#' Update prey attribute. Currently ignored and unused.
#'
#' @return Update prey attribute of `clan` object

update_prey = function(){

  #For now, prey is fixed
  self$prey <- 1

},

#' @description
#' Return individuals of given sex/lifestage in `clan`.
#'
#' @param sex Character. "male", "female", or "all".
#' @param lifestage Character. "cub" (<24mo),
#' "adult" (>= 24mo), "philopatric" (>= 24mo and not yet
#' dispersed from birthclan), "disperser" (>= 24mo and
#' has dispersed from birthclan), or "all". Note: Individuals that
#' leave birthclan and return will be 'disperser'.
#' @param .alive Logical. For internal use only.
#' TRUE (default), return alive individuals.
#' FALSE, return dead individuals. Used for counting
#' deaths before clearing dead individuals from the clan.
#'
#' @return Character vector. List of IDs of individuals
#' with given sex/lifestage.

find_clan_id.R6 = function(sex = "all", lifestage = "all",
                           .alive = TRUE){

  sex_func <- switch(sex,
                     male = function(x){x$sex == "male"},
                     female = function(x){x$sex == "female"},
                     all = function(x){TRUE})

  lifestage_func <- switch(lifestage,
                           cub = function(x){x$age < 24},
                           adult = function(x){x$age >= 24},
                           philopatric = function(x){x$age >= 24 & x$first_date == x$birth_date},
                           disperser = function(x){x$age >= 24 & x$first_date > x$birth_date},
                           all = function(x){TRUE})

  sapply(self$inhabitants, function(individual){

    if (sex_func(individual) & lifestage_func(individual) & individual$alive == .alive) {

      return(individual$ID)

    } else {

      return(NULL)

    }

  }) %>%
    unlist()

},

#' @description
#' Return number of individuals of given sex/lifestage
#' in `clan`.
#'
#' Count length of output from `find_clan_id.R6`
#'
#' @param sex Character. "male", "female", or "all".
#' @param lifestage Character. "cub" (<24mo),
#' "adult" (>= 24mo), "philopatric" (>= 24mo and not yet
#' dispersed from birthclan), "disperser" (>= 24mo and
#' has dispersed from birthclan), or "all". Note: Individuals that
#' leave birthclan and return will be 'disperser'.
#' @param .alive Logical. For internal use only.
#' TRUE (default), return alive individuals.
#' FALSE, return dead individuals. Used for counting
#' deaths before clearing dead individuals from the clan.
#'
#' @return Integer. Number of individuals
#' with given sex/lifestage.

fetch_clan_number.R6 = function(sex = "all", lifestage = "all",
                                .alive = TRUE){

  length(self$find_clan_id.R6(sex = sex, lifestage = lifestage,
                              .alive = .alive))

},

#' @description
#' Find IDs of parents that have reproduced in current
#' time step.
#'
#' Return IDs of mothers and/or father of cubs with age 0
#' (i.e. born this timestep).
#'
#' @param sex Character. "male", "female", or "all".
#'
#' @return Character vector. List of IDs of parents.

find_clan_id.parent.R6 = function(sex = "all") {

  all_parents <- sapply(self$inhabitants, function(individual, sex){

    output <- NULL

    if (individual$age == 0) {

      if (sex %in% c("female", "all")) {

        output <- append(output, individual$motherID$ID)

      }

      if (sex %in% c("male", "all")) {

        output <- append(output, individual$fatherID$ID)

      }

    }

    return(output)

  }, sex = sex) %>%
    unlist()

  unique(all_parents)

},

#' @description
#' Return number of parents that have reproduced in
#' current time step.
#'
#' Return number of mothers and/or father
#' for cubs with age 0 (i.e. born this timestep).
#'
#' @param sex Character. "male", "female", or "all".
#'
#' @return Integer. Number of new parents.

fetch_clan_number.parent.R6 = function(sex = "all") {

  length(self$find_clan_id.parent.R6(sex = sex))

}))
