#' Forest plot of sensitivity analysis
#'
#' Shows variation of each summary statistic around its overall mean
#' @param output Output of function \code{\link{sensitivity_func}}
#'
#' @export

sensitivity_forestplot <- function(output){

  #Create original data
  #First, melt the data so we have a single row for each summary stat at each parameter level
  z_score_data <- output %>%
    tidyr::pivot_longer(cols = -"focal_var", names_to = "variable") %>%
    #Remove any infinite values (possible for ratios)
    dplyr::filter(!is.infinite(.data$value)) %>%
    #Save this temporarily as we'll need it later
  {{. -> temp} %>%
      #Group by summary statistic
      dplyr::group_by(.data$variable) %>%
      #Determine the overall mean of each summary stat
      dplyr::summarise(variable_mean = mean(.data$value, na.rm = T)) %>%
      #Now join this back to our temp file with right join
      #Now we have a row for each summary stat at each parameter level AND the overall mean for that summary stat
      dplyr::right_join(temp, by = "variable", multiple = "all") %>%
      #Subtract variable means to create z-scores for each summary stat
      dplyr::mutate(z_score = .data$value - .data$variable_mean) %>%
      #Once again group by summary stat
      dplyr::group_by(.data$variable) %>%
      #Finally, determine the mean and SE of the z-score of each summary stat over all simulations
      dplyr::summarise(mean_z = mean(.data$z_score, na.rm = T),
                SD = stats::sd(.data$z_score, na.rm = T))} %>%
    #Put data in the order of how much it varies w/ parameter change
    dplyr::arrange(.data$SD)

  output_plot <- ggplot2::ggplot(z_score_data)+
    ggplot2::geom_errorbar(ggplot2::aes(x = .data$variable, ymin = .data$mean_z - .data$SD, ymax = .data$mean_z + .data$SD), width = 0, size = 1)+
    ggplot2::geom_point(ggplot2::aes(x = .data$variable, y = .data$mean_z), shape = 21, size = 3, fill = "dark grey")+
    ggplot2::geom_hline(yintercept = 0, lty = 2, size = 1)+
    ggplot2::theme_classic() +
    ggplot2::coord_flip()

  return(output_plot)

}
