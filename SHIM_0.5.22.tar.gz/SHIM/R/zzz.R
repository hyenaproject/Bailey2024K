# Assign global vars to deal with RCMDChecks
utils::globalVariables(c(".", ".data"))

.onUnload <- function(libpath) {
  library.dynam.unload("SHIM", libpath)
}

## Help doc for fitting models
#' Model fitting tips for SHIM
#'
#' @description
#' Information on demographic model structure and model fitting tips.
#'
#' @details
#' SHIM uses 7 underlying demographic models to simulate spotted hyenas. These models encompass:
#' \itemize{
#'    \item {Female survival}
#'    \item {Pre-dispersal male survival}
#'    \item {Post-dispersal male survival}
#'    \item {Primiparous female reproduction}
#'    \item {Multiparous female reproduction}
#'    \item {Twin litter probability}
#'    \item {Male secondary dispersal}
#'}
#'
#'Information about each of these models and how they are used inside the simulation is provided
#'below.
#'
#'## Model parameters
#'
#'Demographic models used in SHIM can use a specific set of model parameters that are available
#'as traits of the [`hyena`] object used inside the simulation. Other parameter names are not possible
#'aand will lead to errors when running simulations.
#'
#'Possible parameters are:
#' \itemize{
#'    \item {`start_clan`: (character) The clan an individual was in at the beginning of a time step.
#'    **Note:** Male survival is estimated before dispersal, so will only ever be affected by this start clan.}
#'    \item {`age`: (numeric) The age in months of an individual.}
#'    \item {`rank_category`: (character) Either 'top5' or 'lower_ranking' to define the rank of an individual.}
#'    \item {`before1y_effort_all`: (numeric) Value between 0 and 1 to specify the average monthly observation effort
#'    in the year before an observation. This can be useful to consider in model fitting,
#'    but observation effort is assumed to be perfect (1) within the simulation.}
#'    \item {`after1y_effort_all`: (numeric) Value between 0 and 1 to specify the average monthly observation effort
#'    in the year after an observation. This can be useful to consider in model fitting,
#'    but observation effort is assumed to be perfect (1) within the simulation.}
#'    \item {`pop_size`: (numeric) Number of individuals in the entire population.}
#'    \item {`clan_size`: (numeric) Number of individuals in an individual's clan.}
#'    \item {`year`: (numeric or character) The year of observation. Can be fitted as either continous term
#'    or a random effect.}
#'    \item {`post_dispersal_status`: (character) For individuals that have dispersed, are they in their natal clan ("philo")
#'    or not ("disp"). Irrelevant for female models because females do not disperse in our simulation.}
#'    \item {`is_philo`: (logical) Is an individual philopatric (TRUE) or not (FALSE).
#'    Irrelevant for female models because females do not disperse in our simulation.}
#'    \item {`months`: (numeric) Months since a new birth event was possible.
#'    Irrelevant for male models.}
#'}
#'
#'## Female survival model
#'
#'Used to simulate survival outcomes for **all** females >=6mo (survival before 6mo is incorporated into
#'reproduction models). Maximum lifespan is hard-coded with the simulation trait `hyena_max_age`.
#'This is fixed at 25yo by default (see LINK for more detail).
#'Survival of individuals is the first outcome of each simulation time-step.
#'
#'## Pre-dispersal male survival model
#'
#'Used to simulate survival outcomes for males >=6mo but before their first clan selection.
#'Although in males may make their first clan selection after they are sexually mature (i.e. older than 24mo),
#'SHIM assumes all males will make a clan selection at 24mo after which their survival is determined by the
#'post-dispersal male survival model. Survival of individuals is the first outcome of each simulation time-step.
#'
#'## Post-dispersal male survival model
#'
#'Used to simulate survival outcomes for males after their first clan selection.
#'SHIM assumes all males will make a first clan selection at 24mo.
#'Maximum lifespan is hard-coded with the simulation trait `hyena_max_age`.
#'This is fixed at 25yo by default (see LINK for more detail).
#'Survival of individuals is the first outcome of each simulation time-step.
#'
#'## Primiparous female reproduction
#'
#'Used to simulate birth events for primiparous females. In the simulation, a birth event is
#'a female giving birth to a cub that survives to at least 6mo. Therefore, the reproduction
#'model will encompass both reproduction and cub-life survival.
#'
#'The model parameter 'months' can be useful to model female reproduction. In the case
#'of primiparous females, 'months' will represent months since first possible birth event could have occurred.
#'The first possible birth event is considered to be at 4mo (given a 110 gestation period if female conceived straight away).
#'
#'**NOTE:** Designating a minimum age at first reproduction is difficult, and this definition of
#'first possible birth event considered for the 'months' term is deliberately anti-conservative.
#'To make primiparous reproduction more restricted the minimum age at first reproduction can be hard-coded
#'using the simulation trait `female_first_repro`.
#'This is fixed at 24mo by default (see LINK for more detail.)
#'
#'## Multiparous female reproduction
#'
#'Used to simulate birth events for multiparous females (i.e. after their first birth).
#'In the simulation, a birth event is a female giving birth to a cub that survives to at least 6mo.
#'Therefore, the reproduction model will encompass both reproduction and cub-life survival.
#'
#'The model parameter 'months' can be useful to model female reproduction. In the case
#'of multiparous females, 'months' will represent months since a new birth event was possible.
#'The birth event is assumed to be possible 4mo after the previous birth event
#'(110 gestation period if female conceived straight away after her last birth).
#'
#'## Twin litter probability
#'
#'For females that *do* give birth, used to simulate litter size. We only consider two potential litter sizes
#'(1 or 2), so 'twinning' can be modelled as a binomial outcome.
#'
#'## Male secondary dispersal
#'
#'For males that have made a first clan selection (>24mo), used the simulate new dispersal events.
#'
#'## Default models and fitting new models
#'
#'If a named list of models is not provided when a simulation object is initialized, the simulation will
#'use a set of basic demographic models that are fitted to data from 1997-1999.
#'**These default models are not intended for analysis only for demonstration.** To use SHIM
#'properly, more robust demographic models should be provided. Data to fit models
#'can be generated using the function `generate_model_data()`. These new models can be added to
#'SHIM as a named list using the 'models' argument, as seen below:
#'
#'```
#'model_list <- list(allF = fem_survival_mod,
#'                   predispM = predispmale_survival_mod,
#'                   postdispM = postdispmale_survival_mod,
#'                   primirepro = primifem_repro_mod,
#'                   nonprimirepro = nonprimifem_repro_mod,
#'                   twin = twin_mod,
#'                   disp = disp_mod)
#'```
#'
#' @name models
NULL

## Help doc for using predictors
#' Using custom model predictors in SHIM
#'
#' @description
#' Details on how to use the 'predictors' argument in SHIM.
#'
#' @details
#' SHIM accepts multiple model structures and complex predictors; however, to work
#' with more complex models the user will need to specify how predictor used in the
#' models can be calculated. This is achieved with the 'predictors' argument.
#'
#' ## Default predictors
#'
#' When the predictors argument is NULL (default), SHIM will use a set of default predictors
#' that are used within the default models (see [`models`]). These default predictors are:
#'
#' \itemize{
#'    \item {age: age in months}
#'    \item {rank_category: Rank of the individual. Either 'top5' (in the top 5 adult individuals in the hierarchy)
#'    or 'lower.ranking' (all other individuals).}
#'    \item {rank_category_mother: Rank of an individual's mother. Either 'top5' or 'lower.ranking'.
#'    When mother is unknown, rank category of the individual is used.}
#'    \item {clan_size: Number of individuals in the clan.}
#'    \item {year: Account for difference in vital rates between years.}
#'    \item {after1y_effort_all: Average observation effort in the 1 year following observation.
#'    This is particularly useful for reproduction models where observation effort will affect the
#'    chance of spotting a young cub.}
#'    \item {is_philo: Whether an individual is philopatric or has dispersed from its natal clan.}
#'}
#'
#' ## Custom predictors
#'
#' ### Global predictors
#'
#' If predictors other than the defaults are needed, the used will need to specify
#' custom predictors as a named list of functions.
#' Each list item should correspond to a single model predictor and should be a function
#' that accepts an R6 object of class hyena and outputs a single value.
#' For example, the below list could be provided to 'predictors' to define the
#' 'age' and 'clan' model predictors.
#'
#' ```
#' predictors = list(age = function(ID) ID$age,
#'                   clan = function(ID) ID$clan_name)
#' ```
#'
#' ### The 'keep.defaults' argument
#'
#' By default, custom predictors will be added to the existing list of default predictors
#' available inside SHIM. When custom predictors and default predictors share the same name
#' the custom predictor will be used. This can be convenient if a user wants to change
#' only one of the default predictors (e.g. year) and keep all others the same; however,
#' this may also be computationally inefficient if we include predictors that are not
#' needed in the models. If default predictors should be ignored, the argument 'keep.defaults'
#' should be set to FALSE.
#'
#' ```
#' ## Use age and clan as well as existing default predictors
#' simulation$new(predictors = list(age = function(ID) ID$age,
#'                                  clan = function(ID) ID$clan),
#'                keep.defaults = TRUE)
#'
#' ## Use age and clan predictors ONLY
#' simulation$new(predictors = list(age = function(ID) ID$age,
#'                                  clan = function(ID) ID$clan),
#'                keep.defaults = FALSE)
#' ```
#'
#' ### Model specific predictors
#'
#' In the above example, the predictors 'age' and 'clan' will be used for
#' *every* model. This is often the most convenient approach because predictors
#' are often shared between models.
#' However, sometimes a user may want to specify predictors for each
#' model individually. In this case, the user provide multiple named lists,
#' one for each model. For example, in the following list we use age in years
#' for the female survival model and months for other models, except dispersal where
#' age is not used at all.
#'
#' ```
#' predictors = list(allF = list(age = function(ID) ID$age/12),
#'                   predispM = list(age = function(ID) ID$age),
#'                   postdispM = list(age = function(ID) ID$age),
#'                   primirepro = list(age = function(ID) ID$age),
#'                   nonprimirepro = list(age = function(ID) ID$age),
#'                   twin = list(age = function(ID) ID$age),
#'                   disp = list())
#' ```
#'
#' By specifying predictors for each model separately we can work with more complex
#' model structures that have many different predictors. We can also avoid the need
#' to extract unused predictors for specific models (such as the dispersal model
#' above).
#'
#' ## Advanced predictors
#'
#' The predictors argument requires functions that take an R6 object of class hyena;
#' however, models may also use clan or crater level information to simulate demographic outcomes.
#' Clan or crater objects can be accessed from the hyena object through the traits `clan_ID`
#' and `crater_ID`. For example, to include a predictor for number of young females in the clan
#' we would use the following function:
#'
#' ```
#' predictors = list(clan_size = function(ID) ID$clan_ID$no_young_females)
#' ```
#'
#' See the help documentation of [`clan`] and [`crater`] for details on the available
#' traits.
#'
#' @name predictors
NULL
