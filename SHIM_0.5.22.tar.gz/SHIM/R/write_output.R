#'Update the output_tbl (Rawdata_tbl, Adult_tb, Deaths_tbl, Hyenas_tbl)
#'
#'@param self the runned simulation (environment)
#'
#'@return self the runned simulation with some attributes changed
#'@export
#'
#'@examples
#' sim_test <- simulation$new(number_clans = 5,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE)
#'
#' sim_test$run_sim(number_steps = 2)
#'
#' write_output(sim_test)

write_output <- function(self){

  #Compile the raw data on all individuals
  self$Rawdata_tbl  <- do.call(rbind, self$crater$snapshot_data)

  save_data <- self$Rawdata_tbl

  #Save final date of simulation
  final_date <- max(save_data$current_date)

  #Create the Hyenas_tbl for all individuals
  self$Hyenas_tbl <- save_data %>%
    #Group by individual
    dplyr::group_by(.data$ID) %>%
    #Save information on sex...
    dplyr::reframe(sex = dplyr::first(.data$sex),
                   #Save the birth clan
                   birthclan = dplyr::first(.data$clan),
                   #Save birth date
                   birthdate = dplyr::first(.data$birth_date),
                   #Save information on mother
                   #We do not allow for adoption atm, so genetic and social are the same
                   mothergenetic = dplyr::first(.data$mother),
                   mothersocial = dplyr::first(.data$mother),
                   #Save information on father
                   father = dplyr::first(.data$father),
                   DNA = 0L,
                   litterdominancegenetic = NA_integer_,
                   name2 = NA_character_, deathconfirmed = NA_character_,
                   deathcause = NA_character_, comments = NA_character_,
                   date_lastsighting = dplyr::last(.data$current_date))

  if (sum(!is.na(self$Rawdata_tbl$mother)) > 0) {

    #Determine litter dominance of twin litters (older one is always considered dominant)
    #For now we just use birthdate and ID (would be more effective to add in the raw data somewhere)
    litterdom <- self$Rawdata_tbl %>%
      #Only consider individuals where the motherID is known
      dplyr::filter(!is.na(.data$mother)) %>%
      #Take the first record of every individual
      dplyr::group_by(.data$ID) %>%
      dplyr::slice(1) %>%
      #For all individuals with the same mother and birthdate
      #Give them a litter dominance
      dplyr::group_by(.data$mother, .data$birth_date) %>%
      dplyr::mutate(litterdominance = 1:dplyr::n()) %>%
      dplyr::ungroup() %>%
      dplyr::select("ID", "litterdominance")

    self$Hyenas_tbl <- self$Hyenas_tbl %>%
      dplyr::left_join(multiple = "all", litterdom, by = "ID") %>%
      dplyr::select("ID":"father", "litterdominance", dplyr::everything())

  } else {

    self$Hyenas_tbl <- self$Hyenas_tbl %>%
      dplyr::mutate(litterdominance = NA_integer_) %>%
      dplyr::select("ID":"father", "litterdominance", dplyr::everything())

  }

  #Create the Deaths_tbl for all individuals
  self$Deaths_tbl <- save_data %>%
    #Group by individual
    dplyr::group_by(.data$ID) %>%
    dplyr::reframe(deathdate = dplyr::if_else(dplyr::last(.data$current_date) < final_date,
                                              dplyr::last(.data$current_date) + months(self$step_size),
                                              as.Date(NA))) |>
    dplyr::filter(!is.na(.data$deathdate)) %>%
    dplyr::select("ID", "deathdate")

  #Create the Adults_tbl
  self$Adults_tbl <- self$Hyenas_tbl %>%
    dplyr::left_join(multiple = "all", self$Deaths_tbl, by = "ID") %>%
    #If the individual was born >2years before the end of the study then give it an adult date
    dplyr::mutate(ID = .data$ID,
                  sex = .data$sex,
                  dateadult = dplyr::if_else((.data$birthdate + lubridate::years(2)) > final_date, as.Date(NA), .data$birthdate + lubridate::years(2)),
                  deathdate = .data$deathdate,
                  mothergenetic = .data$mothergenetic,
                  mothersocial = .data$mothersocial,
                  DNA = .data$DNA, .keep = "none") %>%
    #Remove all individuals that have no adult date (i.e. they were still cubs when the study finished)
    dplyr::filter(!is.na(.data$dateadult))

  #Extract names of clans
  self$Clans_tbl <- dplyr::tibble(clanID = unique(save_data$clan),
                                 clanname = NA_character_,
                                 location1 = "floor",
                                 location2 = NA_character_,
                                 latitude = NA_real_,
                                 longitude = NA_real_)

  ## Dispersal events where individual moves clan
  disperser_males <- save_data %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::mutate(prev_clan = dplyr::lag(.data$clan)) %>%
    dplyr::ungroup() %>%
    dplyr::filter(.data$clan != .data$prev_clan) %>%
    dplyr::select("ID", origin = "prev_clan",
                  destination = "clan", date = "current_date") %>%
    dplyr::arrange(.data$ID, .data$date)

  ## Philo males are those that are still in birth clan at 24
  ## NOTE: This code works because all males are hard-coded to mature and prospect
  ## for new clans at 24mo.
  ## If age at maturity were flexible, we would need an attribute/column 'age_at_maturity'
  ## to identify philo males.
  philo_males <- save_data %>%
    dplyr::filter(.data$sex == "male" & .data$age == 24 & .data$clan == .data$birth_clan) %>%
    dplyr::select("ID", origin = "birth_clan",
                  destination = "clan", date = "current_date") %>%
    dplyr::arrange(.data$ID, .data$date)

  self$Selections_tbl <- dplyr::bind_rows(disperser_males,
                                          philo_males) |>
    dplyr::arrange(.data$date)

  #Extract selection information
  if (!is.null(self$start_pop)) {

    start_selections <- self$start_pop %>%
      dplyr::select("ID", "selections") %>%
      tidyr::unnest(col = "selections")

    self$Selections_tbl <- self$Selections_tbl %>%
      dplyr::bind_rows(start_selections)

  }

  #Create sightings table
  self$Sightings_tbl <- save_data %>%
    dplyr::mutate(date_time = lubridate::ymd_hm(paste(.data$current_date, "00:00", sep = " ")),
                  latitude = NA_real_, longitude = NA_real_,
                  denname = NA_character_, habitat = NA_character_,
                  age = ifelse(.data$age >= 24, 'ad', 'cub'),
                  sex = .data$sex,
                  remarks = NA_character_,
                  ID = .data$ID, name2 = NA_character_,
                  clanID = .data$clan, denstop = NA_character_,
                  prey = NA_character_,
                  obsstart = format(.data$date_time, "%H:%M"), obsstop = format(.data$date_time, "%H:%M"),
                  sucklingID = NA_character_, denhole = NA_character_,
                  injuryID = NA_character_, earR = NA_character_, earL = NA_character_,
                  altitude = NA_real_, waypoint = NA_character_,
                  observer = NA_character_) %>%
    ## Col order matches in hyena data
    dplyr::select(c("date_time", "latitude", "longitude", "denname", "habitat",
                    "age", "sex", "remarks", "ID", "name2", "clanID", "denstop",
                    "prey", "obsstart", "obsstop", "sucklingID", "denhole", "injuryID",
                    "earR", "earL", "altitude", "waypoint", "observer"))

  #Create snaptshots table
  self$Snapshots_tbl <- save_data %>%
    dplyr::filter(.data$current_date == min(.data$current_date)) %>%
    dplyr::mutate(selection = NA_character_) %>%
    dplyr::select(date = "current_date",
                  "clan",
                  rank = "ord_rank",
                  "ID",
                  "selection")

  self$Rankchanges_tbl <- dplyr::tibble(date = as.Date(NA),
                                       clan = NA_character_,
                                       ID = NA_character_,
                                       higher = NA_character_,
                                       lower = NA_character_,
                                       description = NA_character_,
                                       reason = NA_character_)

  self$Rawdata_tbl <- save_data

  ##Also create .database object that can be manipulated using hyenaR functions
  message("\nYou can use hyenaR to work with the simulated data. Look at the function 'load_package_database.sim()'.")

  return(self)
}
