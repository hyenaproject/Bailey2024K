#' Determine social support numbers of two competing individuals
#'
#' @param focal Character string. Name of focal individual.
#' @param rival Character string. Name of rival individual.
#' @param clan_members List of clan members with ancestry. Output from
#'   get_ancestry.
#' @param status_focal Status of focal individual (i.e. Natal = "N" or immigrant
#'   = "M")
#' @param status_rival Status of rival individual (i.e. Natal = "N" or immigrant
#'   = "M")
#' @param hyena Dataframe containing information on all recorded hyena.
#'
#' @export
#' @examples
#' \dontrun{
#' ## FIXME: Old examples. This data no longer available.
#' ## This code and examples need to be updated!!
#' data("hyenas")
#' data("dispersal_records")
#' data("interactions")
#'
#' clan_list <- get_clan_members(date = interactions$date[1], clan =
#' interactions$clan_f[1], selection = dispersal_records, hyena = hyenas)
#' support_values <- get_support(focal = interactions$focal[1], rival =
#' interactions$other[1], clan_members = clan_list, status_focal =
#' interactions$resid_f[1], status_rival = interactions$resid_o[1], hyena =
#' hyenas)
#'
#' support_values
#' }

get_support <- function(focal, rival, clan_members, status_focal, status_rival, hyena) {

  #### WE ARE CALCULATING THIS FOR EACH INDIVIDUAL COMMON ANCESTOR AS THEY COME UP!!
  #### THIS SHOULD SPEED THINGS UP AS MANY HYENA WILL NOT BE THE COMMON ANCESTOR IN A FIGHT AND SO WE WON'T NEED TO ESTIAMTE
  #### THOUGH MAYBE THEY WILL SOMETIMES BE THE COMMON ANCESTOR MORE THAN ONCE AND WE'RE DOUBLING UP COMPUTATION???
  #### LEAVE THIS FOR OPTIMISATION
  #Add age rank of offspring into hyena data
  hyena <- hyena %>%
    dplyr::group_by(.data$mothersocial) %>%
    dplyr::do(., dplyr::mutate(., offspring_rank = rank(as.Date(.$birthdate), ties.method = "average"))) %>%
    dplyr::ungroup()

  #Return all the known maternal ancestors for both the focal and rival individual
  focal_line <- clan_members[clan_members$ID %in% focal, c(1, 4:9)] %>%
    dplyr::select_if(~ !any(is.na(.)))
  rival_line <- clan_members[clan_members$ID %in% rival, c(1, 4:9)] %>%
    dplyr::select_if(~ !any(is.na(.)))

  #If there is at least one individual shared in the maternal ancestry.
  #Return the first common ancestor
  common_ancestor <- if(sum(focal_line %in% rival_line) > 0) {

    focal_line[which(focal_line %in% rival_line)][1]

    } else {

      NA

    }

  #For the common ancestor, determine all her offspring and their rank (by age)
  common_ancestor_offspring <- hyena %>%
    dplyr::ungroup() %>%
    dplyr::filter(.data$mothersocial %in% common_ancestor) %>%
  #%>% mutate(offspring_rank = rank(as.Date(birthdate, format = "%Y-%m-%d"), ties.method = "average")) %>%
    dplyr::select("ID", "offspring_rank") %>%
    dplyr::arrange(.data$offspring_rank)

  #Determine the rank of offspring of the common ancestor which belongs to the maternal lineage of the focal individual
  #e.g. they share a grandma, but they have different mothers. What was the rank of the mother (based on age)
  focal_ancestor_rank <- common_ancestor_offspring[as.character(common_ancestor_offspring$ID) %in% focal_line, 2]

  #Do the same for the rival
  rival_ancestor_rank <- common_ancestor_offspring[as.character(common_ancestor_offspring$ID) %in% rival_line, 2]

  ##DETERMINE HOW NON-INVOLVED INDIVIDUALS SHOULD RESPOND
  ##N.B. This was previously a function, but it is only ever done once in the code so I don't see that as necessary.

  #If the two individuals do not have a common ancestor
  #The function makes no decision
  if (is.na(common_ancestor)) {
    Priority <- Subordinate <- Sub_line <- NA
    Relationship <- "Unrelated"
    #Otherwise, if A is a maternal ancestor of B
  } else if (focal %in% rival_line) {
    #Then A is superior to B
    Priority = focal
    Subordinate = rival
    Sub_line = rival_line
    Relationship = "Focal_>>_Rival"
    #Otherwise, if B is a maternal ancestor of A
  } else if (rival %in% focal_line) {
    #Then B is superior to A
    Priority = rival
    Subordinate = focal
    Sub_line = focal_line
    Relationship = "Focal_<<_Rival"
    #Otherwise
  } else {
    #If the rank of the divergent ancestor of the focal and rival individuals is equal (i.e. they were twins)
    if (focal_ancestor_rank == rival_ancestor_rank) {
      #Then they cannot be distinguished.
      #The winner cannot be determined
      Priority <- Subordinate <- Sub_line <- NA
      Relationship <- "FocalAncestor_==_RivalAncestor"
      #If they are NOT twins
    } else {
      #The individual with the higher ranked ancestor is superior.
      if (focal_ancestor_rank > rival_ancestor_rank){

        Priority <- focal
        Subordinate <- rival
        Sub_line <- rival_line
        Relationship <- "FocalAncestor_>_RivalAncestor"

      } else {

        Priority <- rival
        Subordinate <- focal
        Sub_line <- focal_line
        Relationship <- "FocalAncestor_<_RivalAncestor"

      }
    }
  }

  #Determine the common choice between individuals A and B (i.e. what an individual should do if it's related to both)
  #CC <- common_choice(A, B, X)
  #Save the winning individual as Choice
  #Choice <- CC[[1]]
  #Save the losing individual as XX
  #XX <- CC[[2]]
  #Save the lineage of the loser as XX_line
  #XX_line <- CC[[3]]
  #Save the comparison (i.e. A>B, B=A)
  #A_B <- CC[[4]]

  #### Now, use all this information to get the choice of C
  #Create a new list of individuals in the clan that are not involved in the fight
  observers <- clan_members %>%
    dplyr::filter(!(.data$ID %in% focal | .data$ID %in% rival))

  #For every individual, determine whether it has any maternal ancestors that are also in the maternal lineage of the focal or rival individual
  #N.B. This means that the individual could be either the ancestor OR desendant (or in the same generation) as one of the two competing individuals.
  #We just checked to see if their ancestor etc. fell SOMEWHERE in the matriline.
  #e.g. For the offspring of the focal individual, their grandma would be in the matriline of focal as the mum.

  #Conduct for focal
  observers$related_focal <- apply(observers, 1, function(x){

    any(x[4:9] %in% focal_line)

  })

  #Conduct for rival
  observers$related_rival <- apply(observers, 1, function(x){

    any(x[4:9] %in% rival_line)

  })

  #Find individuals that were related to ONLY one of the interacting pair
  single_relative <- observers[(observers$related_focal + observers$related_rival) == 1, ]
  #single_relative <- observers[(observers$sumA == T & observers$sumB == F ) | (observers$sumA == F & observers$sumB == T), ]
  #For these individuals, they always choose their relative
  single_relative$choice <- ifelse(single_relative$related_focal, focal, rival)

  #Create a subset for all the other individuals that shared a common ancestor with both competing individuals
  #N.B. This is cases where they are a common ancestor NOT where they ARE the common ancestor of A and B.
  both_relatives <- observers[(observers$related_focal + observers$related_rival) == 2, c(1, 4:9)]

  #Now determine the number of supporters each individual should get.
  #If the focal individual has immigrated...
  if (status_focal == "M") {
    #Determine all those individuals that were born in the current clan (i.e. their birth clan == this clan)
    #the number of individuals that would support the focal will be ONLY those that are unrelated to the rival
    #The rival gets the support of all the natives
    return(data.frame(focal = focal, rival = rival,
                      support_focal = sum(single_relative$choice %in% focal, na.rm = T),
                      support_rival = sum(observers$birthclan == observers$currentclan, na.rm = T),
                      relationship = Relationship))

    #If the rival is an immigrant
  } else if (rival == "M") {
    #Determine all those individuals that are from the current clan.
    #The focal individual gets the support of ALL natives
    #The rival individual only gets support when an individual is related to them and not the focal.
    return(data.frame(focal = focal, rival = rival,
                      support_focal = sum(observers$birthclan == observers$currentclan, na.rm = T),
                      support_rival = sum(single_relative$choice %in% rival, na.rm = T),
                      relationship = Relationship))

    #Otherwise, if there is no clear reason for support via ancestory
    #Either they are unrelated OR their is a twin conflict
    #Then the supporters of each individual are just the ones that are completely unrelated to the other.
    #We assume every other individual abstains because the choice is unclear.
  } else if (is.na(Priority)) {
    return(data.frame(focal = focal, rival = rival,
                      support_focal = sum(single_relative$choice %in% focal, na.rm = T),
                      support_rival = sum(single_relative$choice %in% rival, na.rm = T),
                      relationship = Relationship))

    #However, if there is a clear winner by ancestory and neither are immigrants...
  } else {
    #Determine if the losing individual appears in the maternal ancestery of any clan members
    #i.e. is an individual the offspring of the subordinate.
    #These individuals will abstain.
    both_relatives$rival_descendant <- purrr::imap_lgl(both_relatives$ID, ~ sum(Subordinate %in% both_relatives[.y, ])>= 1)

    #Determine those individuals that are the direct ancestors of the subordinate individual
    both_relatives$rival_ancestor <- both_relatives$ID %in% Sub_line

    #Create a subset for those individuals that are not direct descendents or ancestors of the subordinate individual.
    TT <- both_relatives %>%
      dplyr::filter(!(.data$rival_descendant | .data$rival_ancestor))
    #Create a subset for those individuals that are direct ancestors of the subordinate.
    Ancestors <- both_relatives[both_relatives$rival_ancestor == T, ]

    #Of those individuals that are not direct descendents or ancestors, who is the common ancestor to the subordinate?
    TT$Y <-  purrr::imap_chr(TT$ID, ~ as.character(Sub_line[which(Sub_line %in% TT[.y, ])][1]))

    #Determine all offspring of the shared ancestor.
    Y_sons <- TT %>%
      dplyr::group_by(.data$Y) %>%
      dplyr::do(., hyena[hyena$mothersocial %in% .$Y, c("ID", "offspring_rank")])
    #Save the rank of the individual that are in the lineage of the subordinate
    threshold <- Y_sons %>%
      dplyr::group_by(.data$Y) %>%
      dplyr::summarise(threshold = .data$offspring_rank[.data$ID %in% Sub_line],
                                                     ID = .data$ID[.data$ID %in% Sub_line]) %>%
      dplyr::ungroup()

    #Determine whether offspring of the common ancestor was a higher or lower rank than the offspring of the common ancestor of the subordinate individual
    TT$threshold <- purrr::imap_lgl(TT$Y, ~ Y_sons$offspring_rank[Y_sons$Y %in% TT$Y[.y] & Y_sons$ID %in% TT[.y, 1:7]] > threshold$threshold[threshold$Y == TT$Y[.y]])

    ## count the results:
    Ancestors$choice <- ifelse(Ancestors$rival_ancestor == T, Priority)
    TT$choice <- ifelse(TT$threshold, Priority, NA)

    return(data.frame(focal = focal, rival = rival,
                      support_focal = sum(c(single_relative$choice, Ancestors$choice, TT$choice) %in% focal, na.rm = T),
                      support_rival = sum(c(single_relative$choice, Ancestors$choice, TT$choice) %in% rival, na.rm = T),
                      relationship = Relationship))
  }
}
