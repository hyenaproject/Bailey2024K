
#'Calculate social support

#'Before individuals have dispersed, reproduced, aged etc. we can calculate social support.
#'We are doing this BEFORE they disperse etc, because otherwise there will be individuals who have dispersed, reproduced etc. that aren't yet included in the snapshot
#'The snapshot is only taken just before the next passage of time (see above)
#'N.B. Is this can ideal approach? We are using an external function, rather than an inbuilt method?
#'For now, we will include it as a separate function, but maybe later include as a method inside clan
#'@param self the crater (environment)
#'@return update self$individual_social_support
#'@export
#'

social_support<- function(self){
  #At this stage, I'm going to include an argument to turn on or off social support.
  #This allows us to understand how much it is slowing down calculations.

  #N.B. When using the social support calculations for the simulation, we DON'T need to estimate clan members etc.
  #We already know who dispersed etc. so many of the regular calculations in get_clan_members are irrelevant (e.g. who is alive).
  #For now, we subset out the clan list manually and then use the get_support function.

  #Bind together all old snapshot data
  #This needs to be done to determine the maternal ancestry of each individual.
  #We can't do this just from motherID in the clan inhabitants list because once an individual dies they are removed from the sim
  #The only record of them is therefore in the old snapshots data taken at the time.
  hyena_history <- dplyr::bind_rows(self$snapshot_data) %>%
    #Group by individual
    dplyr::group_by(.data$ID) %>%
    #Save information on birthdate...
    dplyr::summarise(birthdate = .data$birth_date[1],
              #Save information on mother
              mothersocial = as.character(.data$mother[1])) %>%
    #Turn year values into date columns.
    #If it is an integer, make it 1/1/YYYY. Otherwise, make it 1/7/YYYY
    dplyr::mutate(birthdate = ifelse((.data$birthdate %% 1) == 0.5, paste(floor(.data$birthdate), "-7-1", sep = ""), paste(.data$birthdate, "-1-1", sep = "")))

  for (clan_no in 1:length(self$clans)) {

    #Make a list of all possible individuals that could interact in the clan and their maternal ancestry
    clan_members <- do.call(rbind, lapply(self$clans[[clan_no]]$inhabitants, function(x){

      data.frame(ID = x$ID, focal = x$ID, rival = x$ID,
                 birthclan = x$birth_clan, currentclan = self$clans[[clan_no]]$clan_name,
                 age = x$age) %>%
        dplyr::mutate(M = subset(hyena_history, .data$ID == x$ID)$mothersocial,
               GM = ifelse(!is.na(.data$M), subset(hyena_history, .data$ID == .data$M)$mothersocial, NA),
               GGM = ifelse(!is.na(.data$GM), subset(hyena_history, .data$ID == .data$GM)$mothersocial, NA),
               GGGM = ifelse(!is.na(.data$GGM), subset(hyena_history, .data$ID == .data$GGM)$mothersocial, NA),
               GGGGM = ifelse(!is.na(.data$GGGM), subset(hyena_history, .data$ID == .data$GGGM)$mothersocial, NA),
               GGGGGM = ifelse(!is.na(.data$GGGGM), subset(hyena_history, .data$ID == .data$GGGGM)$mothersocial, NA),
               status = ifelse(.data$birthclan == .data$currentclan, "N", "M"))

    })) %>%
      dplyr::filter(.data$age > 1) %>%
      dplyr::select(-"age")

    clan_members$ID        <- as.character(clan_members$ID)
    clan_members$birthclan   <- as.character(clan_members$birthclan)
    clan_members$currentclan <- as.character(clan_members$currentclan)

    #Create a data frame of all possible interactions between all individuals and their status (i.e. M = immigrant, N = natal)
    #The outcome of an interaction between two individuals will be the same regardless of which is rival and which is focal.
    #Therefore, we don't want to use expand.grid, but instead use combinations from gtools package.
    interactions <- as.data.frame(gtools::combinations(n = length(unique(clan_members$ID)),
                                               r = 2, v = unique(clan_members$ID))) %>%
      dplyr::rename(focal = "V1", rival = "V2") %>%
      dplyr::left_join(multiple = "all", dplyr::select("clan_members", "focal", "status"), by = "focal") %>%
      dplyr::rename(status_focal = "status") %>%
      dplyr::left_join(multiple = "all", dplyr::select("clan_members", "rival", "status"), by = "rival") %>%
      dplyr::rename(status_rival = "status")

    clan_members <- dplyr::select("clan_members", -"focal", -"rival")

    #Determine social support for every individual against every other individual
    social_support_value <- purrr::map_df(.x = 1:nrow(interactions),
                                          .f = ~{

                                            get_support(focal = interactions$focal[..1],
                                                        rival = interactions$rival[..1],
                                                        clan_members = clan_members,
                                                        status_focal = interactions$status_focal[..1],
                                                        status_rival = interactions$status_rival[..1],
                                                        hyena = hyena_history)

                                          })

    #Get an average social support value for each individual
    indv_avg_support <- rbind(social_support_value %>%
                                dplyr::select("focal", "support_focal") %>%
                                dplyr::rename(ID = "focal", support = "support_focal"),
                              social_support_value %>%
                                dplyr::select("rival", "support_rival") %>%
                                dplyr::rename(ID = "rival", support = "support_rival")) %>%
      dplyr::group_by(.data$ID) %>%
      dplyr::summarise(avg_support = mean(.data$support))

    if (clan_no == 1) {

      self$indv_avg_support = indv_avg_support

    } else {

      self$indv_avg_support = rbind(self$indv_avg_support, indv_avg_support)

    }

  }

  self$snapshot_data[[length(self$snapshot_data)]] <- dplyr::left_join(multiple = "all", self$snapshot_data[[length(self$snapshot_data)]],
                                                                self$indv_avg_support, by = "ID")

  return(self)

}
