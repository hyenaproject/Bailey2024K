#' Adjust parameters input into our simulation model and look at how it affects the summary statistics
#'
#' @param nsim Number of simulations to be run at each value of X (our focal variable)
#' @param number_steps Number of steps for simulation to be run (length of time step is specified in step_size)
#' @param step_size Size of each time step (months)
#' @param number_clans Number of clans created in each simulation
#' @param start_clan_size Initial size of all clans in each simulation
#' @param sex_ratio Sex ratio of all clans in each simulation
#' @param mean_age Mean age of clans at the start of each simulation
#' @param variable_df Data frame containing all the parameter values use for the simulation (in order of variables in infusion_runsim)
#' @param seed Integer. Seed of the current simulation.
#'
#' @export
#'
#' @examples
#'\dontrun{
#'#Vary the sex ratio.
#'
#'input_df <- data.frame(sex_ratio = c(0.25, 0.5, 0.75))
#'
#'sensitivity_result <- sensitivity_func(variable_df = input_df)
#'}

sensitivity_func <- function(nsim = 10, number_steps = 10, step_size = 6, number_clans = 8,
                             start_clan_size = 20, sex_ratio = 0.5, mean_age = 72,
                             variable_df = NULL, seed = 123){

  overall_output <- purrr::map_df(.x = 1:nrow(variable_df),
                                  .f = function(rownr){

                                    output <- purrr::map_df(.x = 1:nsim,
                                                  .f = function(sim){

                                                    sim_output <- infusion_runsim(number_steps = number_steps,
                                                                                  step_size = step_size,
                                                                                  number_clans = number_clans,
                                                                                  start_clan_size = start_clan_size,
                                                                                  sex_ratio = sex_ratio,
                                                                                  mean_age = mean_age,
                                                                                  seed = seed)

                                                    sim_output

                                                  })

                                    output

                                  })

  # plot_data <- overall_output %>%
  #   tidyr::pivot_longer(cols = -"focal_var", names_to = "variable")
  #
  # output_plot <- ggplot2::ggplot(plot_data) +
  #   ggplot2::geom_violin(ggplot2::aes(x = as.factor(.data$focal_var), y = .data$value),
  #                        fill = NA, colour = "black", size = 1) +
  #   ggplot2::geom_boxplot(ggplot2::aes(x = as.factor(.data$focal_var), y = .data$value),
  #                         fill = "dark grey", colour = "black", width = 0.1) +
  #   ggplot2::facet_wrap(~.data$variable, scales = "free") +
  #   ggplot2::theme_classic()
  #
  # print(output_plot)

  return(overall_output)

}
