#' Run hyena simulation with defined parameter estimates for infusion.
#'
#' @param number_steps Number of steps for simulation to be run (length of time step is specified in step_size)
#' @param step_size Size of each time step (months)
#' @param number_clans Number of clans generated in the simulation
#' @param start_clan_size Starting size of all clans
#' @param sex_ratio Starting sex ratio of all clans
#' @param mean_age Mean age of individuals in all clans
#' @param seed Integer. Seed of the current simulation.
#'
#' @export
#' @examples
#' \dontrun{
#' ## Infusion is old code and not guaranteed to run
#'infusion_runsim(number_steps = 2, step_size = 6, number_clans = 5, start_clan_size = 10,
#'sex_ratio = 0.5, mean_age = 72)
#' }


infusion_runsim <- function(number_steps, step_size, number_clans, start_clan_size,
                            sex_ratio, mean_age,
                            seed = 123){

  #Create simulation object with parameters provided
  sim <- simulation$new(step_size = step_size,
                        number_clans = number_clans, start_clan_size = start_clan_size,
                        sex_ratio = sex_ratio, mean_age = mean_age,
                        seed = seed)

  #Run the simulation with these new variables
  sim$run_sim(number_steps = number_steps)

  #Calculate median age of death for males and females
  death_age <- sim$Hyenas_tbl %>%
    dplyr::left_join(multiple = "all", sim$Deaths_tbl, by = "ID") %>%
    dplyr::filter(!is.na(.data$deathdate)) %>%
    dplyr::mutate(death_age = as.numeric(.data$deathdate - .data$birthdate)/365) %>%
    dplyr::filter(.data$death_age >= 2) %>%
    dplyr::group_by(.data$sex) %>%
    dplyr::summarise(median_death = stats::median(.data$death_age),
                     sd_death = stats::sd(.data$death_age),
                     # skew_death = e1071::skewness(.data$death_age)[1]
                     )

  #Calculate LRS for females (we exclude males because of incomplete knowledge of paternity in real data)
  #Only consider cubs that reach >2yo
  sim_LRS_F <- sim$Rawdata_tbl %>%
    dplyr::filter(!is.na(.data$mother) & .data$age >= 24) %>%
    dplyr::group_by(.data$mother) %>%
    dplyr::summarise(LRS = length(unique(.data$ID)))

  #Sex ratio of adults (>2yo)
  sex_ratio_all <- sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date) %>%
    dplyr::summarise(Number_cubs    = length(which(.data$age < 24)),
                     Number_females = length(which(.data$age >= 24 & .data$sex == "female")),
                     Number_males   = length(which(.data$age >= 24 & .data$sex == "male"))) %>%
    dplyr::mutate(sex_ratio = .data$Number_females/.data$Number_males)

  #Male dispersal info
  no_clans <- sim$Rawdata_tbl %>%
    dplyr::filter(.data$sex == "male") %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::summarise(no_clans = sum(diff(as.numeric(.data$clan)) != 0))

  #Average annual clan cub:adult ratio
  cub_ratio <- sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date, .data$clan) %>%
    dplyr::summarise(cub_ratio = length(which(.data$age < 24))/length(which(.data$age >= 24))) %>%
    dplyr::summarise(annual_cub_ratio = mean(.data$cub_ratio))

  #Average 6 month clan sizes
  clan_size <- sim$Rawdata_tbl %>%
    dplyr::group_by(.data$current_date, .data$clan) %>%
    dplyr::summarise(clan_size = dplyr::n()) %>%
    dplyr::summarise(mean_size_time = mean(.data$clan_size),
                     max_size_time  = max(.data$clan_size))

  #Output our important summary stats
  data.frame(med_male_death  = death_age$median_death[1],
             sd_male_death   = death_age$sd_death[1],
             skew_male_death = death_age$skew_death[1],
             med_fem_death   = death_age$median_death[2],
             sd_fem_death    = death_age$sd_death[2],
             skew_fem_death  = death_age$skew_death[2],
             median_fem_LRS  = stats::median(sim_LRS_F$LRS),
             sd_fem_LRS      = stats::sd(sim_LRS_F$LRS),
             # skew_fem_LRS    = e1071::skewness(sim_LRS_F$LRS),
             max_fem_LRS     = max(sim_LRS_F$LRS),
             mean_sex_ratio  = mean(sex_ratio_all$sex_ratio),
             sd_sex_ratio    = stats::sd(sex_ratio_all$sex_ratio),
             # skew_sex_ratio  = e1071::skewness(sex_ratio_all$sex_ratio),
             mean_no_disp    = mean(no_clans$no_clans),
             sd_no_disp      = stats::sd(no_clans$no_clans),
             # skew_no_disp    = e1071::skewness(no_clans$no_clans),
             max_no_disp     = max(no_clans$no_clans),
             mean_cub_ratio  = mean(cub_ratio$annual_cub_ratio),
             sd_cub_ratio    = stats::sd(cub_ratio$annual_cub_ratio),
             # skew_cub_ratio  = e1071::skewness(cub_ratio$annual_cub_ratio),
             max_age_male    = max(dplyr::filter(sim$Rawdata_tbl, .data$sex == "male")$age),
             max_age_fem     = max(dplyr::filter(sim$Rawdata_tbl, .data$sex == "female")$age),
             mean_clan_size  = mean(clan_size$mean_size_time),
             max_clan_size   = max(clan_size$max_size_time))

}
