#' calculate pedigree relatedness

#' These functions allow to calculate pedigree relatedness between individuals
#' @param IDs vectors of IDs
#' @param hyena_tbl hyenas table from simulation
#' @param .ancestor type of ancestor to look for (e.g. "mothergenetic", "mothersocial", "father")
#' @return a data.frame with the generation and Ids of ancestors
#' @examples



#' ################find_ancestors
#'
#'@describeIn pedigree_relatedness Return a vector of all ancestor for the given ID(s)
#' @examples
#' \dontrun{
#' rm(list = ls())
#' # Load data (use dummy dataset)
#' load_database()
#' find_ancestors(IDs = "A-243")
#' find_ancestors(ID = c("A-243", "A-001"))
#'
#' hyenas <- extract_database("hyenas")
#' find_ancestors("A-243", hyenas)
#' find_ancestors("A-243", as.data.frame(hyenas))
#'}
find_ancestors <- function(IDs,
                           hyena_tbl,
                           .ancestor =  "mothergenetic") {
  d <- list(IDs)

  i <- 1
  while (sum(!is.na(d[[i]])) > 0) {
    d[[i + 1]] <- hyena_tbl[match(d[[i]], hyena_tbl$ID), .ancestor, drop = TRUE]
    i <- i + 1
  }

  c(stats::na.omit(unlist(d)))
}


#################################################################
#' calculate_relatedness
#'
#'
#'
#' @param ID1 name of one ind
#' @param ID2 name of another ind
#' @param ancestor which kind of ancestor one want to climb up
#' @return a coefficient of relatedness
#' @describeIn pedigree_relatedness Calculate the ralatedness between 2 ID(s)
#' @export
#' @examples
#' \dontrun{
#' load_database()
#' hyenas <- extract_database("hyenas")
#' calculate_relatedness(ID1 = "A-084", ID2 = "A-010", hyena_tbl = hyenas, ancestor = "mothergenetic")
#'}
calculate_relatedness <- function(ID1, ID2, hyena_tbl, ancestor) {
  line_A <- find_ancestors(ID1, hyena_tbl = hyena_tbl, .ancestor = ancestor)
  line_B <- find_ancestors(ID2, hyena_tbl = hyena_tbl, .ancestor = ancestor)
  ## no common ancestor:
  if (length(base::intersect(line_A, line_B)) == 0) return(NA)

  ## common ancestor(s):
  steps_to_A_ancestor <- which(line_A %in% line_B)[1] - 1
  steps_to_B_ancestor <- which(line_B %in% line_A)[1] - 1
  0.5^(steps_to_A_ancestor + steps_to_B_ancestor)
}


#' @describeIn pedigree_relatedness create a tidy table with individuals and their relatedness.
#'
#' @export
#' @examples
#'\dontrun{
#' #### Simple example of create_offspringtable usage:
#' load_database()
#' create_relatednesstable(c("A-001", "L-003", "A-100"))
#'}
create_relatednesstable <- function(IDs, hyena_tbl){

  ## create an empty matrix with output number of rows and 2 col
  input <- matrix(NA_character_, nrow = (length(IDs) * (length(IDs) - 1 )) / 2, ncol = 2)
  colnames(input) <- c("ID1", "ID2")

  ## add the IDs
  k <- 1
  for (i in 1:(length(IDs) - 1)) {
    for (j in (i + 1):length(IDs)) {
      input[k, 1] <- IDs[i]
      input[k, 2] <- IDs[j]
      k <- k + 1
    }
  }
  ## and turn into a df
  output <- tibble::as_tibble(input)

  ## calculate the relededness using the calculate
  output <- output %>%
    dplyr::mutate(relatedness =
             furrr::future_pmap_dbl(list(output$ID1, output$ID2), ~ (calculate_relatedness(..1, ..2,
                                                                                          hyena_tbl = hyena_tbl, ancestor = "mothergenetic"))+calculate_relatedness(..1, ..2,
                                                                                                                                                                   hyena_tbl = hyena_tbl, ancestor = "father")))

  return(output)
}




