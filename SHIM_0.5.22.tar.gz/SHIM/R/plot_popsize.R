#' Create a ggplot of total population size
#'
#' @param sim Object of class \code{\link{simulation}}. Must be following the method run_sim().
#' @param type Should population size be plotted as a line graph ("line") or area graph ("area")
#'
#' @return Produces a ggplot showing change in population sizes over time.
#' @export
#' @examples
#' set.seed(666)
#' sim_test <- simulation$new(number_clans = 2,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72)
#'
#' sim_test$run_sim(number_steps = 2)
#' plot_popsize(sim_test, type = "line")

plot_popsize <- function(sim, type = "area"){

  if ("pop_size" %in% colnames(sim$Rawdata_tbl)) {

    sim_data <- sim$Rawdata_tbl %>%
      dplyr::mutate(year = lubridate::year(lubridate::ymd(date))) %>%
      dplyr::select("date", total = "pop_size", "year")

  } else {

    sim_data <- sim$Rawdata_tbl %>%
      dplyr::mutate(date = .data$current_date) %>%
      dplyr::group_by(.data$date) %>%
      dplyr::summarise(total = dplyr::n()) %>%
      dplyr::mutate(year = lubridate::year(.data$date))

  }

  if (type == "line") {

    ggplot2::ggplot(sim_data) +
      ggplot2::geom_line(ggplot2::aes(x = .data$date, y = .data$total),
                         size = 1, lty = 2) +
      ggplot2::geom_point(ggplot2::aes(x = .data$date, y = .data$total),
                          size = 3, shape = 21, fill = "dark grey") +
      ggplot2::theme_classic() +
      ggplot2::scale_y_continuous(limits = c(0, NA))

  } else {

    ggplot2::ggplot(sim_data) +
      ggplot2::geom_area(ggplot2::aes(x = .data$date, y = .data$total),
                         size = 1, colour = "black") +
      ggplot2::theme_classic() +
      ggplot2::scale_y_continuous(limits = c(0, NA))

  }

}

#' Plot population size of multiple simulations.
#'
#' Create a single plot with population size of multiple simulations.
#' Takes saved simulation objects as an input.
#'
#' @param sim_files Character vector. File path of all save simulations.
#' @param burnin Integer. Number of years to remove when plotting simulations.
#'
#' @return ggplot showing change in population sizes over time.
#' @export
#'
#' @examples
#' \dontrun{
#'
#' simulation_iterate(i = 25, number_steps = 5, number_clans = 8, CPUcores = 4,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72,
#' save_size = 1, save_dir = ".")
#'
#' sim_files <- list.files(path = ".", pattern = ".txt")
#'
#' #Show all data
#' plot_popsize.all(sim_files = sim_files, burnin = 0)
#'
#' #Cut first year
#' plot_popsize.all(sim_files = sim_files, burnin = 1)
#'
#' }
plot_popsize.all <- function(sim_files, burnin = 0) {

  if (!inherits(sim_files, what = "character")) {

    stop("Requires a vector of files paths.")

  }

  if (!all(stringr::str_detect(sim_files, pattern = ".txt") | all(stringr::str_detect(sim_files, pattern = ".RDS")))) {

    stop("Plotting function expects txt or RDS files.")

  }

  plot_data <- purrr::imap_dfr(.x = sim_files,
                           .f = function(path, index){

                             if (stringr::str_detect(path, pattern = ".txt")) {

                               output <- utils::read.csv(path, sep = ",") %>%
                                 dplyr::mutate(date = as.Date(date),
                                               sim_number = as.character(index))

                             } else if (stringr::str_detect(sim_files, pattern = ".RDS")) {

                               sim <- readRDS(path)

                               output <- sim$Rawdata_tbl %>%
                                 dplyr::mutate(date = as.Date(date),
                                               sim_number = as.character(index))

                             }

                           }) %>%
    dplyr::mutate(year = lubridate::year(.data$date)) %>%
    dplyr::filter(.data$year >= (min(.data$year) + burnin))

  unique_yrs <- unique(plot_data$year)

  #If we've got more than 10 years, start displaying every second year
  if (length(unique_yrs) > 10 & length(unique_yrs) < 50) {

    break_length <- length(unique_yrs)/2

  } else if (length(unique_yrs) > 50 & length(unique_yrs) < 200) {

    break_length <- length(unique_yrs)/25

  } else if (length(unique_yrs) > 200) {

    break_length <- length(unique_yrs)/50

  } else {

    break_length <- length(unique_yrs)

  }

  plot_data_median <- stats::median(plot_data$pop_size)

  ggplot2::ggplot(plot_data) +
    ggplot2::geom_line(ggplot2::aes(x = .data$date, y = .data$pop_size,
                                    colour = .data$sim_number),
                       size = 1, lty = 1, alpha = 0.25) +
    ggplot2::geom_hline(yintercept = plot_data_median, lty = 2) +
    ggplot2::geom_text(ggplot2::aes(x = min(.data$date), y = plot_data_median * 1.1, label = plot_data_median)) +
    ggplot2::theme_classic() +
    ggplot2::scale_x_date(breaks = seq(min(plot_data$date), max(plot_data$date), length.out = break_length),
                          date_labels = "%Y") +
    ggplot2::labs(y = "Population size", x = "") +
    ggplot2::theme(legend.position = "none")

}
