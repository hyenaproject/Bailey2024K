#' Plot the simulated hyena pedigree
#'
#' @param sim Object of class \code{\link{simulation}}. Must be following the method run_sim().
#' @param individual If you want to focus only on the relatives of a single individual, individual ID should be specified here.
#'
#' @return A ggplot of pedigree
#' @export
#' @examples
#' set.seed(666)
#' sim_test <- simulation$new(number_clans = 2,
#' start_clan_size = 20, sex_ratio = 0.5, mean_age = 72)
#'
#' sim_test$run_sim(number_steps = 10)
#' plot_pedigree(sim_test)

plot_pedigree <- function(sim, individual = NA){

  sim_pedigree <- sim$Rawdata_tbl %>%
    dplyr::mutate(ID = as.character(.data$ID)) %>%
    dplyr::group_by(.data$ID) %>%
    dplyr::summarise(birth_date = lubridate::year(.data$birth_date)[1],
              motherID = .data$mother[1],
              fatherID = .data$father[1])

  if (is.na(individual)) {

    melted_data <- sim_pedigree %>%
      dplyr::select(-"birth_date") %>%
      tidyr::pivot_longer(cols = c("motherID", "fatherID"), names_to = "variable") %>%
      dplyr::filter(!is.na(.data$value)) %>%
      dplyr::rename(ParentID = "value") %>%
      dplyr::mutate(Group = 1:dplyr::n())

    melted_data2 <- melted_data %>%
      dplyr::select(-"variable") %>%
      tidyr::pivot_longer(cols = c("ID", "ParentID"), names_to = "variable") %>%
      dplyr::rename(ID = "value") %>%
      dplyr::left_join(multiple = "all", sim_pedigree[, c("ID", "birth_date")], by = "ID") %>%
      dplyr::mutate(x = NA) %>%
      dplyr::filter(!is.na(.data$birth_date))

    #Generate x coordinates for each birth year
    melted_data2 <- melted_data2 %>%
      dplyr::group_by(.data$birth_date) %>%
      dplyr::mutate(x = 1:dplyr::n()/mean(seq(1, dplyr::n(), 1)))

    ggplot2::ggplot(melted_data2) +
      ggplot2::geom_point(ggplot2::aes(x = .data$x, y = .data$birth_date),
                          shape = 21, fill = "dark grey") +
      ggplot2::geom_line(ggplot2::aes(x = .data$x, y = .data$birth_date, group = .data$Group),
                         alpha = 0.1) +
      ggplot2::theme_classic() +
      ggplot2::theme(axis.text.x = ggplot2::element_blank(),
            axis.ticks.x = ggplot2::element_blank(),
            axis.title.x = ggplot2::element_blank()) +
      ggplot2::scale_y_reverse()

  }
}
