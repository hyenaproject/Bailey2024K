#' Estimate rank category for a given individual
#'
#' This function can be used to define individuals as either top ranking or lower ranking.
#' The function can be passed to the 'predictors' argument in simulation to specify how
#' predictor values should be extracted when simulating demographic outcomes.
#'
#' @param ID R6 object of class hyena.
#' @param age Integer. Age (months) of individuals that can be considered top ranking. Default 24mo.
#' @param sex Character. Sex of individuals that can be considered top ranking. Default male and female.
#' @param number.top Integer. Size of top ranking group. Default 5 considers only the top 5 individuals in each clan.
#' @param target Character. Which individual should be checked? If 'ID', checks if focal individual is in top ranked individuals.
#' If 'motherID', checks if mother of focal individual is in top ranked individuals. When motherID is unknown, fall back to
#' focal individual ID.
#'
#' @return Character vector. Individuals are either 'top5' or 'lower.ranking'
#' @export
fetch_id_rank.category <- function(ID, age = 24, sex = c("male", "female"),
                                   number.top = 5, target = "ID"){

  inhabitants_tbl <- ID$clan_ID$inhabitants_tbl

  top_rank <- inhabitants_tbl[inhabitants_tbl$age >= age & inhabitants_tbl$sex %in% sex, "ID"][1:number.top]

  if (target == "ID") {
    focalID <- ID$ID
  } else if (target == "motherID") {
    if (!is.null(ID$motherID)) {
      focalID <- ID$motherID$ID
    } else {
      focalID <- ID$ID
    }
  } else {
    stop("'target' argument should be either ID or motherID")
  }

  if (focalID %in% top_rank) "top5" else "lower.ranking"

}
