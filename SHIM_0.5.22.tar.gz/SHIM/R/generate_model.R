#' Fit models for survival, reproduction and twinning rates
#'
#' @param year_margin Numeric. Number of years, starting from the last observation date,
#' that should not be reserved as a test dataset.
#' @param db File path or R6 simulation object. Hyena database to use. Can either be a file path to an .sqlite database
#' or and R6 simulation object.
#'
#' @return Rda objects.
#' @export
generate_model <- function(db = file.choose(), year_margin = 0){

  if (!requireNamespace("hyenaR", quietly = TRUE)) {
    stop("Package 'hyenaR' is required to generate starting data")
  }

  ## FIXME: This is no longer used. We should instead have code to make new (minimal) spaMM models
  # data_list <- generate_model_data(db = db, year_margin = year_margin)
  #
  # #Create progress bar
  # pb <- utils::txtProgressBar(min = 1, max = 30, char = "|", style = 3)
  #
  # pb_counter <- 1
  #
  # utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Generate models
  # # Save all models in a named list
  # # This will be used to update sysdata.rda
  # model_list <- list()
  #
  # ###
  # # Clan density dependence models with interaction with rank ####
  # ###
  #
  # # All adult survival
  # model_list$survival_F_clan_rank <- mgcv::gam(surv ~ s(age, by = rank_category, k = 10) + rank_category + start_clan +
  #                                                clan_size +
  #                                                clan_size:rank_category,
  #                                              data = data_list$F_surv_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Pre-dispersal male survival
  # model_list$survival_M_predisp_clan_rank <- mgcv::gam(surv ~ s(age, by = rank_category, k = 10) + rank_category + start_clan +
  #                                                        clan_size +
  #                                                        clan_size:rank_category,
  #                                                      data = data_list$PreM_surv_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Post-dispersal male survival
  # model_list$survival_M_postdisp_clan <- mgcv::gam(surv ~ s(age, by = post_dispersal_status, k = 10) +
  #                                                    post_dispersal_status + start_clan + clan_size,
  #                                                  data = data_list$PostM_surv_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Female primiparous reproduction
  # model_list$repro_Fprimi_clan_rank <- stats::glm(repro ~ months*rank_category +
  #                                                   start_clan +
  #                                                   rank_category*(clan_size) +
  #                                                   after1y_effort_all,
  #                                                 data = data_list$F_repro_primi,
  #                                                 family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Female non-primiparous reproduction
  # model_list$repro_Fnonprimi_clan_rank <- stats::glm(repro ~ months*rank_category + months:age +
  #                                                      age + start_clan +
  #                                                      rank_category*(clan_size) +
  #                                                      after1y_effort_all,
  #                                                    data = data_list$F_repro_nonprimi,
  #                                                    family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Female twinning
  # model_list$twinning_clan_rank <- mgcv::gam(twin ~ s(age, by = rank_category, k = 10) + rank_category + start_clan +
  #                                              after1y_effort_all +
  #                                              clan_size +
  #                                              clan_size:rank_category,
  #                                            data = data_list$F_twin_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # ###
  # # Clan density dependence models with interaction with rank and year spline ####
  # #Note, we don't fit spline for age at first repro (not enough data)
  # ###
  #
  # # All adult survival
  # model_list$survival_F_clan_rank_year <- mgcv::gam(surv ~ s(age, by = rank_category, k = 10) + rank_category + start_clan +
  #                                                     clan_size +
  #                                                     clan_size:rank_category +
  #                                                     s(year, by = start_clan, k = 10),
  #                                                   data = data_list$F_surv_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Post-dispersal male survival
  # model_list$survival_M_postdisp_clan_year <- mgcv::gam(surv ~ s(age, by = post_dispersal_status, k = 10) +
  #                                                         post_dispersal_status + start_clan + clan_size +
  #                                                         s(year, by = start_clan, k = 10),
  #                                                       data = data_list$PostM_surv_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Pre-dispersal male survival
  # model_list$survival_M_predisp_clan_rank_year <- mgcv::gam(surv ~ s(age, by = rank_category, k = 10) + rank_category + start_clan +
  #                                                             clan_size +
  #                                                             clan_size:rank_category +
  #                                                             s(year, by = start_clan, k = 12),
  #                                                           data = data_list$PreM_surv_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Female primiparous reproduction
  # model_list$repro_Fprimi_clan_rank_year <- mgcv::gam(repro ~ months*rank_category +
  #                                                       start_clan +
  #                                                       rank_category*(clan_size) +
  #                                                       after1y_effort_all +
  #                                                       s(year, by = start_clan, k = 10),
  #                                                     data = data_list$F_repro_primi,
  #                                                     family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Female non-primiparous reproduction
  # model_list$repro_Fnonprimi_clan_rank_year <- mgcv::gam(repro ~ months*rank_category + months:age +
  #                                                          age + start_clan +
  #                                                          rank_category*(clan_size) +
  #                                                          after1y_effort_all +
  #                                                          s(year, by = start_clan, k = 10),
  #                                                        data = data_list$F_repro_nonprimi,
  #                                                        family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Female twinning
  # model_list$twinning_clan_rank_year <- mgcv::gam(twin ~ s(age, by = rank_category, k = 10) + rank_category + start_clan +
  #                                                   after1y_effort_all +
  #                                                   clan_size +
  #                                                   clan_size:rank_category +
  #                                                   s(year, by = start_clan, k = 10),
  #                                                 data = data_list$F_twin_data, family = "binomial")
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # # Standard male dispersal model
  #
  # #Male second dispersal
  # model_list$disp_M <- stats::glm(second_disp ~ is_philo,
  #                                 data = data_list$M_second_disp_data, family = stats::binomial(link = "logit"))
  #
  # pb_counter <- pb_counter + 1; utils::setTxtProgressBar(pb, pb_counter)
  #
  # return(model_list)

}
