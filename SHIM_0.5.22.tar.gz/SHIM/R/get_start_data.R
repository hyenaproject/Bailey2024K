#' Generate a snapshot of the hyena population on a given date.
#'
#' This snapshot can be used as the starting population for a simulation.
#'
#' @param db.path File path. Location of hyena database.
#' @param interactive Should function prompt the user?
#' @param at Date. Date at which snapshot should be returned.
#'
#' @return A tibble.
#' @export
#'
#' @examples
#' #Don't run because it requires a database file
#' #Return data of all individuals on Jan 1st, 1996
#' #get_data.start(at = "1996-01-01")
get_data.start <- function(db.path = file.choose(), at, interactive = TRUE){

  if (!requireNamespace("hyenaR", quietly = TRUE)) {
    stop("Package 'hyenaR' is required to generate starting data")
  }

  reload <- 1

  if (exists(".database") && attr(.GlobalEnv$.database, "datatype") == "full" && interactive) {

    reload <- utils::menu(title = "A full database is already loaded. Would you like to reload data?",
                          choices = c("Yes", "No"))

  }

  if (reload == 1) {

    #Load hyenaR data using full database
    force(db.path)

    hyenaR::load_package_database.full(db.path)

  }

  if (missing(at)) {
    at = hyenaR::find_pop_date.observation.first()
  }

  selections <- hyenaR::extract_database_table("selections") %>%
    dplyr::filter(.data$date <= at) %>%
    dplyr::group_by(.data$ID) %>%
    tidyr::nest(selections = .data$origin:.data$date)

  #Generate data in the format needed to build the simulation
  hyenaR::create_id_starting.table(at = at) %>%
    dplyr::mutate(date = at,
                  sex = hyenaR::fetch_id_sex(.data$ID),
                  age = floor(hyenaR::fetch_id_age(.data$ID, at = at, unit = "month")),
                  birth_date = hyenaR::fetch_id_date.birth(.data$ID),
                  birth_clan = hyenaR::fetch_id_clan.birth(.data$ID),
                  motherID = hyenaR::fetch_id_id.mother.genetic(.data$ID),
                  mothersocialID = hyenaR::fetch_id_id.mother.social(.data$ID),
                  fatherID = hyenaR::fetch_id_id.father(.data$ID),
                  current_clan = hyenaR::fetch_id_clan.current(.data$ID, at = at),
                  lifetime_RS = hyenaR::fetch_id_number.offspring(.data$ID, from = hyenaR::find_pop_date.conception.first(), to = at),
                  tenure = floor(hyenaR::fetch_id_duration.tenure(.data$ID, at = at)),
                  litterID = hyenaR::fetch_id_litterID(.data$ID)) %>%
    #We can only deal with 8 clans...any individuals in the non-main clans are filtered out
    #We can keep individuals that were born in other clans but moved into focal clans
    #We also need to exclude all individuals where we never knew the sex
    dplyr::filter(.data$current_clan %in% hyenaR::find_clan_name.all(main.clans = TRUE) & !is.na(.data$sex)) %>%
    dplyr::left_join(multiple = "all", selections, by = "ID") %>%
    #Add own rank and mother rank
    dplyr::mutate(hyenaR::create_id_rank.table(.data$ID, at = at),
                  mother_rank = hyenaR::fetch_id_rank.native.adult(ID = .data$mothersocialID,
                                                                   at = at)) %>%
    #Filter just the rank columns
    dplyr::select("ID":"selections", dplyr::contains("rank")) -> output_nosibling

  #Add age of reproduction information females
  hyenaR::create_id_starting.table(ID = dplyr::filter(output_nosibling, .data$sex == "female") %>%
                                     dplyr::pull(.data$ID)) %>%
    dplyr::mutate(cubs = hyenaR::fetch_id_id.offspring(ID = .data$ID, to = at,
                                                            filiation = c("mother_genetic", "mother_social_genetic"))) %>%
    tidyr::unnest(cols = "cubs") %>%
    dplyr::mutate(cub_bday = hyenaR::fetch_id_date.birth(ID = .data$cubs)) %>%
    dplyr::mutate(repro_age = floor(hyenaR::fetch_id_age(ID = .data$ID,
                                                             at = .data$cub_bday,
                                                             unit = "month"))) %>%
    dplyr::group_by(.data$ID) %>%
    #First repro will probably be an over-estimation for left-censored females
    #But we need it here so the simulation knows that they're already past age of first reproduction
    dplyr::summarise(last_repro = max(.data$repro_age),
                     first_repro = min(.data$repro_age),
                     .groups = "drop") -> repro_ages

  output_nosibling %>%
    dplyr::left_join(multiple = "all", repro_ages, by = "ID") -> output_nosibling_lastrepro

  #Add sibling information
  offspring_info <- hyenaR::create_litter_offspring.table(unique(stats::na.omit(output_nosibling$litterID))) %>%
    dplyr::select("litterID", "offspringID") %>%
    dplyr::group_by(.data$litterID) %>%
    dplyr::summarise(offspring = list(.data$offspringID), .groups = "drop")

  output_nosibling_lastrepro %>%
    dplyr::left_join(multiple = "all", offspring_info, by = "litterID") %>%
    dplyr::mutate(siblingID = purrr::map2_chr(.x = .$offspring, .y = .$ID,
                                              .f = ~{

                                                if (!is.null(..1) & length(..1) > 1) {

                                                  #Ignore triplet litters, these aren't possible in the simulation
                                                  return(setdiff(..1, ..2)[1])

                                                } else {

                                                  return(NA)

                                                }

                                              })) -> output

  output |>
    dplyr::arrange(.data$current_clan, .data$rank)

}
