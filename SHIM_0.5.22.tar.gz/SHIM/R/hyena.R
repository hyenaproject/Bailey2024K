#' R6 class representing a single spotted hyena individual
#'
#' `hyena` is an [`R6 class`][`R6::R6Class`] within a parent [`simulation`], [`crater`],
#' and [`clan`] object.
#'
#' @author Liam D. Bailey
#' @export
#' @examples
#' sim_test <- simulation$new(number_clans = 8,
#' start_clan_size = 20, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE)
#'
#' test_crater <- crater$new(number_clans = 8, start_clan_size = 20,
#' sex_ratio = 0.5, mean_age = 72, simulation_ID = sim_test)
#'
#' test_clan <- clan$new(clan_name = "Clan_A", start_clan_size = 20,
#' crater_ID = test_crater, sex_ratio = 0.5, mean_age = 72)
#'
#' test_hyena <- hyena$new(ID = "Jeff", sex = "female", age = 60, motherID = NULL,
#' fatherID = NULL, clan_ID = test_clan, birth_clan = test_clan,
#' sib_ID = NA, birth_date = "1964/01/01",
#' crater_ID = test_crater, last_repro = 0L)
#'
#' #Extract age of individual
#' test_hyena$age

hyena <- R6::R6Class(classname = "hyena",
                     public = list(

                       ## Slots for the class attributes #######################################################

                       #'@field ID Character. Name of the individual (format X-123).
                       ID = NULL,

                       #'@field alive Logical. Is the individual alive. If FALSE, individual
                       #'will be removed from the clan during clan method `update_clan`.
                       alive = NULL,

                       #'@field sex Character. 'male' or 'female'
                       sex = NULL,

                       #'@field age Integer. Age of individual in months.
                       age = 0,

                       #'@field birth_date Date (YYYY-MM-DD). Birthdate of individual.
                       birth_date = NULL,

                       #'@field birth_clan Character. Name of birth clan. For males
                       #'`birth_clan` and `clan_name` may be different after dispersal.
                       birth_clan = NULL,

                       #'@field motherID R6 object. Object of class [`hyena`] representing individuals (genetic) mother.
                       #'Can be NULL if mother is unknown at the beginning of the simulation.
                       motherID = NULL,

                       #'@field fatherID R6 object. Object of class [`hyena`] representing individuals father.
                       #'Can be NULL if father is unknown at the beginning of the simulation.
                       fatherID = NULL,

                       #'@field clan_name Character. Name of the current clan where
                       #'an individual is found. For a female, this will be the same as the birth clan. For a male, this
                       #'may be different following dispersal.
                       clan_name = NULL,

                       #'@field clan_ID R6 object. Parent object of class [`clan`] representing the current clan where
                       #'an individual is found. For a female, this will be the same as the birth clan. For a male, this
                       #'may be different following dispersal.
                       clan_ID = NULL,

                       #'@field crater_ID R6 object. Grandparent object of class [`crater`].
                       crater_ID = NULL,

                       #'@field simulation_ID R6 object. Great-grandparent object of class [`simulation`].
                       simulation_ID = NULL,

                       #'@field twin Character. Dominance of individual in a twin litter. Can be
                       #''singleton' (i.e. no twin sibling), 'dominant', or 'subordinate'.
                       #'Currently ignored.
                       twin = NA,

                       #'@field sib_ID R6 object. Object of class [`hyena`] representing individuals sibling.
                       #'Can be NULL if individual is in a singleton litter of sibling has died.
                       sib_ID = NULL,

                       #'@field tenure Integer. For males, the number of months spent in the current clan.
                       #'When non-random mate choice is implemented, longer tenure males will be chosen by females
                       #'before shorter tenure individuals.
                       tenure = NULL,

                       #'@field first_selection Date (YYYY-MM-DD). Date of males first clan selection. Can include
                       #'philopatric and non-natal dispersal.
                       first_selection = NULL,

                       #'@field first_date Date (YYYY-MM-DD). Date of males selection of the current clan.
                       #'Unlike first_selection attribute, this will change each time an individual disperses.
                       first_date = NULL,

                       #'@field stand_rank Numeric (-1 to 1). Standardised rank of individual.
                       stand_rank = NA,

                       #'@field ord_rank Integer. Ordinal rank of individual.
                       ord_rank = NA,

                       #'@field first_repro Integer. Age of female at first reproduction (months).
                       first_repro = NA,

                       #'@field last_repro Integer. Age of female at most recent reproduction (months).
                       #' This is 0 for primiparous mothers.
                       last_repro = 0L,

                       #'@field lifetime_RS Integer. Number of cubs produced by an individual.
                       lifetime_RS = 0L,

                       #'@field relat_unchosen_chosen List. Contains the mean genetic relatedness between
                       #'a female and all potential mates
                       # and the mean genetic relatedness between the focal female and the chosen male.
                       relat_unchosen_chosen = NULL,

                       #'@field genome R6 object. R6 object with method (mutations) and attribute dna
                       genome = emptyenv(),

                       ## Slots for the methods stored in the class ####################################################

                       #' @description
                       #' Create a new R6 object of class `hyena`.
                       #'
                       #' This functions is used to create the object within the parent [`clan`] object.
                       #'
                       #' @param ID Character. Name of individual (format X-123).
                       #' @param sex Character. "male" or "female".
                       #' @param age Integer. Age of individual in months when object is created.
                       #' @param stand_rank Numeric (-1 to 1). Standardised rank of individual when object is created.
                       #' @param ord_rank Integer. Ordinal rank of individual when object is created.
                       #' @param lifetime_RS Integer. Number of cubs produced by an individual when object is created.
                       #' @param first_selection Date (YYYY-MM-DD). The date of first selection for males that have dispersed
                       #' before the start of the simulation.
                       #' @param tenure Integer. For males that have dispersed before the start of the simulation,
                       #' the number of months a male has been in the current clan.
                       #' @param motherID R6 object. Object of class [`hyena`] representing individuals (genetic) mother.
                       #'Can be NULL if mother is unknown at the beginning of the simulation.
                       #' @param fatherID R6 object. Object of class [`hyena`] representing individuals father.
                       #'Can be NULL if father is unknown at the beginning of the simulation.
                       #' @param first_repro Integer. Age of first reproduction event. Will define when a female is
                       #' considered reproductively active.
                       #' @param last_repro Integer. Age of last reproductive event. Will be 0 for
                       #' primiparous mothers.
                       #' @param birth_clan Character. Name of birth clan.
                       #' @param clan_ID clan_ID R6 object. Parent object of class [`clan`] representing the current clan where
                       #'an individual is found. For a female, this will be the same as the birth clan. For a male, this
                       #'may be different following dispersal.
                       #' @param crater_ID R6 object. Parent object of class [`crater`].
                       #' @param sib_ID R6 object. Object of class [`hyena`] representing individuals sibling.
                       #' @param birth_date Date (YYYY-MM-DD). Birthdate of individual.
                       #'
                       #' @return an object of class `hyena`

                       initialize = function(ID, sex, age, first_repro = NA, last_repro = NA,
                                             stand_rank = NA, ord_rank = NA, lifetime_RS = 0, first_selection = NULL,
                                             tenure = NULL, motherID,
                                             fatherID, birth_clan, clan_ID, crater_ID, sib_ID, birth_date){

                         #Add basic info
                         self$alive            <- TRUE
                         self$ID               <- ID
                         self$birth_clan       <- birth_clan
                         self$sex              <- sex
                         self$age              <- age
                         #If first_repro isn't provided (i.e. individual where birth conditions unknown)
                         #Generate age of first reproduction from known distribution
                         self$first_repro      <- ifelse(is.na(first_repro), floor(stats::rnbinom(n = 1,
                                                                                                  size = 32.48,
                                                                                                  mu = 45.70)), first_repro)
                         self$last_repro       <- ifelse(is.na(last_repro), 0, last_repro)
                         self$sib_ID           <- sib_ID
                         self$stand_rank       <- stand_rank
                         self$ord_rank         <- ord_rank
                         self$lifetime_RS      <- lifetime_RS
                         self$first_selection  <- first_selection
                         self$tenure           <- tenure

                         #Save parent objects
                         self$clan_ID       <- clan_ID
                         self$crater_ID     <- crater_ID
                         self$simulation_ID <- crater_ID$simulation_ID

                         #Save clan name
                         self$clan_name <- self$clan_ID$clan_name

                         #Add genetic info
                         self$relat_unchosen_chosen <- c(unchosen = NA, chosen = NA)
                         self$genome                <- genome$new(crater_ID$simulation_ID$loci_number,
                                                                  crater_ID$simulation_ID$allelic_diversity,
                                                                  motherID, fatherID)

                         #If no birth_date is given (i.e. it's an individual generated at the start of the simulation)
                         if (is.na(birth_date)) {

                           #Make its first date and birth date both start_date - age
                           #We are assuming no immigrants, so this will be correct 'first_date' value
                           self$first_date <- self$simulation_ID$date - months(self$age)
                           self$birth_date <- self$simulation_ID$date - months(self$age)

                         } else {

                           #If birth date is provided (i.e. they are born during the simulation), use this instead.
                           self$first_date <- self$birth_date <- birth_date

                         }

                         #When an individual is juvenile and has no listed sibling it's listed as singleton.
                         #If it has a sibling which has already been defined, give it the opposite definition!
                         self$twin <- ifelse(self$age >= 24, NA,
                                             ifelse(is.null(self$sib_ID), "singleton",
                                                    ifelse(self$sib_ID$twin == "dominant", "subordinate", "dominant")))

                         #Information on parents and environment of individual
                         #Individuals simulated at the start will have unknown parents
                         self$motherID      <- motherID
                         self$fatherID      <- fatherID

                         #If there is no tenure and male >=24mo (i.e. it was generated at the start of our simulation)
                         #Then assume its a philopatric male (i.e. its tenure is the age - 24)
                         if (is.null(self$tenure) & self$age >= 24 & self$sex == "male") {

                           self$tenure <- self$age - 24

                         }

                       }))
