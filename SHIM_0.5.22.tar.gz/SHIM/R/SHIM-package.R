#' Welcome to SHIM - Spotted Hyena Individual-based Model
#'
#' This individual-based model is used to simulate the population of spotted hyenas
#' in Ngorongoro Crater, studied by the Ngorongoro hyena project (https://hyena-project.com/).
#'
#' @name SHIM-package
#' @aliases SHIM-package SHIM
#' @docType package
#'
#' @keywords package
#' @examples
#' \dontrun{
#'   browseVignettes("SHIM")
#' }
"_PACKAGE"
