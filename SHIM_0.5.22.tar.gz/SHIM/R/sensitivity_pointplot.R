#' Plot means and SE of sensitivity analysis results
#'
#' @param line Add a loess smoothed line to the plot
#' @param output Output of function \code{\link{sensitivity_func}}
#'
#' @export

sensitivity_pointplot <- function(output, line = TRUE){

  plot_data <- output %>%
    tidyr::pivot_longer(cols = -"focal_var", names_to = "variable") %>%
    dplyr::filter(!is.infinite(.data$value)) %>%
    dplyr::group_by(.data$focal_var, .data$variable) %>%
    dplyr::summarise(mean_value = mean(.data$value, na.rm = T),
              SE = stats::sd(.data$value, na.rm = T)/sqrt(dplyr::n()))

  overall_means <- output %>%
    tidyr::pivot_longer(cols = -"focal_var", names_to = "variable") %>%
    dplyr::filter(!is.infinite(.data$value)) %>%
    dplyr::group_by(.data$variable) %>%
    dplyr::summarise(mean = mean(.data$value, na.rm = T))

  if (line == TRUE) {

    output_plot <- ggplot2::ggplot(plot_data) +
      ggplot2::geom_errorbar(ggplot2::aes(x = .data$focal_var, ymin = .data$mean_value - .data$SE, ymax = .data$mean_value + .data$SE), width = 0, size = 1)+
      ggplot2::geom_point(ggplot2::aes(x = .data$focal_var, y = .data$mean_value), shape = 21, size = 3, fill = "dark grey")+
      ggplot2::geom_smooth(ggplot2::aes(x = .data$focal_var, y = .data$mean_value), se = FALSE, method = "loess")+
      ggplot2::facet_wrap(~.data$variable, scales = "free")+
      ggplot2::geom_hline(data = overall_means,
                          ggplot2::aes(yintercept = .data$mean),
                          lty = 2, size = 1)+
      ggplot2::theme_classic()

  } else {

    output_plot <- ggplot2::ggplot(plot_data)+
      ggplot2::geom_errorbar(ggplot2::aes(x = .data$focal_var, ymin = .data$mean_value - .data$SE, ymax = .data$mean_value + .data$SE), width = 0, size = 1)+
      ggplot2::geom_point(ggplot2::aes(x = .data$focal_var, y = .data$mean_value), shape = 21, size = 3, fill = "dark grey")+
      ggplot2::facet_wrap(~.data$variable, scales = "free")+
      ggplot2::geom_hline(data = overall_means,
                          ggplot2::aes(yintercept = .data$mean),
                          lty = 2, size = 1)+
      ggplot2::theme_classic()

  }

  return(output_plot)

}
