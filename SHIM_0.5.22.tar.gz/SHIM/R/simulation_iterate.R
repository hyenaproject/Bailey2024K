#' Fit and run an R6 simulation object
#'
#' Use simulation methods `new` and `run_sim` and
#' return the simulation object.
#'
#' @param ... Input variables for the simulation.
#' @param number_steps Integer. Number of time steps over which the simulation will run.
#' @param name Character. Name of simulation. Used to create output files.
#' @param save_dir File path. Folder where txt and/or RDS output should be saved.
#' @param save Character. Can be:
#'\itemize{
#'    \item {'no', No files are saved. Only tmp .txt file is generated for trouble shooting.}
#'    \item {'basic', Summary .txt file of output is saved to `save_dir`. Least memory intensive.}
#'    \item {'snapshot', Summary .txt file of output and .RDS file of individual level snapshots
#'    is saved to `save_dir`.}
#'    \item {'full' (default), Summary .txt file of output and .RDS file of full R6 object saved to
#'    `save_dir`. Most memory intensive, but simulation can be fully inspected.}
#'}
#' @param return Logical. Should simulation object be returned?
#' @param RDScompress Character. Passed to 'compress' argument of `saveRDS`. Default 'xz' which
#' shows best results for compressing R6 objects in tests.
#'
#' @return A simulation object
#' @export
#' @examples
#' #Same examples from simulation but using `simulation_fitrun`
#'
#' #Fast simulation for example
#' #Don't save
#'
#' sim_test_fast <- simulation_fitrun(number_steps = 2, number_clans = 5,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE,
#' return = TRUE, save = 'no')
#'
#' \dontrun{
#'
#' #Larger realistic example.
#' #290 seconds on i7-7567U 3.5GHz
#' sim_test <- simulation_fitrun(number_steps = 50, number_clans = 8,
#' start_clan_size = 20, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE,
#' return = TRUE, save = 'no')
#'
#' }

simulation_fitrun <- function(..., number_steps, name,
                              save = 'full',
                              return = FALSE, save_dir = ".",
                              RDScompress = "xz"){

  #Check functions
  ## TODO: Keep the path check and just copy code into SHIM?
  # save_dir <- check_function_arg.path(save_dir)
  save     <- check_function_arg.save(save)

  if (save == 'no') {

    save_file <- NULL

  } else {

    #Path of text file
    save_file <- paste0(save_dir, "/simulation_", name, ".txt")

  }

  sim <- simulation$new(...)

  tryCatch(sim$run_sim(number_steps = number_steps, save_file = save_file),
           error = function(e){

             if (grepl(e, pattern = "model has parameters that cannot be used")) {
               file.remove(paste0(save_dir, "/simulation_", name, ".txt"))
               stop(e$message)
             }

             message(paste("Simulation stopped before completion: \n", e))

           },
           warning = function(w){

             message(paste("Simulation stopped before completion: \n", w))

           })

  #Save .RDS if snapshot or full save is requested
  if (save %in% c('snapshot', 'full')) {

    RDS_path <- paste0(save_dir, "/simulation_", name, ".RDS")

    #Update simulation attribute to keep track of file locations
    sim$save_files <- c(sim$save_files, RDS_file = RDS_path)

    if (save == 'snapshot') {

      saveRDS(sim$Rawdata_tbl, file = RDS_path, compress = RDScompress)

    } else {

      saveRDS(sim, file = RDS_path, compress = RDScompress)

    }

  }

  #Return if specified
  if (return) {

    return(sim)

  } else {

    return(invisible())

  }

}

#' Rerun a simulation with additional timesteps
#'
#' @param number_steps Integer. Number of time steps over which the simulation will run.
#' @param simulation R6 object. Simulation object that has already been run.
#' @param return Logical. Should simulation object be returned? Generally, this is not
#' needed due to the mutability of R6 objects (i.e. changes in the function will also
#' change the input object); however, if re-running multiple simulations in parallel,
#' such as with `simulation_reiterate` this does not happen and we need to manually
#' return and over-write the original input.
#'
#' @return Nothing returned. Simulation objects will be updated in situ within
#' the original simulation list object due to mutability.
#' @export
#' @examples
#' #Fast simulation for example
#' sim_test_fast <- simulation$new(number_clans = 5,
#' start_clan_size = 10, sex_ratio = 0.5, mean_age = 72, calc_SS = FALSE)
#'
#' sim_test_fast$run_sim(number_steps = 2)
#'
#' #Check latest year in simulation data
#' max(sim_test_fast$Rawdata_tbl$current_date)
#'
#' #Rerun simulation
#' simulation_rerun(sim_test_fast)
#'
#' #See new simulation date
#' #Note, the simulation object has changed in place
#' max(sim_test_fast$Rawdata_tbl$current_date)

simulation_rerun <- function(simulation, number_steps, return = TRUE){

  #Check functions
  simulation <- check_function_arg.data.R6(simulation)

  #Check if there are any associated save files
  save_file <- ifelse(is.null(simulation$save_files$txt_file), ".", simulation$save_files$txt_file)

  tryCatch(simulation$run_sim(number_steps = number_steps, save_file = save_file),
           error = function(e){

             if (grepl(e, pattern = "model has parameters that cannot be used")) {
               stop(e$message)
             }

             message(paste("Simulation stopped before completion: \n", e))

           },
           warning = function(w){

             message(paste("Simulation stopped before completion: \n", w))

           })

  #Replace .RDS file if it exists
  if (!is.null(simulation$save_files$RDS_file)) {

    saveRDS(simulation, file = simulation$save_files$RDS_file)

  }

  if (return) {

    return(simulation)

  } else {

    return(invisible())

  }

}


#' Run multiple iterations of a simulation with different starting populations
#'
#' @param ... Starting information for the simulation
#' @param start_pops List. A list of data frames with individuals used to initialise the simulation.
#' @param predictors Named list of commands to extract model predictors from [`hyena`] objects.
#'Names of list should be the same as those used for models above.
#'
#'By default, will consider only those predictors available in default models.
#'
#'See ?predictors for more details and examples of defining predictors.
#' @param number_steps Integer. Number of time steps over which the simulation will run.
#' @param sim_years Integer vector. Vector of years over which simulation iterations
#' should be run.
#' @param i Integer. Number of times each combination of starting population and years should be
#' replicated. Total number of iterations will be i x length of `sim_years` x length of `start_pops`.
#' @param iterator_seed Integer. Seed values for all iterations are randomly selected from
#' a uniform distribution covering +/-2*10^9 (the range of representable integers in R).
#' iterator_seed argument can be used to fix the random seed for this process,
#' allowing full iteration procedures to be recreated.
#' @param parallel Logical. Should parallel computing be used if possible?
#' @param .parallel.min Integer. The minimum number of iterations for parallel computation
#' to be triggered (parallel computing on small jobs is inefficient)
#' @param CPUcores Integer. If parallel is TRUE and i is greater than .parallel.min, the number
#' of CPU used for parallel processing.
#' @param save_dir File path. Location where simulations should be saved.
#' @param return Logical. Should the simulation objects be returned in the R session. Note, with large simulations
#' and/or many iterations this can be very heavy on memory.
#'
#' @return A list of simulation objects
#' @export
#' @examples
#' \dontrun{
#'
#'#Create two different start populations
#'start_pops <- list(start_pop_example[1:10, ], start_pop_example)
#'
#'## EXAMPLE 1: Multiple iterations of 1 year/population combination
#'## Will run 2 times: 2(i) x 1(year) x 1(population) = 2
#'eg1_sim <- simulation_iterate(start_pops = start_pops[[1]],
#'sim_years = 1996, parallel = FALSE,
#'number_steps = 2, save_size = 1, i = 2,
#'save_dir = "./test_folder_eg1", return = TRUE)
#'
#'## EXAMPLE 2: Multiple iterations of one population across 2 years
#'#Will create two folder: ./test_folder_eg2/1995 and ./test_folder_eg2/1996
#'#Runs 4 times: 2(i) x 2(year) x 1(population) = 4
#'eg2_sim <- simulation_iterate(start_pops = start_pops[[1]],
#'sim_years = 1996:1997, parallel = FALSE,
#'number_steps = 2, save_size = 1, i = 2,
#'save_dir = "./test_folder_eg2", return = TRUE)
#'
#'## EXAMPLE 3: Multiple iterations of 2 populations in 2 different years
#'#Runs 8 times: 2(i) x 2(year) x 2(population) = 8
#'eg3_sim <- simulation_iterate(start_pops = start_pops,
#'sim_years = 1996:1997, parallel = FALSE,
#'number_steps = 2, save_size = 1, i = 2,
#'save_dir = "./test_folder_eg3", return = TRUE)
#'
#'## EXAMPLE 4: Same as example 3 but with parallel processing
#'eg6_sim <- simulation_iterate(start_pops = start_pops,
#'sim_years = 1996:1997,
#'number_steps = 2, save_size = 1, i = 2,
#'save_dir = "./test_folder_eg6", return = TRUE,
#'parallel = TRUE, .parallel.min = 2, CPUcores = 4)
#'}

simulation_iterate <- function(..., number_steps, start_pops = NULL, predictors = NULL,
                               sim_years = NA_integer_,
                               i = 1, iterator_seed = NULL,
                               parallel = TRUE, .parallel.min = 20, CPUcores = NULL, save_dir, return = FALSE){

  #Make pops into a named list
  if (is.null(start_pops)) {

    start_pops <- list(NULL)
    names(start_pops) <- "pop1"

  } else if (inherits(start_pops, "data.frame")) {

    start_pops <- list(start_pops)
    names(start_pops) <- "pop1"

  } else {

    names(start_pops) <- paste0("pop", seq(1, length(start_pops)))

  }

  #Set iterator seed for random number generation
  set.seed(iterator_seed)

  ## Only trigger parallel if necessary to avoid overhead for small job
  ## Adapted from hyenaR/social_support.R
  ## TODO: Maybe write this parallel computing logic as a stand alone function?
  method <- NULL

  if (parallel) {

    if (!is.null(CPUcores) && CPUcores > 1) {

      if (i*length(sim_years)*length(start_pops) < .parallel.min) {

        message("Number of iterations below the minimum allowed for parallel computing.")

        method <- "purrr"

      } else {

        method <- "furrr"

      }

    } else {

      message("`CPUcores` must be greater than 1 for parallel computing")

      method <- "purrr"

    }

  } else {

    method <- "purrr"

  }

  #If year input is a list, it can only be one year combination.
  #TODO: Allow multiple year combinations in a list
  if (inherits(sim_years, what = "list")) {

    if (any(sapply(sim_years, length) > 1)) {

      stop("When providing different years for each model, only one combination of years is currently possible.")

    }

    #Determine all iterations needed
    all_iterations <- tidyr::expand_grid(start_pop = start_pops,
                                         year = list(sim_years),
                                         i = 1:i) %>%
      dplyr::mutate(sim_name = paste(names(.data$start_pop), .data$year, sep = "_")) %>%
      #Set seed of each simulation
      #This returns a double, but it is coerced to an integer when using set.seed()
      dplyr::mutate(seed = stats::runif(n = i, min = -2000000000, max = 2000000000)) %>%
      ## Convert the years into functions that we can input to predictors
      dplyr::mutate(predictors = lapply(paste0("list(year = function(...)", year, ")"), \(r) eval(parse(text = r))))

  } else {

    #Determine all iterations needed
    all_iterations <- tidyr::expand_grid(start_pop = start_pops,
                                         year = sim_years,
                                         i = 1:i) %>%
      dplyr::mutate(sim_name = paste(names(.data$start_pop), .data$year, sep = "_")) %>%
      #Set seed of each simulation
      #This returns a double, but it is coerced to an integer when using set.seed()
      dplyr::mutate(seed = stats::runif(n = i, min = -2000000000, max = 2000000000)) %>%
      ## Convert the years into functions that we can input to predictors
      dplyr::mutate(predictors = lapply(paste0("list(year = function(...)", year, ")"), \(r) eval(parse(text = r))))

  }

  #If a predictors list already exists, we should append the year term to it.
  if (!is.null(predictors)) {
    all_iterations <- all_iterations |>
      dplyr::rowwise() |>
      dplyr::mutate(predictors = list(append(.data$predictors, !!predictors)))
  }

  #Change the named list to specify both the population and year
  #This makes each simulation uniquely indexable in the output
  names(all_iterations$start_pop) <- all_iterations$sim_name

  #Create save directory if it doesn't exist
  system(paste0("mkdir -p ", save_dir))

  #If input is a list we can currently only have 1 folder
  #Call it sim_1
  if (inherits(sim_years, what = "list")) {

    all_iterations <- all_iterations %>%
      dplyr::mutate(save_dir = paste(save_dir, "sim_1", sep = "/"))

    purrr::walk(.x = unique(all_iterations$save_dir),
                .f = ~{

                  system(paste0("mkdir -p ", ..1))

                })

    #If we're doing more than one year give each of them a sub-folder in the save directory
  } else if (length(sim_years) > 1) {

    all_iterations <- all_iterations %>%
      dplyr::mutate(save_dir = paste(save_dir, .data$year, sep = "/"))

    purrr::walk(.x = unique(all_iterations$save_dir),
                .f = ~{

                  system(paste0("mkdir -p ", ..1))

                })

  } else {

    all_iterations <- all_iterations %>%
      dplyr::mutate(save_dir = save_dir)

  }

  #If the folders already contain simulations, then names use i + n, where n
  #is the number of previous simulations.
  all_iterations <- all_iterations %>%
    dplyr::mutate(i = purrr::map2_int(.x = .data$i,
                                      .y = .data$save_dir,
                                      .f = function(i, save_dir){

                                        previous_sims <- length(list.files(save_dir, pattern = ".txt"))

                                        return(i + previous_sims)

                                      }))

  #If no years are given (NA by default) then name should just be the same as i
  #Otherwise, it is a concatenation of year and iteration number
  if (inherits(sim_years, what = "list")) {

    all_iterations <- all_iterations %>%
      dplyr::mutate(name = paste("sim", .data$sim_name, .data$i, sep = "_"))

  } else if (all(!is.na(sim_years))) {

    all_iterations <- all_iterations %>%
      dplyr::mutate(name = paste(.data$sim_name, .data$i, sep = "_"))

  } else if (is.na(sim_years)) {

    all_iterations <- all_iterations %>%
      dplyr::mutate(name = paste(.data$sim_name, .data$i, sep = "_"))

  }

  if (method == "furrr") {
    CPUcores <- hyenaR::load_parallel_processing(CPUcores = CPUcores)  ## TODO: not sure we want to use hyenaR here since it creates hard dependency
    sim_output <- furrr::future_pmap(list(start_pop = all_iterations$start_pop,
                                          name = all_iterations$name,
                                          predictors = all_iterations$predictors,
                                          save_dir = all_iterations$save_dir,
                                          seed = all_iterations$seed),
                                     simulation_fitrun,
                                     .progress = TRUE, ...,
                                     number_steps = number_steps,
                                     return = return,
                                     .options = furrr::furrr_options(seed = TRUE,
                                                                     packages = c("stats", "SHIM")))
  } else if (method == "purrr") {
    #.x is fed to first argument (name) so that each output has the name
    #of the iteration.
    sim_output <- purrr::pmap(list(start_pop = all_iterations$start_pop,
                                   name = all_iterations$name,
                                   predictors = all_iterations$predictors,
                                   save_dir = all_iterations$save_dir,
                                   seed = all_iterations$seed),
                              simulation_fitrun, ...,
                              number_steps = number_steps,
                              return = return)
  }

  if (return) {

    return(sim_output)

  } else {

    return(invisible())

  }

}

#' Rerun multiple existing simulations
#'
#' @param sim_list List. List of R6 simulation objects.
#' @param number_steps Integer. Number of time steps over which the simulation will run.
#' @param parallel Logical. Should parallel computing be used if possible?
#' @param .parallel.min Integer. The minimum number of iterations for parallel computation
#' to be triggered (parallel computing on small jobs is inefficient)
#' @param CPUcores Integer. If parallel is TRUE and i is greater than .parallel.min, the number
#' of CPU used for parallel processing.
#'
#' @return Nothing returned. Simulation objects will be updated in situ within
#' the original simulation list object due to mutability.
#' @export
#' @examples
#' \dontrun{
#'
#'#Create an iterative set of simulations
#'all_sims <- simulation_iterate(i = 2, sim_years = 1995:1996, parallel = TRUE,
#'number_steps = 2, number_clans = 5, .parallel.min = 10, CPUcores = 4,
#'start_clan_size = 10, sex_ratio = 0.5, mean_age = 72,
#'save_dir = "./test_folder_parallel", return = TRUE)
#'
#'#Extend these simulations (parallel)
#'simulation_reiterate(all_sims, number_steps = 2, parallel = TRUE,
#'CPUcores = 4, .parallel.min = 1)
#'
#'#Extend these simulations (non-parallel)
#'simulation_reiterate(all_sims, number_steps = 2, parallel = FALSE)
#'}

simulation_reiterate <- function(sim_list, number_steps,
                                 parallel = TRUE, .parallel.min = 20,
                                 CPUcores = NULL){

  #If there is an attached .txt save file, check that it matches the input sim
  #This is needed because of non-mutability that occurs in parallel
  #Just check first one, because it should be fine in others
  #NOTE: We don't do this for the .RDS file because this could be *huge*
  #Consequences of repeat extension on .RDS file are less severe because it will
  #just continue to over-write the same file...with .txt file it will continue to append
  #the same values to the text file.
  if ("txt_file" %in% names(sim_list[[1]]$save_files)) {

    txtfile <- utils::read.csv(sim_list[[1]]$save_files$txt_file)

    #If last date and current date of sim are not matching there is a problem
    if (as.Date(txtfile$date[nrow(txtfile)]) > sim_list[[1]]$date) {

      stop("Simulation and save file are out of sync. This may occur if you re-iterate simulations
           in parallel (mutability is lost). When re-iterating in parallel we recommend
           saving the output in the global environment. Try to reload simulations from file to fix this problem.")

    }

  }

  #Need an iterator i to loop through list
  #For some reason, map can't loop through list of R6 objects
  i <- length(sim_list)

  ## Only trigger parallel if necessary to avoid overhead for small job
  ## Adapted from hyenaR/social_support.R
  ## TODO: Maybe write this parallel computing logic as a stand alone function?
  method <- NULL

  if (parallel) {

    if (!is.null(CPUcores) && CPUcores > 1) {

      if (i < .parallel.min) {

        message("Number of iterations below the minimum allowed for parallel computing.")

        method <- "purrr"

      } else {

        method <- "furrr"

      }

    } else {

      message("`CPUcores` must be greater than 1 for parallel computing")

      method <- "purrr"

    }

  } else {

    method <- "purrr"

  }

  if (method == "furrr") {
    CPUcores <- hyenaR::load_parallel_processing(CPUcores = CPUcores)
    sim_output <- furrr::future_map(.x = sim_list,
                                    .f = simulation_rerun,
                                    .progress = TRUE, return = TRUE,
                                    number_steps = number_steps,
                                    .options = furrr::furrr_options(seed = TRUE,
                                                                    packages = c("stats", "SHIM")))

    return(sim_output)

  } else if (method == "purrr") {
    #.x is fed to first argument (name) so that each output has the name
    #of the iteration.
    sim_output <- purrr::map(.x = sim_list,
                             .f = simulation_rerun,
                             number_steps = number_steps)

    return(invisible())

  }

}

#' Generate summary statistics for a group of simulation iterations.
#'
#' @param sim An R6 simulation object.
#' @param simname Name of simulation object to be saved in tibble.
#'
#' @return A tibble containing summary statistics
#' @export

simulation_stats <- function(sim, simname = "1"){

  #TODO: The process to extract each stat should be separate functions
  #That way they can be called in e.g. single simulation vignette and
  #here.

  #Load data
  hyenaR::load_package_database.sim(data.R6 = sim, verbose = FALSE)

  hyenaR::create_id_starting.table(sex = "female",
                                   from = hyenaR::find_pop_date.observation.first(),
                                   to = hyenaR::find_pop_date.observation.last(),
                                   lifestage = "cub", lifestage.overlap = "start") %>%
    dplyr::mutate(lifespan = hyenaR::fetch_id_duration.lifespan(.data$ID)) %>%
    # Remove NAs for lifespan = IDs still not dead = right-censored IDs
    dplyr::filter(!is.na(.data$lifespan)) -> lifespan_data

  output <- dplyr::tibble(median_lifespan_F = stats::median(lifespan_data$lifespan)) %>%
    dplyr::mutate(name = simname)

  return(output)

}

#' Extract simulation summary statistics for multiple simulations
#'
#' @param simdir Folder containing simulation files saved as RDS objects.
#'
#' @return A tibble containing summary statistics for all simulations
#' @export

simulation_stats_iterate <- function(simdir) {

  sim_files <- list.files(simdir, pattern = ".RDS", full.names = TRUE)

  i <- stringr::str_sub(sim_files, start = -5, end = -5)

  output <- purrr::map2_df(.x = sim_files, .y = i,
                           .f = ~{

                             sim <- readRDS(..1)

                             simulation_stats(sim = sim, simname = ..2)

                           })

  return(output)

}
