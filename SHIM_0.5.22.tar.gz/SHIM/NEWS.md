# v. 0.5.22

## Minor changes
- Fix bug in `generate_model_data()` that used old hyenaR arguments.

## Major changes
- when `include_ranef = FALSE` `simulate_model()` now computes marginal predictions by integration over the distribution of the random factor (on the response scale) whenever possible.

# v. 0.5.21

## Minor changes
- The 'inhabitants_tbl' of each clan object now includes a column 'natal' to identify natal individuals in the clan. Can be useful if wanting to extract ranks for natal only individuals with predictors.
- Output of 'generate_monthly_data()' now returns all rank metrics for an individual at each time-step. This is useful if we want to build models based on different rank metrics.

## Bug fixes
- Initialising using a start population data frame now forces ordering individuals by rank, rather than alphabetically.
- 'start_pop_example' is ordered by rank.

---

# v. 0.5.2

## Major changes
- Adult males (that have previously made a clan selection) cannot pick their current clan when dispersing again. This is because we can only model probability of male dispersals, we have no data on cases of prospecting that don't lead to dispersal.

---

# v. 0.5.12

## Minor changes
- SHIM should be able to run without package attached.

## Developer changes
- Remove dependence on future and doParallel (these are already installed as dependencies of other packages).
- Remove dependence on e1071. Used for function 'skewness', but this is not currently used in code.

---

# v. 0.5.11

## Bug fix

- Fixed bug caused by removing 'cub_survival_age'

---

# v. 0.5.1

## Major changes

- 'cub_survival_age' has been removed as a trait from simulations. Mothers can now reproduce even if they have young cubs, which matches what we observe in the wild.

---

# v. 0.5.0

## Major changes

- Default models are now stored in a single object 'model_list'. These are spaMM mixed models fitted on a few years of data. They are intended for tests and examples only *not for analysis*.
See `?models` for more details.
- Simulation now takes an argument 'predictors'. This is a named list of functions that will be used to extract newdata to simulate demographic outcomes. All functions expect an input ID, which is a single R6 object of class hyena. See `?predictors` for more details.
- Traits 'effort', 'year', 'favourable_year' and 'year_transition' are removed from simulation. 'effort' and 'year' can be replicated using new 'predictors' argument. Other traits are removed all together.
- 'start_pop_example' is now a snapshot of the real data on the first observation date.
- 'simulation_iterate.multistart' is deprecated. This functionality now exists in function 'simulation_iterate'.
- 'sim_years' argument can now accept non-integer values. This is useful when modelling time
at non-year resolution.

## Minor changes
- 'glm.nb' models no longer supported.

## Bug fixes
- Fix bug that placed cubs at the bottom of the hierarchy, rather than below their mother.

## Developer changes
- Number of assets with package substantially reduced, including small models used for testing (rather than full models fitted on all data).
- Substantial speed increase from batching processes (e.g. we call simulate once for survival of all females, rather than individually).
- Reduce dependencies, including hyenaR, mgcv, gratia etc. These models are supported if called by the user, but not imported with the package.
- Clan objects now include new trait 'inhabitants_tbl', which is a current snapshot of the clan hierarchy. This can be useful to find individual rank.

---

# v. 0.4.0

## Major changes

- Name of package changed from `HyenaPopmod` to `SHIM` to match our common acronym.

---

# v. 0.3.8

## Major changes

- New function `simulation_elasticity` that allows us to run elasticity/sensitivity analysis on individual models. Function will offset model intercepts (increase and decrease) while keeping all other model terms constant. Users can specify which models to run analysis on and the effect size of change.
- 

## Minor changes
- When running multiple populations and iterations, output list has more meaningful names (avoid duplicate model names).
- Changes to parallel processing is setup to ensure parallel processing is possible on CS1 Linux server.
- Fitting models without usable parameters (i.e. that are not attributes within the simulation) now returns understandable errors.

## Developer changes
- Use quoted variable names when querying column *names* (that are passed to tidyselect). Example functions include `select()`, `pivot_wider/longer()`, `unnest()`, and `rename()`.
- Added documentation for `disp` model that was missing in some cases.
- Update all code to work with `{dplyr}` v1.1.0. This includes using `reframe()` rather than `summarise()`, specifying argument 'multiple = "all"' in all joins, and removing cases of `group_by()/case_when()` that are known to be slow with new version.
- Update all code to work with `{tidyr}` v1.2.0. All functions that use tidyselect now use quotations.

---

# v. 0.3.7

## Major changes

- Default model set used in simulation is now 'clanrank_year'. Demographic variables are affected by clan size. Density dependent effect varies with rank. Demographic variables in each clan vary over time. Previous default did not consider time effects.
- New argument in simulation iteration 'year_transition', which allows us to simulate a frequency of good and bad years. 'year_transition' should be a list with two named numeric values, 'good_transition' (probability for a good year to be followed by another good year) and 'bad transition' (probability for a bad year to be followed by another bad year). Internally, a good year represents conditions in 2010 while a bad year represents conditions in 2018. 
- The realised outcome of good and bad years is stored as a numeric vector in new attribute 'favourable_years'.

## Minor changes

---

# v. 0.3.61

## Major changes

## Minor changes

- Simulation takes new argument logical `include_ranef` on initialization. `include_ranef` defines whether simulation outcomes will condition on random effects internally (i.e. year). If `include_ranef` is FALSE, `year` argument will have no affect on the outcome of the simulation.
- `generate_data()` is now split into two functions: `generate_monthly_data()` to return data frame of monthly demographic information and `generate_model_data()` to filter monthly data for different demographic models.
- `generate_model_data()` now works for both a full database and simulation (R6) object.

## Bug fixes
- Simulations using models from `{lme4}` now condition on random effects in the same way as those of `{spaMM}`. Previously, `{lme4}` models would condition on none of the random effects (i.e. year was ignored).

---

# v. 0.3.6

## Major changes

- 'output' argument removed from simulation. All simulations will save time steps in the same way:
  - A clan/population summary is saved at each time step (e.g. pop nr, male nr, cub nr). This is saved in a .txt file (located in tmp unless otherwise specified) and Summarydata_tb trait of the simulation object.
  - Individual level data is saved at each time step. To prevent memory issues, the maximum number of time steps stored can be adjusted with the argument 'save_size'.
  - Default argument of 'save_size' is Inf, replicating original 'full' output format.
  
- New 'save' argument in `simulation_fitrun()` that determines how data is saved to disk. Has four options:
  - 'no': No files are saved to physical disk. Clan/population summary is saved as .txt file in tmp for troubleshooting.
  - 'summary': Clan/population summary is saved as .txt file in specified location.
  - 'snapshot': In addition to clan/population summary, individual level data is saved as a .RDS file.
  - 'full' (default): Clan/population summary is saved as .txt. R6 simulation object is saved as .RDS file. This replicates original save = TRUE behaviour.

## Minor changes

- .RDS files are now saved using 'xz' compression by default. Tests suggest this is most effective compression for R6 object.
- Use `inherits()` to check class of objects rather than `class(x) == "y"`. Recommended by R CMD Check.

## Bug fixes

---

# v. 0.3.52

## Major changes

## Minor changes

- `simulation` object has new attribute `version` defined on initialization. This stores the package version number of HyenaPopmod at the time of simulation. Useful to identify old results, particularly for bug fixing.

## Bug fixes

---

# v. 0.3.51

## Major changes

## Minor changes

## Bug fixes

- Fix bug when clan dies while using 'summary' output. Because we were appending to a text file, when a clan died (and was removed) number of columns in output data and source file did not match. This led to data being assigned to wrong columns. Problem is fixed so that when a clan dies all columns will be NA.

---

# v. 0.3.5

## Major changes

- `simulation_iterate.multistart` allows us to run iterations with different starting conditions.

## Minor changes

## Bug fixes

---

# v. 0.3.41

## Major changes

## Minor changes

## Bug fixes

- `simulation_fitrun` now correctly saves file path to .RDS file in simulation object. Previously, .RDS file was save *before* save path was updated, therefore the saved file did not have the correct file path. Using `simulation_rerun` or `simulation_reiterate` would therefore fail to update the .RDS file.

---

# v. 0.3.4

## Major changes

- Bug fix for `simulation_reiterate`, now also works in parallel. Note: When running in parallel R6 objects appear to lose mutability (i.e. changes in parallel do not change original input object), therefore, simulation should be output and assigned to replace the input simulation. Have included an error check to ensure that .txt save files don't get appended multiple times.

## Minor changes

- Extinct populations no longer throw error. Instead, all 'non-viable' populations (i.e. extinct or only 1 individual) will throw warning and terminate *after saving last snapshot*.

## Bug fixes

---

# v. 0.3.3

## Major changes

- Remove dependent cub death in simulation. Previously, cubs below a chosen threshold (12 months default) would die if mothers have died. This conflicts with our estimation of reproduction that implicitly includes cub survival in the first 6 mo. We may end up overestimating mortality in young cubs.
- spaMM models produce conditional simulations, rather than the spaMM default to return unconditional simulations.


## Minor changes

- Remove months with natal -> philopatric status change in males. Previously, this was included because philopatric males are now considered post-dispersal males.
- spaMM models do not produce print messages during simulation.

## Bug fixes

---

# v. 0.3.2

## Major changes

## Minor changes

- Age term removed from primiparous female reproduction model. In primiparous females, age and month are essentially identical creating issues of multi-collinearity.
- Hard-coded limit for age at first reproduction is included as attribute `female_first_repro` in simulation. Default 24mo.
- Update female reproduction model vignette to explain model selection process.

## Bug fixes

---

# v. 0.3.1

## Major changes

- Raw data in simulation is now stored as 'Rawdata_tb' rather than 'output_data_raw'. This allows it to be saved together with all other tables in `write_output`.
- Remove effect of primiparity in pre-dispersal male survival. This was applied inconsistently because we included it in male survival models but not to young females. Effect in pre-dispersal model was limited, so just removed for parsimony of models.
- `output` argument ('full' or 'summary') is now defined in simulation initialization (rather than in `run_sim()`).
- `number_steps` argument is not defined in `run_sim()` rather than during simulation initialization. This allows the number of steps to be changed for consecutive uses of `run_sim()`.
- Redefine post-dispersal males to include both dispersers and philopatric males. The post-dispersal male model now includes a term 'post_dispersal_status' to differentiate between these two groups. Pre-dispersal male model now only includes males before any clan selection, and so will only be used to predict survival from 6-24mo in the simulation.
- Female reproduction is now simulated using two logistic regressions: primiparous reproduction and non-primiparous reproduction (with effects of months since last repro and age). Primiparous reproduction includes all records of primiparous females, but we hard-code a cap in the simulation that only uses the model for females >= 24mo. For more detail on why this model design was used see `female_repro_model` vignette.
- Choices for all models are now described in included vignettes.
- Lifespan now has a hard-coded cap in 25 years. Males and females cannot survive past this point. This prevents the (few) cases of very long lived individuals.

## Minor changes

- Remove unused arguments in R6 objects (second_dispersal_chance in simulation object).
- Add defaults to many functions. e.g. simulation$new() can now be run using only default arguments.
- All R6 objects can access all their parents (e.g. hyena objects have simulation_ID).
- Date information is now stored in simulation object rather than crater.
- Simulation can now work with negative binomial models. May be useful if we wish to model e.g. age at first reproduction.
- `check_function_arg.data.R6()` is now moved from hyenaR into this package.

## Bug fixes

- Fix bug where individuals were dropped from model fitting due to incorrect rank calculation. For a number of reasons (e.g. using mother rank when mother was dead) individuals return NA rank and were dropped from model fitting. Correcting these issues provided many more records for model fitting, which should allow for more robust models.

---

# v. 0.3.0

## Major changes

- Secondary male dispersal is now simulated from a (basic) secondary dispersal model. Model accounts for higher secondary dispersal probability in philopatric males.

- Reproduction is now modelled using two separate models. One negative binomial to model age of first reproduction for young females and another, logistic regression, to model probability of reproduction following previous successful birth. Using age at first reproduction model means that there is no fixed cut-off for when females can begin to reproduce (previously considered >= 36mo). Reproduction is still defined as cubs surviving to >= 6mo.

- Observer effort is only included as a linear term in reproduction/twinning models. Using spline on effort created trends that are difficult to explain biologically.

- Population size is removed from all models. Biological effect of population size is somewhat unclear as we expect density dependent effects to be more relevant at the clan level. Population density dependent effects were also very sensitive to inclusion of year spline, often leading to positive density dependence and unstable simulations. We now include only 3 model structures with the package: clan (clan size effect), clanrank (clan size effect interacts with rank), and clanrank_year (include year spline).

- `simulation_rerun()` and `simulation_reiterate()` allow us to extend existing simulations with new time steps.

## Minor changes

- Survival, dispersal, and reproduction are now all applied to clans in a random order. This should not have any affect in e.g. survival, where survival or each individual at time t is independent of survival of all other individuals; however, it is useful to have a standard approach when describing the model.

- Males are considered mature for both dispersal and reproduction at 24mo (previously age maturity for dispersal was earlier than for reproduction).

- Aging phase now occurs before survival. Previously survival occurred before aging so that survival was applied to cubs age == 0. Now that reproduction include cubs >= 6mo we no longer need to apply survival to cubs age == 0.

- Year term is used correctly for female survival.

- `simulate_model()` can now simulate using `glm.nb` model class.

## Bug fixes

- Prevent returning males being treated as philopatric for survival. Philopatric males are only those that have matured but have not yet left their natal clan. Once a male leaves the natal clan it can no longer be considered philopatric, even if it returns to the natal clan later.

- Survival of pre-dispersal males is affected by mother rank rather than own rank.

---

# v. 0.2.6

## Major changes

- Reproduction model now defines a reproduction event as 'females that produce at least one cub that survives to 6 months'. Observing young cubs (and thus estimating their survival) is very difficult in the crater, so many 'failed' reproduction events in our previous model may simply be females with cubs that died before they were observed. Similarly, estimating survival of young cubs is difficult as they are rarely observed. Therefore, our reproduction model now explicitly integrates effects of early life survival while our survival model now *only* applies to individuals >= 6 months.
- `simulation` objects can now take 'effort' as an argument during initialization. This allows us to dynamically adjust effort value in simulation.
- `simulation` can now take a named list of 'year' values that allows year to be adjusted differently for each demographic model.

## Minor changes

- Add test to ensure `simulation_iterate` can run in parallel.
- Old code that computes survival separately for young and adult females is removed.

## Bug fixes

- Fix typo in `generate_data` that classified some individuals as 'lower_ranking' and others as 'lower.ranking'.


---

# v. 0.2.5

## Major changes

- `simulation_iterate` can now add new simulations to a directory, rather than overwriting existing files.
- Data used to fit models in `generate_data()` can be returned to the user with argument `return = TRUE`. This is important to allow users to build custom models.
- `simulation_rerun` allows additional time steps to be run on an existing simulation object (R6 or .RDS file).
- User can now set seed of single simulation ('seed' argument in initialisation) and set seed for `simulation_iterate` ('iterator_seed' argument in function).

## Minor changes

## Bug fixes

---

# v. 0.2.4

## Major changes

- Simulations can now fix the year used to generate predictions from underlying demographic models using the `year` attribute of the simulation object.
- `simulation_iterate` now takes argument `i` and `sim_years`. Together, this allows us to run multiple iterations (`i`) with multiple fixed years (`sim_years`) in parallel.

## Minor changes

## Bug fixes

- Ensure correct clan names used when start population database is provided.
- Death database of clan objects should be integers.

---

# v. 0.2.3

## Major changes

- `plot_popsize()` and `plot_clansize()` accept simulations using output 'full' and 'summary'. 

## Minor changes

- Most functions now have working examples that can be run during checks.

## Bug fixes

---

# v. 0.2.2

## Major changes

- The `run_sim()` method now allows for two outputs: 'full' and 'summary' (replacing 'pop_size'). 'summary' output saves a broad demographic summary of each clan at each time point, including numbers of individuals in each lifestage, different sexes, reproductive output and deaths. This broad demographic summary is also returned in the optional saved text file.

- Add new methods to the `clan` R6 class:
  - `find_clan_id.R6()` returns IDs of individuals in a given subgroup. Individuals can be filtered by sex, lifestage (cub, adult, disperser, philopatric), and whether they are alive.
  - `find_clan_id.parent.R6()` returns IDs of individuals that have reproduced in the previous timestep. Can return mothers, fathers or both.
  - `fetch_clan_number.R6()` returns the number of individuals in a given subgroup. Individuals can be filtered by sex, lifestage (cub, adult, disperser, philopatric), and whether they are alive.
  - `fetch_clan_number.parent.R6()` returns the number of individuals that have reproduced in the previous timestep. Can return number of mothers, fathers or both.
  
- Add new methods in the `hyena` R6 class:
  - `survive_dependent.cub()` determines whether an individual is a dependent cub with a live mother. Dependent cubs whos mothers have died are assumed to die. Creating a stand-alone method allows us to build a more complex dependency relationship in the future if desired (e.g. add adoption).

## Minor changes

- When initialising a `crater` object, using procedurally generated individuals is now the default. `start_pop` argument can be left blank when procedural generation is desired.

- `clan` R6 class now has a `deaths` attribute for internal use. `deaths` is a data frame that records the number of individuals that died in the previous time step. This is required to record deaths in our demographic summary output before the individuals are removed during `update_clan()`.

## Bug fixes

- Fix bug where males could disperse multiple times in the same time step. Males are now excluded from prospecting and dispersing after they have made their first dispersal in a time step.

---

# v. 0.2.1

## Major changes

## Minor changes

* Remove variable assignment in in zzz.R. Variables used in dplyr should have namespace specified with `.data$xxx`.

* Specify namespace of all functions and remove `@import` in documentation.

* Import `%>%` to avoid having to type 'magrittr::`%>%`' in pipes.

* `gratia` and `lubridate` are now included as depends as we need to use internal functions (`gratia:::simulate.gam()` and `lubridate:::months()`) that cannot be coded with explicit namespace without generating a check warning.

---

# v. 0.2.0

## Major changes

* 'output' argument in simulation method `run_sim()` allows users to save only population size data with the input 'pop_size', instead of full snapshot of all individuals. Allows users to greatly reduce memory usage. Future version changes may include other save options (e.g. 'clan_size').
* Arguments 'save' and 'save_path' save population size data in an external .txt file. Allows simulation output to be checked while still running.

## Minor changes

* 'burnins' arguments have been removed from all functions. Size of burnins are not obvious a-priori and so this argument is not helpful. 

---

# v. 0.1.0

* Initial stable version. Major features documented below:
  * Simulation includes 5 R6 object types: simulation, crater, clan, hyena, genome.
  * Includes 5 gam models fitted from Ngorongoro Crater data; female survival, pre-dispersal male survival, post-dispersal male survival, female reproduction, twinning rate.
  * Simulation can be run individually using simulation object method `run_sim()` or run multiple iterations (with parallel processing) with `simulation_iterate()`.
  * Simulations can be run with starting state based on the real population using `get_data.start()` or using a procedurally generated starting state when `start_pop` argument is missing.
  * Male dispersal is roughly estimated using proportion of number of young females.
