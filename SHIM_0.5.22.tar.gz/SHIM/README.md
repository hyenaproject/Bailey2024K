# Spotted Hyena Individual-based Model (SHIM)

## Table of contents

[Introduction](#intro)

[Current version](#stable)

[Basics of SHIM](#basics)

[R6 object-oriented programming](#R6)

[Initialize a simulation](#initialize)

[Run a simulation](#run)

[Convenient wrapper functions](#wrappers)


<a name="intro"/>

## Introduction 

This repo includes an individual (agent) based model that can be used to simulate the population of spotted hyena (*Crocuta crocuta*) in the Ngorongoro Crater, Tanzania. We call the model the 'Spotted Hyena Individual-based Model' or SHIM. SHIM incorporates our understanding of spotted hyena behaviour, demography and reproductive biology collected by the Ngorongoro Crater Hyena Project since 1996.

<a name="stable"/>

## Stable release

The current stable version of SHIM is v0.5.21. Please read the NEWS for updates on changes made in previous versions.

Go to current releases (https://github.com/hyenaproject/SHIM/releases) and download the source code (.tar.gz) to your computer.
You can then use this source code to install the most recent stable version of the simulation in R.

`install.packages("file/path/SHIM-0.5.21.tar.gz", source = TRUE, repos = NULL)`

And then load it like any other package.

`library(SHIM)`

Let us know if you have any questions or encounter bugs.

<a name="basics"/>

## Basics of SHIM

<a name="R6"/>

### Working with R6 objects

SHIM is built using the package {R6}, which allows for object-oriented programming in R. Each object has a set of 'traits' (the characteristics of the object) and 'methods' (functions that the object can execute). Read more about R6 [here](https://r6.r-lib.org/articles/Introduction.html). To work with SHIM you will work with the 'simulation' object type. We must first 'initialize' the simulation using the method `new()` and then run the simulation using the method `run_sim()`. An example is provided below:

```r
#Initialize the simulation
my_sim <- simulation$new()

#Run the simulation for a given number of time-steps
my_sim$run_sim(number_steps = 5)
```

**NOTE:** Notice that when you use `run_sim()` you do not need to assign the output to a new object!! R6 objects are mutable, which means that as the simulation runs it will update the object 'my_sim'.

Below we give some more detail about working with the 'simulation' object.

<a name="initialize"/>

### Building a simulation ('initialization')

Before we start a simulation we have to define the initial population. This can be done in two ways a) using a snapshot of the real population or b) procedurally generating an initial population with certain demographic characteristics (e.g. sex ratio and age ratio).

#### Using a population snapshot

We can generate a population snapshot from the real data using the function `get_data.start()`, which takes a file path to a copy of the Ngorongoro Crater .sqlite database (db.path) and a date at which the snapshot should be taken, in the format "yyyy-mm-dd" (at). By default, the function will create a snapshot on the first day of observation.

The data frame returned by `get_data.start()` can be added to the simulation during initialization with the argument 'start_pop'.

```r
pop_snapshot <- get_data.start(db.path = "path/to/database.sqlite", at = "1997-01-01")
example_sim  <- simulation$new(start_pop = pop_snapshot)
```

#### Procedurally generate a initial population

Alternatively, if a snapshot is not provided to 'start_pop' we can generate a starting population with given demographic characteristics using argument such as 'mean_age' and 'start_clan_size'. See the documentation of method `new()` in the simulation object (`?simulation`). The default values of these arguments are similar to that of the real population. An example is provided below:

```r
#Generate a simulation where each clan has 10 individuals with a mean age of 120 months
example_sim  <- simulation$new(start_clan_size = 10, mean_age = 120)
```

#### Defining vital rate models

How vital rates are modelled inside SHIM is defined by the argument 'models'. This argument can use pre-defined model groups ('clanrank': demographic variables are affected by clan size. Density dependent effect varies with rank.; 'clanrank_year': demographic variables are affected by clan size. Density dependent effect varies with rank. Demographic variables in each clan vary with year.). Otherwise, a named list of models should be provided for each vital rate (female survival, pre-dispersal male survival, post-dispersal male survival, twinning rate, primiparous reproduction, non-primiparous reproduction).

```r
#Create model list
modlist <- list(
                #Model of female survival
                allF = mod1,
                #Model of pre-dispersal male survival
                predispM = mod2,
                #Model of post-dispersal male survival
                postdispM = mod3,
                #Model of twinning
                twin = mod4,
                #Model of primiparous female reproduction
                primirepro = mod5,
                #Model of multi-parous female reproduction
                nonprimirepro = mod6)
```

#### Using 'step_size' to define simulation resolution

By default, SHIM will create a simulation that runs at a monthly resolution. If you wish to use a coarser resolution, increase the value of 'step_size'.

```r
#A simulation that will run at a monthly resolution
monthly_sim <- simulation$new(step_size = 1)

#A simulation that will run at a 6 month resolution
halfyr_sim  <- simulation$new(step_size = 6)
```

<a name="run"/>

### Running the simulation

Once a simulation has been initialized we still need to *run* the simulation with the method `run_sim()`. We can define how long the simulation runs for with the argument 'number_steps'. Remember, the size of each time-step will depend on the 'step_size' argument defined in initialization.

```r
#Initialize a simulation that will run at a monthly resolution
monthly_sim <- simulation$new(step_size = 1)

#Run the simulation for 12 months (i.e. 1 year)
monthly_sim$run_sim(number_steps = 12)
```

#### Viewing our results

Results of our simulation are conveniently stored in a set of tables that mirror the structure of the Ngorongoro Hyena Project data.

```r
#Raw data (every individual at each save time step)
monthly_sim$Rawdata_tbl

#Adults table. All adults in the population
monthly_sim$Adults_tbl

#Deaths table. All records of individuals that have died
monthly_sim$Deaths_tbl
```

We can plot these results using in-built plotting functions. For example, `plot_clansize()` shows us the size of all clans in each time-step of the simulation.

```r
plot_clansize(monthly_sim)
```

#### SHIM and hyenaR

Because the output of SHIM is in the same format as the Ngorongoro Hyena Project data, we can also study simulation results using the [`{hyenaR}`](https://github.com/hyenaproject/drat) package. This package includes many useful functions to work with the hyena data.

```{r}
## Load the simulation output into hyenaR
hyenaR::load_package_database.sim(monthly_sim)

## Find the number of individuals in the population on a given date using hyenaR
hyenaR::fetch_pop_number(at = "1999-01-01")
```

**NOTE:** Simulation objects always start at the date '1996-04-12' (same as the Ngorongoro Hyena Project)

#### Re-running an existing simulation

We might decide to extend a simulation for longer after the initial run. To do this we can just use the `run_sim()` method again.

```r
#Extend the simulation for another 6 months (1.5 years in total)
monthly_sim$run_sim(number_steps = 6)
```

#### Using 'save_size' to limit memory usage

When running short simulations we can keep all individual level data; however, when running longer simulations this can cause a considerable memory stress and may lead to a system crash. We can prevent this using the argument 'save_size' during initialization. When the simulation is run it will only save information for the number of time-steps defined by 'save_size'. For example, if 'save_size = 6' and 'step_size = 1' the simulation will only store the most recent 6 months of data in the simulation.

*NOTE:* This means that saved data for plotting or any other analysis will only be available for the final saved timesteps.

```r
#Generate a model with monthly step size, but only save 2 most recent months
longer_sim_save2 <- simulation$new(step_size = 1, save_size = 2, seed = 123)
#Run for 10 steps, but only the last 2 will be saved
longer_sim_save2$run_sim(number_steps = 10)
length(unique(longer_sim_save2$Rawdata_tbl$current_date))

#Exactly the same simulation (same seed) but saving the last 5 steps
longer_sim_save5 <- simulation$new(step_size = 1, save_size = 5, seed = 123)
longer_sim_save5$run_sim(number_steps = 10)
length(unique(longer_sim_save5$Rawdata_tbl$current_date))
```

<a name="wrappers"/>

### Wrapper functions

Instead of initializing and running a single simulation in separate steps, you can use wrapper functions.

#### `simulation_fitrun()`

`simulation_fitrun()` will fit and run a simulation with one line of code. It takes arguments to both initialize the simulation object and run the simulation.

*NOTE:* By default, this will save the output of the simulation has a .txt or .RDS file. If you want to simulation to simply return within R you can adjust the 'save' and 'return' arguments as shown below.

```r
my_sim <- simulation_fitrun(step_size = 6,
                            number_steps = 3,
                            save_size = 2,
                            seed = 123,
                            save = 'no', return = TRUE)
                            
plot_clansize(my_sim)
```

#### `simulation_iterate()`

Often, we will want to run multiple iterations of a simulation with the same characteristics (e.g. starting population, step size) but different starting seeds. We can do this using `simulation_iterate()`. We provide all the same arguments as `simulation_fitrun()`, but also give 'i' (the number of iterations to run). If we want to recreate the same set of iterations, we can specify the 'iterator_seed' argument, to ensure that results can be recreated.

```r
my_sims <- simulation_iterate(i = 3, step_size = 6,
                              number_steps = 3,
                              save_size = 2,
                              save = 'no', return = TRUE,
                              ## FIXME:
                              #Currently, file path for saving is needed by default even when not saving
                              save_dir = ".")

#Plot first of these simulations                            
plot_clansize(my_sims[[1]])
```

By default, `simulation_iterate()` will run iterations with different starting seeds but the same starting population. This can lead to some initialization bias in the outcome. Alternatively, we can use the 'start_pops' argument in `simulation_iterate()` to run multiple iterations for different starting populations. 'start_pops' takes a list of data frames to use as starting populations (currently there is not option to use multiple different generated populations). The argument 'i' is still available, so we can run `i*length(start_pops)` simulations.

```r
pop_list <- list(pop1 = start_pop1,
                 pop2 = start_pop2)

simulation_iterate(start_pops = start_pops,
                   i = 2, step_size = 6, number_steps = 3)
```
